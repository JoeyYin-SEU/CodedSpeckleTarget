//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// detectCheckerboard.h
//
// Code generation for function 'detectCheckerboard'
//

#ifndef DETECTCHECKERBOARD_H
#define DETECTCHECKERBOARD_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
void b_detectCheckerboard(const ::coder::array<float, 2U> &b_I,
                          double peakThreshold, boolean_T highDistortion,
                          boolean_T usePartial,
                          ::coder::array<double, 2U> &points,
                          double boardSize[2]);

void detectCheckerboard(const ::coder::array<float, 2U> &b_I, double sigma,
                        double peakThreshold, boolean_T highDistortion,
                        boolean_T usePartial,
                        ::coder::array<double, 2U> &points,
                        double boardSize[2]);

} // namespace checkerboard
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder

#endif
// End of code generation (detectCheckerboard.h)
