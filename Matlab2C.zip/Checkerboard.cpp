//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Checkerboard.cpp
//
// Code generation for function 'Checkerboard'
//

// Include files
#include "Checkerboard.h"
#include "binaryMinOrMax.h"
#include "bsxfun.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "div.h"
#include "eml_setop.h"
#include "find.h"
#include "get_chessborad_pixel_data.h"
#include "get_chessborad_pixel_rtwutil.h"
#include "ismember.h"
#include "minOrMax.h"
#include "norm.h"
#include "polyfit.h"
#include "polyval.h"
#include "rt_nonfinite.h"
#include "squeeze.h"
#include "unsafeSxfun.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>

// Function Declarations
static void b_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5);
static void binary_expand_op(coder::vision::internal::calibration::checkerboard::
  Checkerboard *in1, const coder::array<float, 2U> &in2, const coder::array<
  float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::array<float,
  2U> &in5);
static void binary_expand_op(coder::array<float, 1U> &in1, const coder::array<
  float, 1U> &in2, const coder::array<float, 1U> &in3);
static void binary_expand_op(coder::array<double, 2U> &in1, const coder::vision::
  internal::calibration::checkerboard::Checkerboard *in2, const coder::array<
  double, 2U> &in3, const coder::array<double, 2U> &in4);
static void binary_expand_op(coder::array<double, 2U> &in1, const coder::array<
  double, 2U> &in2, const coder::array<double, 2U> &in3);
static void binary_expand_op(coder::array<float, 2U> &in1, const coder::vision::
  internal::calibration::checkerboard::Checkerboard *in2, double in3);
static void binary_expand_op(coder::array<double, 2U> &in1, const coder::array<
  double, 3U> &in2, const coder::array<double, 3U> &in3, const coder::array<
  double, 3U> &in4);
static void c_binary_expand_op(coder::array<float, 2U> &in1, const coder::array<
  float, 2U> &in2, const coder::array<float, 2U> &in3);
static void c_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5);
static void d_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5);
static void e_binary_expand_op(coder::array<boolean_T, 1U> &in1, const coder::
  array<double, 2U> &in2, const coder::array<double, 2U> &in3);
static void minus(coder::array<float, 2U> &in1, const coder::array<float, 2U>
                  &in2);

// Function Definitions
namespace coder
{
  namespace vision
  {
    namespace internal
    {
      namespace calibration
      {
        namespace checkerboard
        {
          void Checkerboard::arrayFind(const ::coder::array<boolean_T, 2U> &arr,
            ::coder::array<double, 2U> &matchedIdx)
          {
            array<int, 2U> b_ii;
            array<signed char, 2U> matchArr;
            array<boolean_T, 2U> x;
            int idx;
            int ii;
            int nx;
            boolean_T exitg1;
            matchArr.set_size(1, arr.size(1) - 2);
            ii = arr.size(1);
            for (idx = 0; idx <= ii - 3; idx++) {
              boolean_T b_x[3];
              boolean_T y;
              for (nx = 0; nx < 3; nx++) {
                b_x[nx] = arr[idx + nx];
              }

              y = true;
              nx = 0;
              exitg1 = false;
              while ((!exitg1) && (nx <= 2)) {
                if (!b_x[nx]) {
                  y = false;
                  exitg1 = true;
                } else {
                  nx++;
                }
              }

              matchArr[idx] = static_cast<signed char>(y);
            }

            x.set_size(1, matchArr.size(1));
            nx = matchArr.size(1);
            if (static_cast<int>(matchArr.size(1) < 3200)) {
              for (int i{0}; i < nx; i++) {
                x[i] = (matchArr[i] == 1);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i = 0; i < nx; i++) {
                x[i] = (matchArr[i] == 1);
              }
            }

            nx = x.size(1);
            idx = 0;
            b_ii.set_size(1, x.size(1));
            ii = 0;
            exitg1 = false;
            while ((!exitg1) && (ii <= nx - 1)) {
              if (x[ii]) {
                idx++;
                b_ii[idx - 1] = ii + 1;
                if (idx >= nx) {
                  exitg1 = true;
                } else {
                  ii++;
                }
              } else {
                ii++;
              }
            }

            if (x.size(1) == 1) {
              if (idx == 0) {
                b_ii.set_size(1, 0);
              }
            } else {
              if (idx < 1) {
                idx = 0;
              }

              b_ii.set_size(b_ii.size(0), idx);
            }

            matchedIdx.set_size(1, b_ii.size(1));
            nx = b_ii.size(1);
            if (static_cast<int>(b_ii.size(1) < 3200)) {
              for (int i{0}; i < nx; i++) {
                matchedIdx[i] = b_ii[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i = 0; i < nx; i++) {
                matchedIdx[i] = b_ii[i];
              }
            }
          }

          void Checkerboard::b_findClosestIndices(const ::coder::array<double,
            2U> &predictedPoints, ::coder::array<double, 2U> &indices) const
          {
            array<double, 2U> b_indices;
            array<double, 2U> p;
            array<double, 2U> remIdx;
            array<double, 1U> c_this;
            array<double, 1U> validBoardIdx;
            array<float, 2U> d_this;
            array<float, 2U> diffs;
            array<float, 1U> dists;
            array<int, 2U> r1;
            array<int, 1U> validPredictions;
            array<boolean_T, 2U> r2;
            array<boolean_T, 1U> r;
            float minDist;
            int b_i;
            int b_loop_ub;
            int b_this;
            int c_i;
            int c_loop_ub;
            int d_loop_ub;
            int i;
            int i1;
            int iindx;
            int loop_ub;
            int n;
            int nPrime;
            int nx;
            indices.set_size(1, predictedPoints.size(0));
            loop_ub = predictedPoints.size(0);
            i = (predictedPoints.size(0) < 3200);
            if (i) {
              for (b_this = 0; b_this < loop_ub; b_this++) {
                indices[b_this] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_this = 0; b_this < loop_ub; b_this++) {
                indices[b_this] = 0.0;
              }
            }

            nx = Points.size(0);
            if (nx < 1) {
              p.set_size(1, 0);
            } else {
              p.set_size(1, nx);
              loop_ub = nx - 1;
              if (static_cast<int>(nx < 3200)) {
                for (b_this = 0; b_this <= loop_ub; b_this++) {
                  p[b_this] = static_cast<double>(b_this) + 1.0;
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_this = 0; b_this <= loop_ub; b_this++) {
                  p[b_this] = static_cast<double>(b_this) + 1.0;
                }
              }
            }

            nx = BoardIdx.size(0) * BoardIdx.size(1);
            c_this = BoardIdx.reshape(nx);
            do_vectors(p, c_this, remIdx, validPredictions);
            if (remIdx.size(1) != 0) {
              r.set_size(predictedPoints.size(0));
              loop_ub = predictedPoints.size(0);
              if (i) {
                for (b_this = 0; b_this < loop_ub; b_this++) {
                  r[b_this] = !std::isnan(predictedPoints[b_this]);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_this = 0; b_this < loop_ub; b_this++) {
                  r[b_this] = !std::isnan(predictedPoints[b_this]);
                }
              }

              b_eml_find(r, validPredictions);
              i1 = validPredictions.size(0);
              if (validPredictions.size(0) - 1 >= 0) {
                b_loop_ub = predictedPoints.size(1);
                c_loop_ub = Points.size(1);
                n = nx;
                d_loop_ub = Points.size(1);
              }

              for (b_i = 0; b_i < i1; b_i++) {
                p.set_size(1, predictedPoints.size(1));
                for (nx = 0; nx < b_loop_ub; nx++) {
                  p[nx] = predictedPoints[(validPredictions[b_i] +
                    predictedPoints.size(0) * nx) - 1];
                }

                d_this.set_size(remIdx.size(1), Points.size(1));
                for (nx = 0; nx < c_loop_ub; nx++) {
                  loop_ub = remIdx.size(1);
                  for (c_i = 0; c_i < loop_ub; c_i++) {
                    d_this[c_i + d_this.size(0) * nx] = Points[(static_cast<int>
                      (remIdx[c_i]) + Points.size(0) * nx) - 1];
                  }
                }

                bsxfun(d_this, p, diffs);
                dists.set_size(diffs.size(0));
                nx = diffs.size(0);
                for (loop_ub = 0; loop_ub < nx; loop_ub++) {
                  dists[loop_ub] = rt_hypotf_snf(diffs[loop_ub], diffs[loop_ub +
                    diffs.size(0)]);
                }

                loop_ub = indices.size(1) - 1;
                nx = 0;
                for (c_i = 0; c_i <= loop_ub; c_i++) {
                  if (indices[c_i] > 0.0) {
                    nx++;
                  }
                }

                r1.set_size(1, nx);
                nx = 0;
                for (c_i = 0; c_i <= loop_ub; c_i++) {
                  if (indices[c_i] > 0.0) {
                    r1[nx] = c_i;
                    nx++;
                  }
                }

                loop_ub = r1.size(1);
                b_indices.set_size(1, r1.size(1));
                for (nx = 0; nx < loop_ub; nx++) {
                  b_indices[nx] = indices[r1[nx]];
                }

                isMember(remIdx, b_indices, r2);
                loop_ub = r2.size(1) - 1;
                for (c_i = 0; c_i <= loop_ub; c_i++) {
                  if (r2[c_i]) {
                    dists[c_i] = rtInfF;
                  }
                }

                minDist = ::coder::internal::minimum(dists, iindx);
                nx = 0;
                for (loop_ub = 0; loop_ub < n; loop_ub++) {
                  if (BoardIdx[loop_ub] != 0.0) {
                    nx++;
                  }
                }

                validBoardIdx.set_size(nx);
                c_i = -1;
                for (loop_ub = 0; loop_ub < n; loop_ub++) {
                  if (BoardIdx[loop_ub] != 0.0) {
                    c_i++;
                    validBoardIdx[c_i] = BoardIdx[loop_ub];
                  }
                }

                d_this.set_size(validBoardIdx.size(0), Points.size(1));
                for (nx = 0; nx < d_loop_ub; nx++) {
                  loop_ub = validBoardIdx.size(0);
                  for (c_i = 0; c_i < loop_ub; c_i++) {
                    d_this[c_i + d_this.size(0) * nx] = Points[(static_cast<int>
                      (validBoardIdx[c_i]) + Points.size(0) * nx) - 1];
                  }
                }

                bsxfun(d_this, p, diffs);
                dists.set_size(diffs.size(0));
                nx = diffs.size(0);
                for (loop_ub = 0; loop_ub < nx; loop_ub++) {
                  dists[loop_ub] = rt_hypotf_snf(diffs[loop_ub], diffs[loop_ub +
                    diffs.size(0)]);
                }

                if (minDist < ::coder::internal::minimum(dists) / 2.0F) {
                  indices[validPredictions[b_i] - 1] = remIdx[iindx - 1];
                }
              }

              n = 0;
              i1 = indices.size(1);
              if (i) {
                for (b_this = 0; b_this < i1; b_this++) {
                  if (indices[b_this] != 0.0) {
                    n++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(nPrime)

                {
                  nPrime = 0;

#pragma omp for nowait

                  for (b_this = 0; b_this < i1; b_this++) {
                    if (indices[b_this] != 0.0) {
                      nPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    n += nPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              if (n < 4) {
                loop_ub = indices.size(1) - 1;
                if (i) {
                  for (b_this = 0; b_this <= loop_ub; b_this++) {
                    if (indices[b_this] > 0.0) {
                      indices[b_this] = 0.0;
                    }
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_this = 0; b_this <= loop_ub; b_this++) {
                    if (indices[b_this] > 0.0) {
                      indices[b_this] = 0.0;
                    }
                  }
                }
              }
            }
          }

          void Checkerboard::b_findIndependentVar(double coordsToUse[2]) const
          {
            array<double, 1U> b_x;
            array<double, 1U> x;
            array<int, 1U> r1;
            array<boolean_T, 1U> r;
            int b_i;
            int end;
            int i;
            int loop_ub;
            int trueCountPrime;
            r.set_size(BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                r[b_i] = ((BoardIdx[b_i] > 0.0) && (BoardIdx[b_i + BoardIdx.size
                           (0)] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                r[b_i] = ((BoardIdx[b_i] > 0.0) && (BoardIdx[b_i + BoardIdx.size
                           (0)] > 0.0));
              }
            }

            end = r.size(0) - 1;
            loop_ub = 0;
            if (i) {
              for (b_i = 0; b_i <= end; b_i++) {
                if (r[b_i]) {
                  loop_ub++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= end; b_i++) {
                  if (r[b_i]) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  loop_ub += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r1.set_size(loop_ub);
            loop_ub = 0;
            for (i = 0; i <= end; i++) {
              if (r[i]) {
                r1[loop_ub] = i;
                loop_ub++;
              }
            }

            x.set_size(r1.size(0));
            loop_ub = r1.size(0);
            b_x.set_size(r1.size(0));
            if (static_cast<int>(r1.size(0) < 3200)) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                x[b_i] = BoardCoords[r1[b_i] + BoardCoords.size(0)] -
                  BoardCoords[r1[b_i]];
                b_x[b_i] = BoardCoords[(r1[b_i] + BoardCoords.size(0)) +
                  BoardCoords.size(0) * BoardCoords.size(1)] -
                  BoardCoords[r1[b_i] + BoardCoords.size(0) * BoardCoords.size(1)];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                x[b_i] = BoardCoords[r1[b_i] + BoardCoords.size(0)] -
                  BoardCoords[r1[b_i]];
                b_x[b_i] = BoardCoords[(r1[b_i] + BoardCoords.size(0)) +
                  BoardCoords.size(0) * BoardCoords.size(1)] -
                  BoardCoords[r1[b_i] + BoardCoords.size(0) * BoardCoords.size(1)];
              }
            }

            if (std::abs(combineVectorElements(x) / static_cast<double>(x.size(0)))
                > std::abs(combineVectorElements(b_x) / static_cast<double>
                           (b_x.size(0)))) {
              coordsToUse[0] = 1.0;
              coordsToUse[1] = 2.0;
            } else {
              coordsToUse[0] = 2.0;
              coordsToUse[1] = 1.0;
            }
          }

          void Checkerboard::b_findIndependentVar(const ::coder::array<double,
            2U> &idx, double coordsToUse[2]) const
          {
            array<double, 1U> b_x;
            array<double, 1U> x;
            array<int, 1U> r1;
            array<boolean_T, 1U> r;
            int b_i;
            int b_idx_tmp;
            int end;
            int i;
            int idx_tmp;
            int loop_ub;
            int trueCountPrime;
            idx_tmp = static_cast<int>(idx[0]);
            b_idx_tmp = static_cast<int>(idx[1]);
            r.set_size(BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                r[b_i] = ((BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)] >
                           0.0) && (BoardIdx[b_i + BoardIdx.size(0) * (b_idx_tmp
                            - 1)] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                r[b_i] = ((BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)] >
                           0.0) && (BoardIdx[b_i + BoardIdx.size(0) * (b_idx_tmp
                            - 1)] > 0.0));
              }
            }

            end = r.size(0) - 1;
            loop_ub = 0;
            if (i) {
              for (b_i = 0; b_i <= end; b_i++) {
                if (r[b_i]) {
                  loop_ub++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= end; b_i++) {
                  if (r[b_i]) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  loop_ub += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r1.set_size(loop_ub);
            loop_ub = 0;
            for (i = 0; i <= end; i++) {
              if (r[i]) {
                r1[loop_ub] = i;
                loop_ub++;
              }
            }

            x.set_size(r1.size(0));
            loop_ub = r1.size(0);
            b_x.set_size(r1.size(0));
            if (static_cast<int>(r1.size(0) < 3200)) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                x[b_i] = BoardCoords[r1[b_i] + BoardCoords.size(0) * (b_idx_tmp
                  - 1)] - BoardCoords[r1[b_i] + BoardCoords.size(0) * (idx_tmp -
                  1)];
                b_x[b_i] = BoardCoords[(r1[b_i] + BoardCoords.size(0) *
                  (b_idx_tmp - 1)) + BoardCoords.size(0) * BoardCoords.size(1)]
                  - BoardCoords[(r1[b_i] + BoardCoords.size(0) * (idx_tmp - 1))
                  + BoardCoords.size(0) * BoardCoords.size(1)];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                x[b_i] = BoardCoords[r1[b_i] + BoardCoords.size(0) * (b_idx_tmp
                  - 1)] - BoardCoords[r1[b_i] + BoardCoords.size(0) * (idx_tmp -
                  1)];
                b_x[b_i] = BoardCoords[(r1[b_i] + BoardCoords.size(0) *
                  (b_idx_tmp - 1)) + BoardCoords.size(0) * BoardCoords.size(1)]
                  - BoardCoords[(r1[b_i] + BoardCoords.size(0) * (idx_tmp - 1))
                  + BoardCoords.size(0) * BoardCoords.size(1)];
              }
            }

            if (std::abs(combineVectorElements(x) / static_cast<double>(x.size(0)))
                > std::abs(combineVectorElements(b_x) / static_cast<double>
                           (b_x.size(0)))) {
              coordsToUse[0] = 1.0;
              coordsToUse[1] = 2.0;
            } else {
              coordsToUse[0] = 2.0;
              coordsToUse[1] = 1.0;
            }
          }

          void Checkerboard::b_fitPolynomialIndices(::coder::array<double, 2U>
            &newIndices) const
          {
            array<double, 2U> b_index;
            array<double, 2U> b_this;
            array<double, 2U> removedIdx;
            array<int, 2U> validIdx;
            array<int, 1U> currCurve_tmp;
            double currCurve_data[5];
            double coordsToUse[2];
            int i1;
            int loop_ub;
            b_findIndependentVar(coordsToUse);
            newIndices.set_size(1, BoardCoords.size(0));
            loop_ub = BoardCoords.size(0);
            if (static_cast<int>(loop_ub < 3200)) {
              for (int i{0}; i < loop_ub; i++) {
                newIndices[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i = 0; i < loop_ub; i++) {
                newIndices[i] = 0.0;
              }
            }

            removedIdx.set_size(1, 0);
            i1 = BoardCoords.size(0);
            for (int j{0}; j < i1; j++) {
              int i2;
              b_index.set_size(1, BoardCoords.size(1));
              loop_ub = BoardCoords.size(1);
              for (i2 = 0; i2 < loop_ub; i2++) {
                b_index[i2] = BoardCoords[(j + BoardCoords.size(0) * i2) +
                  BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                  (coordsToUse[0]) - 1)];
              }

              eml_find(b_index, validIdx);
              if (validIdx.size(1) >= 2) {
                double coordDist;
                double coordDist_tmp;
                double currCoord;
                double currRad;
                int currCurve_size[2];
                int b_coordDist_tmp;
                int n;
                boolean_T exitg1;
                currRad = coordsToUse[0];
                coordDist_tmp = BoardCoords[(j + BoardCoords.size(0) *
                  (validIdx[0] - 1)) + BoardCoords.size(0) * BoardCoords.size(1)
                  * (static_cast<int>(coordsToUse[0]) - 1)];
                b_coordDist_tmp = validIdx[0];
                coordDist = (coordDist_tmp - BoardCoords[(j + BoardCoords.size(0)
                  * (validIdx[1] - 1)) + BoardCoords.size(0) * BoardCoords.size
                             (1) * (static_cast<int>(coordsToUse[0]) - 1)]) / (
                  static_cast<double>(validIdx[1]) - static_cast<double>
                  (b_coordDist_tmp));
                n = 0;
                i2 = validIdx.size(1);
                for (loop_ub = 0; loop_ub < i2; loop_ub++) {
                  if (validIdx[loop_ub] != 0) {
                    n++;
                  }
                }

                currCurve_tmp.set_size(validIdx.size(1));
                loop_ub = validIdx.size(1);
                for (i2 = 0; i2 < loop_ub; i2++) {
                  currCurve_tmp[i2] = validIdx[i2];
                }

                b_index.set_size(1, currCurve_tmp.size(0));
                loop_ub = currCurve_tmp.size(0);
                b_this.set_size(1, currCurve_tmp.size(0));
                for (i2 = 0; i2 < loop_ub; i2++) {
                  b_index[i2] = BoardCoords[(j + BoardCoords.size(0) *
                    (currCurve_tmp[i2] - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * (static_cast<int>(currRad) - 1)];
                  b_this[i2] = BoardCoords[(j + BoardCoords.size(0) *
                    (currCurve_tmp[i2] - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * (static_cast<int>(coordsToUse[1]) - 1)];
                }

                if (n > 5) {
                  i2 = 4;
                } else {
                  i2 = 2;
                }

                polyfit(b_index, b_this, static_cast<double>(i2), currCurve_data,
                        currCurve_size);
                currRad = coordDist / 4.0;
                currCoord = currRad + coordDist_tmp;
                exitg1 = false;
                while ((!exitg1) && (std::abs(currCoord - coordDist_tmp) <
                                     static_cast<double>(b_coordDist_tmp) * 1.5 *
                                     std::abs(coordDist))) {
                  double currPt[2];
                  boolean_T exitg2;
                  boolean_T p;
                  p = true;
                  loop_ub = 0;
                  exitg2 = false;
                  while ((!exitg2) && (loop_ub < 2)) {
                    if (!(coordsToUse[loop_ub] == static_cast<double>(loop_ub) +
                          1.0)) {
                      p = false;
                      exitg2 = true;
                    } else {
                      loop_ub++;
                    }
                  }

                  if (p) {
                    double y;
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (loop_ub = 0; loop_ub <= i2 - 2; loop_ub++) {
                      y = currCoord * y + currCurve_data[loop_ub + 1];
                    }

                    currPt[0] = currCoord;
                    currPt[1] = y;
                  } else {
                    double y;
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (loop_ub = 0; loop_ub <= i2 - 2; loop_ub++) {
                      y = currCoord * y + currCurve_data[loop_ub + 1];
                    }

                    currPt[0] = y;
                    currPt[1] = currCoord;
                  }

                  findClosestOnCurve(currPt, std::abs(currRad), currCurve_data,
                                     currCurve_size, coordsToUse, removedIdx,
                                     b_index);
                  if (b_index.size(1) != 0) {
                    newIndices[j] = b_index[0];
                    i2 = removedIdx.size(1);
                    loop_ub = b_index.size(1);
                    removedIdx.set_size(removedIdx.size(0), removedIdx.size(1) +
                                        b_index.size(1));
                    for (b_coordDist_tmp = 0; b_coordDist_tmp < loop_ub;
                         b_coordDist_tmp++) {
                      removedIdx[i2 + b_coordDist_tmp] = b_index[b_coordDist_tmp];
                    }

                    exitg1 = true;
                  } else {
                    currCoord += currRad;
                  }
                }
              }
            }
          }

          void Checkerboard::c_fitPolynomialIndices(::coder::array<double, 2U>
            &newIndices) const
          {
            array<double, 2U> b_index;
            array<double, 2U> removedIdx;
            array<double, 1U> b_this;
            array<double, 1U> c_this;
            array<int, 1U> validIdx;
            double currCurve_data[5];
            double coordsToUse[2];
            double currPt[2];
            double coordDist;
            double coordDist_tmp;
            double currCoord;
            double currRad;
            double y;
            int currCurve_size[2];
            int b_k;
            int i;
            int i1;
            int i2;
            int j;
            int k;
            int loop_ub;
            int nPrime;
            boolean_T exitg1;
            boolean_T exitg2;
            boolean_T p;
            findIndependentVar(coordsToUse);
            newIndices.set_size(1, BoardCoords.size(1));
            loop_ub = BoardCoords.size(1);
            i = (loop_ub < 3200);
            if (i) {
              for (k = 0; k < loop_ub; k++) {
                newIndices[k] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (k = 0; k < loop_ub; k++) {
                newIndices[k] = 0.0;
              }
            }

            removedIdx.set_size(1, 0);
            i1 = BoardCoords.size(1);
            for (j = 0; j < i1; j++) {
              b_this.set_size(BoardCoords.size(0));
              loop_ub = BoardCoords.size(0);
              for (i2 = 0; i2 < loop_ub; i2++) {
                b_this[i2] = BoardCoords[(i2 + BoardCoords.size(0) * j) +
                  BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                  (coordsToUse[0]) - 1)];
              }

              eml_find(b_this, validIdx);
              if (validIdx.size(0) >= 2) {
                currRad = coordsToUse[0];
                coordDist_tmp = BoardCoords[((validIdx[0] + BoardCoords.size(0) *
                  j) + BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<
                  int>(coordsToUse[0]) - 1)) - 1];
                coordDist = (coordDist_tmp - BoardCoords[((validIdx[1] +
                  BoardCoords.size(0) * j) + BoardCoords.size(0) *
                  BoardCoords.size(1) * (static_cast<int>(coordsToUse[0]) - 1))
                             - 1]) / (static_cast<double>(validIdx[1]) -
                                      static_cast<double>(validIdx[0]));
                loop_ub = 0;
                i2 = validIdx.size(0);
                b_this.set_size(validIdx.size(0));
                c_this.set_size(validIdx.size(0));
                for (b_k = 0; b_k < i2; b_k++) {
                  if (validIdx[b_k] != 0) {
                    loop_ub++;
                  }

                  b_this[b_k] = BoardCoords[((validIdx[b_k] + BoardCoords.size(0)
                    * j) + BoardCoords.size(0) * BoardCoords.size(1) * (
                    static_cast<int>(currRad) - 1)) - 1];
                  c_this[b_k] = BoardCoords[((validIdx[b_k] + BoardCoords.size(0)
                    * j) + BoardCoords.size(0) * BoardCoords.size(1) * (
                    static_cast<int>(coordsToUse[1]) - 1)) - 1];
                }

                if (loop_ub > 5) {
                  i2 = 4;
                } else {
                  i2 = 2;
                }

                polyfit(b_this, c_this, static_cast<double>(i2), currCurve_data,
                        currCurve_size);
                currRad = coordDist / 4.0;
                currCoord = currRad + coordDist_tmp;
                exitg1 = false;
                while ((!exitg1) && (std::abs(currCoord - coordDist_tmp) <
                                     static_cast<double>(validIdx[0]) * 1.5 *
                                     std::abs(coordDist))) {
                  p = true;
                  b_k = 0;
                  exitg2 = false;
                  while ((!exitg2) && (b_k < 2)) {
                    if (!(coordsToUse[b_k] == static_cast<double>(b_k) + 1.0)) {
                      p = false;
                      exitg2 = true;
                    } else {
                      b_k++;
                    }
                  }

                  if (p) {
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (b_k = 0; b_k <= i2 - 2; b_k++) {
                      y = currCoord * y + currCurve_data[b_k + 1];
                    }

                    currPt[0] = currCoord;
                    currPt[1] = y;
                  } else {
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (b_k = 0; b_k <= i2 - 2; b_k++) {
                      y = currCoord * y + currCurve_data[b_k + 1];
                    }

                    currPt[0] = y;
                    currPt[1] = currCoord;
                  }

                  findClosestOnCurve(currPt, std::abs(currRad), currCurve_data,
                                     currCurve_size, coordsToUse, removedIdx,
                                     b_index);
                  if (b_index.size(1) != 0) {
                    newIndices[j] = b_index[0];
                    i2 = removedIdx.size(1);
                    loop_ub = b_index.size(1);
                    removedIdx.set_size(removedIdx.size(0), removedIdx.size(1) +
                                        b_index.size(1));
                    for (b_k = 0; b_k < loop_ub; b_k++) {
                      removedIdx[i2 + b_k] = b_index[b_k];
                    }

                    exitg1 = true;
                  } else {
                    currCoord += currRad;
                  }
                }
              }
            }

            loop_ub = 0;
            i1 = newIndices.size(1);
            if (i) {
              for (k = 0; k < i1; k++) {
                if (newIndices[k] != 0.0) {
                  loop_ub++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(nPrime)

              {
                nPrime = 0;

#pragma omp for nowait

                for (k = 0; k < i1; k++) {
                  if (newIndices[k] != 0.0) {
                    nPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  loop_ub += nPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            if (loop_ub < 4) {
              loop_ub = newIndices.size(1) - 1;
              if (i) {
                for (k = 0; k <= loop_ub; k++) {
                  if (newIndices[k] > 0.0) {
                    newIndices[k] = 0.0;
                  }
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (k = 0; k <= loop_ub; k++) {
                  if (newIndices[k] > 0.0) {
                    newIndices[k] = 0.0;
                  }
                }
              }
            }
          }

          float Checkerboard::computeInitialEnergy() const
          {
            array<float, 2U> col1;
            array<float, 2U> col2;
            array<float, 2U> row3;
            array<boolean_T, 1U> x;
            float e;
            int ix;
            int loop_ub;
            boolean_T exitg1;
            boolean_T y;
            loop_ub = BoardIdx.size(0) * BoardIdx.size(1);
            x.set_size(loop_ub);
            if (static_cast<int>(loop_ub < 3200)) {
              for (int i{0}; i < loop_ub; i++) {
                x[i] = (BoardIdx[i] < 0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i = 0; i < loop_ub; i++) {
                x[i] = (BoardIdx[i] < 0.0);
              }
            }

            y = false;
            ix = 1;
            exitg1 = false;
            while ((!exitg1) && (ix <= x.size(0))) {
              if (x[ix - 1]) {
                y = true;
                exitg1 = true;
              } else {
                ix++;
              }
            }

            if (y) {
              e = rtInfF;
            } else {
              float b_x[3];
              float c_x[3];
              float y_idx_0;
              float y_idx_1;
              float y_idx_2;
              int i1;
              col1.set_size(3, Points.size(1));
              ix = Points.size(1);
              col2.set_size(3, Points.size(1));
              row3.set_size(3, Points.size(1));
              i1 = (ix * 3 < 3200);
              if (i1) {
                for (int i{0}; i < ix; i++) {
                  col1[3 * i] = Points[(static_cast<int>(BoardIdx[0]) +
                                        Points.size(0) * i) - 1];
                  col2[3 * i] = Points[(static_cast<int>(BoardIdx[1]) +
                                        Points.size(0) * i) - 1];
                  row3[3 * i] = Points[(static_cast<int>(BoardIdx[2]) +
                                        Points.size(0) * i) - 1];
                  col1[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0)]) + Points.size(0) * i) - 1];
                  col2[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 1]) + Points.size(0) * i) - 1];
                  row3[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 2]) + Points.size(0) * i) - 1];
                  col1[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2]) + Points.size(0) * i) - 1];
                  col2[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 1]) + Points.size(0) * i) -
                    1];
                  row3[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 2]) + Points.size(0) * i) -
                    1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int i = 0; i < ix; i++) {
                  col1[3 * i] = Points[(static_cast<int>(BoardIdx[0]) +
                                        Points.size(0) * i) - 1];
                  col2[3 * i] = Points[(static_cast<int>(BoardIdx[1]) +
                                        Points.size(0) * i) - 1];
                  row3[3 * i] = Points[(static_cast<int>(BoardIdx[2]) +
                                        Points.size(0) * i) - 1];
                  col1[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0)]) + Points.size(0) * i) - 1];
                  col2[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 1]) + Points.size(0) * i) - 1];
                  row3[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 2]) + Points.size(0) * i) - 1];
                  col1[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2]) + Points.size(0) * i) - 1];
                  col2[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 1]) + Points.size(0) * i) -
                    1];
                  row3[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 2]) + Points.size(0) * i) -
                    1];
                }
              }

              if (col1.size(1) == 1) {
                ix = row3.size(1);
              } else {
                ix = col1.size(1);
              }

              y = ((col1.size(1) == row3.size(1)) && (ix == col2.size(1)));
              if (y) {
                ix = 3 * col1.size(1);
                col2.set_size(3, col1.size(1));
                if (i1) {
                  for (int i{0}; i < ix; i++) {
                    col2[i] = (col1[i] + row3[i]) - 2.0F * col2[i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int i = 0; i < ix; i++) {
                    col2[i] = (col1[i] + row3[i]) - 2.0F * col2[i];
                  }
                }
              } else {
                c_binary_expand_op(col2, col1, row3);
              }

              if (col1.size(1) == row3.size(1)) {
                ix = 3 * col1.size(1);
                col1.set_size(3, col1.size(1));
                if (static_cast<int>(ix < 3200)) {
                  for (int i{0}; i < ix; i++) {
                    col1[i] = col1[i] - row3[i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int i = 0; i < ix; i++) {
                    col1[i] = col1[i] - row3[i];
                  }
                }
              } else {
                minus(col1, row3);
              }

              b_x[0] = rt_hypotf_snf(col2[0], col2[3]);
              y_idx_0 = rt_hypotf_snf(col1[0], col1[3]);
              b_x[1] = rt_hypotf_snf(col2[1], col2[4]);
              y_idx_1 = rt_hypotf_snf(col1[1], col1[4]);
              b_x[2] = rt_hypotf_snf(col2[2], col2[5]);
              y_idx_2 = rt_hypotf_snf(col1[2], col1[5]);
              col1.set_size(3, Points.size(1));
              ix = Points.size(1);
              col2.set_size(3, Points.size(1));
              row3.set_size(3, Points.size(1));
              if (i1) {
                for (int i{0}; i < ix; i++) {
                  col1[3 * i] = Points[(static_cast<int>(BoardIdx[0]) +
                                        Points.size(0) * i) - 1];
                  col2[3 * i] = Points[(static_cast<int>(BoardIdx[BoardIdx.size
                    (0)]) + Points.size(0) * i) - 1];
                  row3[3 * i] = Points[(static_cast<int>(BoardIdx[BoardIdx.size
                    (0) * 2]) + Points.size(0) * i) - 1];
                  col1[3 * i + 1] = Points[(static_cast<int>(BoardIdx[1]) +
                    Points.size(0) * i) - 1];
                  col2[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 1]) + Points.size(0) * i) - 1];
                  row3[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 1]) + Points.size(0) * i) -
                    1];
                  col1[3 * i + 2] = Points[(static_cast<int>(BoardIdx[2]) +
                    Points.size(0) * i) - 1];
                  col2[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 2]) + Points.size(0) * i) - 1];
                  row3[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 2]) + Points.size(0) * i) -
                    1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int i = 0; i < ix; i++) {
                  col1[3 * i] = Points[(static_cast<int>(BoardIdx[0]) +
                                        Points.size(0) * i) - 1];
                  col2[3 * i] = Points[(static_cast<int>(BoardIdx[BoardIdx.size
                    (0)]) + Points.size(0) * i) - 1];
                  row3[3 * i] = Points[(static_cast<int>(BoardIdx[BoardIdx.size
                    (0) * 2]) + Points.size(0) * i) - 1];
                  col1[3 * i + 1] = Points[(static_cast<int>(BoardIdx[1]) +
                    Points.size(0) * i) - 1];
                  col2[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 1]) + Points.size(0) * i) - 1];
                  row3[3 * i + 1] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 1]) + Points.size(0) * i) -
                    1];
                  col1[3 * i + 2] = Points[(static_cast<int>(BoardIdx[2]) +
                    Points.size(0) * i) - 1];
                  col2[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) + 2]) + Points.size(0) * i) - 1];
                  row3[3 * i + 2] = Points[(static_cast<int>
                    (BoardIdx[BoardIdx.size(0) * 2 + 2]) + Points.size(0) * i) -
                    1];
                }
              }

              if (y) {
                ix = 3 * col1.size(1);
                col2.set_size(3, col1.size(1));
                if (i1) {
                  for (int i{0}; i < ix; i++) {
                    col2[i] = (col1[i] + row3[i]) - 2.0F * col2[i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int i = 0; i < ix; i++) {
                    col2[i] = (col1[i] + row3[i]) - 2.0F * col2[i];
                  }
                }
              } else {
                c_binary_expand_op(col2, col1, row3);
              }

              if (col1.size(1) == row3.size(1)) {
                ix = 3 * col1.size(1);
                col1.set_size(3, col1.size(1));
                if (static_cast<int>(ix < 3200)) {
                  for (int i{0}; i < ix; i++) {
                    col1[i] = col1[i] - row3[i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int i = 0; i < ix; i++) {
                    col1[i] = col1[i] - row3[i];
                  }
                }
              } else {
                minus(col1, row3);
              }

              b_x[0] /= y_idx_0;
              c_x[0] = rt_hypotf_snf(col2[0], col2[3]) / rt_hypotf_snf(col1[0],
                col1[3]);
              b_x[1] /= y_idx_1;
              c_x[1] = rt_hypotf_snf(col2[1], col2[4]) / rt_hypotf_snf(col1[1],
                col1[4]);
              b_x[2] /= y_idx_2;
              c_x[2] = rt_hypotf_snf(col2[2], col2[5]) / rt_hypotf_snf(col1[2],
                col1[5]);
              e = static_cast<float>(loop_ub) * std::fmax(std::fmax(0.0F, ::
                coder::internal::maximum(b_x)), ::coder::internal::maximum(c_x))
                - static_cast<float>(loop_ub);
            }

            return e;
          }

          float Checkerboard::computeNewEnergyHorizontal(const ::coder::array<
            double, 2U> &idx, float oldEnergy) const
          {
            array<double, 3U> b_denom;
            array<double, 3U> b_num;
            array<double, 3U> c_this;
            array<double, 2U> denom;
            array<double, 2U> num;
            array<double, 2U> validNewColIdx;
            array<double, 1U> b_r;
            array<double, 1U> c_r;
            array<int, 1U> r;
            array<boolean_T, 2U> b_this;
            array<boolean_T, 1U> validIdx;
            double b_num_tmp;
            double d;
            double num_tmp;
            float newEnergy;
            float newEnergy_tmp;
            int b_i;
            int b_idx_tmp;
            int c_i;
            int c_idx_tmp;
            int end;
            int i;
            int i1;
            int idx_tmp;
            int loop_ub;
            int nx;
            int trueCountPrime;
            boolean_T exitg1;
            boolean_T y;
            idx_tmp = static_cast<int>(idx[0]);
            b_idx_tmp = static_cast<int>(idx[1]);
            c_idx_tmp = static_cast<int>(idx[2]);
            validIdx.set_size(BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)]
                                  > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  (b_idx_tmp - 1)] > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  (c_idx_tmp - 1)] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)]
                                  > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  (b_idx_tmp - 1)] > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  (c_idx_tmp - 1)] > 0.0));
              }
            }

            newEnergy = 0.0F;
            y = false;
            nx = 1;
            exitg1 = false;
            while ((!exitg1) && (nx <= validIdx.size(0))) {
              if (validIdx[nx - 1]) {
                y = true;
                exitg1 = true;
              } else {
                nx++;
              }
            }

            if (y) {
              end = validIdx.size(0) - 1;
              nx = 0;
              if (i) {
                for (b_i = 0; b_i <= end; b_i++) {
                  if (validIdx[b_i]) {
                    nx++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (b_i = 0; b_i <= end; b_i++) {
                    if (validIdx[b_i]) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    nx += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              r.set_size(nx);
              nx = 0;
              for (c_i = 0; c_i <= end; c_i++) {
                if (validIdx[c_i]) {
                  r[nx] = c_i;
                  nx++;
                }
              }

              c_this.set_size(r.size(0), 1, BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(0);
                for (end = 0; end < nx; end++) {
                  c_this[end + c_this.size(0) * i1] = (BoardCoords[(r[end] +
                    BoardCoords.size(0) * (idx_tmp - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1] + BoardCoords[(r[end] +
                    BoardCoords.size(0) * (c_idx_tmp - 1)) + BoardCoords.size(0)
                    * BoardCoords.size(1) * i1]) - 2.0 * BoardCoords[(r[end] +
                    BoardCoords.size(0) * (b_idx_tmp - 1)) + BoardCoords.size(0)
                    * BoardCoords.size(1) * i1];
                }
              }

              b_squeeze(c_this, num);
              c_this.set_size(r.size(0), 1, BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(0);
                for (end = 0; end < nx; end++) {
                  c_this[end + c_this.size(0) * i1] = BoardCoords[(r[end] +
                    BoardCoords.size(0) * (idx_tmp - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1] - BoardCoords[(r[end] +
                    BoardCoords.size(0) * (c_idx_tmp - 1)) + BoardCoords.size(0)
                    * BoardCoords.size(1) * i1];
                }
              }

              b_squeeze(c_this, denom);
              if (num.size(1) > 1) {
                b_r.set_size(num.size(0));
                nx = num.size(0);
                i1 = (num.size(0) < 3200);
                if (i1) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                }

                c_r.set_size(denom.size(0));
                nx = denom.size(0);
                if (static_cast<int>(denom.size(0) < 3200)) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(denom[b_i], denom[b_i + denom.size
                      (0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(denom[b_i], denom[b_i + denom.size
                      (0)]);
                  }
                }

                if (b_r.size(0) == c_r.size(0)) {
                  loop_ub = b_r.size(0);
                  if (i1) {
                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  }

                  newEnergy = std::fmax(oldEnergy, static_cast<float>(::coder::
                    internal::maximum(b_r)));
                } else {
                  newEnergy = binary_expand_op(oldEnergy, b_r, c_r);
                }
              } else {
                newEnergy = std::fmax(oldEnergy, static_cast<float>
                                      (rt_hypotd_snf(num[0], num[1]) /
                  rt_hypotd_snf(denom[0], denom[1])));
              }
            }

            b_this.set_size(1, BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                b_this[b_i] = (BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)] >
                               0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                b_this[b_i] = (BoardIdx[b_i + BoardIdx.size(0) * (idx_tmp - 1)] >
                               0.0);
              }
            }

            Checkerboard::arrayFind(b_this, validNewColIdx);
            if (validNewColIdx.size(1) != 0) {
              i = validNewColIdx.size(1);
              loop_ub = BoardCoords.size(2);
              i1 = BoardCoords.size(2);
              for (c_i = 0; c_i < i; c_i++) {
                d = validNewColIdx[c_i];
                b_num.set_size(1, 1, i1);
                b_denom.set_size(1, 1, i1);
                for (end = 0; end < loop_ub; end++) {
                  num_tmp = BoardCoords[((static_cast<int>(d) + BoardCoords.size
                    (0) * (idx_tmp - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * end) - 1];
                  b_num_tmp = BoardCoords[((static_cast<int>(d + 2.0) +
                    BoardCoords.size(0) * (idx_tmp - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * end) - 1];
                  b_num[end] = (num_tmp + b_num_tmp) - 2.0 * BoardCoords[((
                    static_cast<int>(d + 1.0) + BoardCoords.size(0) * (idx_tmp -
                    1)) + BoardCoords.size(0) * BoardCoords.size(1) * end) - 1];
                  b_denom[end] = num_tmp - b_num_tmp;
                }

                if (newEnergy != 0.0F) {
                  nx = b_num.size(2);
                  end = b_denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = b_denom.reshape(end);
                  newEnergy = std::fmax(newEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                } else {
                  nx = b_num.size(2);
                  end = b_denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = b_denom.reshape(end);
                  newEnergy = std::fmax(oldEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                }
              }
            }

            newEnergy_tmp = static_cast<float>(BoardIdx.size(0) * BoardIdx.size
              (1));
            if (newEnergy != 0.0F) {
              newEnergy = newEnergy * newEnergy_tmp - newEnergy_tmp;
            } else {
              newEnergy = rtInfF;
            }

            return newEnergy;
          }

          float Checkerboard::computeNewEnergyHorizontal(float oldEnergy) const
          {
            array<double, 3U> b_denom;
            array<double, 3U> b_num;
            array<double, 3U> c_this;
            array<double, 2U> denom;
            array<double, 2U> num;
            array<double, 2U> validNewColIdx;
            array<double, 1U> b_r;
            array<double, 1U> c_r;
            array<int, 1U> r;
            array<boolean_T, 2U> b_this;
            array<boolean_T, 1U> validIdx;
            double b_num_tmp;
            double d;
            double num_tmp;
            float newEnergy;
            float newEnergy_tmp;
            int b_i;
            int c_i;
            int end;
            int i;
            int i1;
            int loop_ub;
            int nx;
            int trueCountPrime;
            boolean_T exitg1;
            boolean_T y;
            validIdx.set_size(BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[b_i] > 0.0) && (BoardIdx[b_i +
                  BoardIdx.size(0)] > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  2] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[b_i] > 0.0) && (BoardIdx[b_i +
                  BoardIdx.size(0)] > 0.0) && (BoardIdx[b_i + BoardIdx.size(0) *
                  2] > 0.0));
              }
            }

            newEnergy = 0.0F;
            y = false;
            nx = 1;
            exitg1 = false;
            while ((!exitg1) && (nx <= validIdx.size(0))) {
              if (validIdx[nx - 1]) {
                y = true;
                exitg1 = true;
              } else {
                nx++;
              }
            }

            if (y) {
              end = validIdx.size(0) - 1;
              nx = 0;
              if (i) {
                for (b_i = 0; b_i <= end; b_i++) {
                  if (validIdx[b_i]) {
                    nx++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (b_i = 0; b_i <= end; b_i++) {
                    if (validIdx[b_i]) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    nx += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              r.set_size(nx);
              nx = 0;
              for (c_i = 0; c_i <= end; c_i++) {
                if (validIdx[c_i]) {
                  r[nx] = c_i;
                  nx++;
                }
              }

              c_this.set_size(r.size(0), 1, BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(0);
                for (end = 0; end < nx; end++) {
                  c_this[end + c_this.size(0) * i1] = (BoardCoords[r[end] +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1] +
                    BoardCoords[(r[end] + BoardCoords.size(0) * 2) +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1]) - 2.0 *
                    BoardCoords[(r[end] + BoardCoords.size(0)) +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1];
                }
              }

              b_squeeze(c_this, num);
              c_this.set_size(r.size(0), 1, BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(0);
                for (end = 0; end < nx; end++) {
                  c_this[end + c_this.size(0) * i1] = BoardCoords[r[end] +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1] -
                    BoardCoords[(r[end] + BoardCoords.size(0) * 2) +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1];
                }
              }

              b_squeeze(c_this, denom);
              if (num.size(1) > 1) {
                b_r.set_size(num.size(0));
                nx = num.size(0);
                i1 = (num.size(0) < 3200);
                if (i1) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                }

                c_r.set_size(denom.size(0));
                nx = denom.size(0);
                if (static_cast<int>(denom.size(0) < 3200)) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(denom[b_i], denom[b_i + denom.size
                      (0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(denom[b_i], denom[b_i + denom.size
                      (0)]);
                  }
                }

                if (b_r.size(0) == c_r.size(0)) {
                  loop_ub = b_r.size(0);
                  if (i1) {
                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  }

                  newEnergy = std::fmax(oldEnergy, static_cast<float>(::coder::
                    internal::maximum(b_r)));
                } else {
                  newEnergy = binary_expand_op(oldEnergy, b_r, c_r);
                }
              } else {
                newEnergy = std::fmax(oldEnergy, static_cast<float>
                                      (rt_hypotd_snf(num[0], num[1]) /
                  rt_hypotd_snf(denom[0], denom[1])));
              }
            }

            b_this.set_size(1, BoardIdx.size(0));
            loop_ub = BoardIdx.size(0);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                b_this[b_i] = (BoardIdx[b_i] > 0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                b_this[b_i] = (BoardIdx[b_i] > 0.0);
              }
            }

            Checkerboard::arrayFind(b_this, validNewColIdx);
            if (validNewColIdx.size(1) != 0) {
              i = validNewColIdx.size(1);
              loop_ub = BoardCoords.size(2);
              i1 = BoardCoords.size(2);
              for (c_i = 0; c_i < i; c_i++) {
                d = validNewColIdx[c_i];
                b_num.set_size(1, 1, i1);
                b_denom.set_size(1, 1, i1);
                for (end = 0; end < loop_ub; end++) {
                  num_tmp = BoardCoords[(static_cast<int>(d) + BoardCoords.size
                    (0) * BoardCoords.size(1) * end) - 1];
                  b_num_tmp = BoardCoords[(static_cast<int>(d + 2.0) +
                    BoardCoords.size(0) * BoardCoords.size(1) * end) - 1];
                  b_num[end] = (num_tmp + b_num_tmp) - 2.0 * BoardCoords[(
                    static_cast<int>(d + 1.0) + BoardCoords.size(0) *
                    BoardCoords.size(1) * end) - 1];
                  b_denom[end] = num_tmp - b_num_tmp;
                }

                if (newEnergy != 0.0F) {
                  nx = b_num.size(2);
                  end = b_denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = b_denom.reshape(end);
                  newEnergy = std::fmax(newEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                } else {
                  nx = b_num.size(2);
                  end = b_denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = b_denom.reshape(end);
                  newEnergy = std::fmax(oldEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                }
              }
            }

            newEnergy_tmp = static_cast<float>(BoardIdx.size(0) * BoardIdx.size
              (1));
            if (newEnergy != 0.0F) {
              newEnergy = newEnergy * newEnergy_tmp - newEnergy_tmp;
            } else {
              newEnergy = rtInfF;
            }

            return newEnergy;
          }

          float Checkerboard::computeNewEnergyVertical(float oldEnergy) const
          {
            array<double, 3U> b;
            array<double, 3U> b_num;
            array<double, 3U> denom;
            array<double, 3U> r1;
            array<double, 3U> r2;
            array<double, 3U> r3;
            array<double, 2U> b_denom;
            array<double, 2U> num;
            array<double, 2U> validNewRowIdx;
            array<double, 1U> b_r;
            array<double, 1U> c_r;
            array<int, 2U> r;
            array<boolean_T, 2U> validIdx;
            double b_num_tmp;
            double d;
            double num_tmp;
            float newEnergy;
            float newEnergy_tmp;
            int b_i;
            int c_i;
            int end;
            int i;
            int i1;
            int i2;
            int loop_ub;
            int nx;
            int trueCountPrime;
            boolean_T exitg1;
            boolean_T y;
            validIdx.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[BoardIdx.size(0) * b_i] > 0.0) &&
                                 (BoardIdx[BoardIdx.size(0) * b_i + 1] > 0.0) &&
                                 (BoardIdx[BoardIdx.size(0) * b_i + 2] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[BoardIdx.size(0) * b_i] > 0.0) &&
                                 (BoardIdx[BoardIdx.size(0) * b_i + 1] > 0.0) &&
                                 (BoardIdx[BoardIdx.size(0) * b_i + 2] > 0.0));
              }
            }

            newEnergy = 0.0F;
            y = false;
            nx = 1;
            exitg1 = false;
            while ((!exitg1) && (nx <= validIdx.size(1))) {
              if (validIdx[nx - 1]) {
                y = true;
                exitg1 = true;
              } else {
                nx++;
              }
            }

            if (y) {
              end = validIdx.size(1) - 1;
              nx = 0;
              if (i) {
                for (b_i = 0; b_i <= end; b_i++) {
                  if (validIdx[b_i]) {
                    nx++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (b_i = 0; b_i <= end; b_i++) {
                    if (validIdx[b_i]) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    nx += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              r.set_size(1, nx);
              nx = 0;
              for (c_i = 0; c_i <= end; c_i++) {
                if (validIdx[c_i]) {
                  r[nx] = c_i;
                  nx++;
                }
              }

              r1.set_size(1, r.size(1), BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              r2.set_size(1, r.size(1), BoardCoords.size(2));
              b.set_size(1, r.size(1), BoardCoords.size(2));
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(1);
                for (i2 = 0; i2 < nx; i2++) {
                  end = r[i2];
                  r1[i2 + r1.size(1) * i1] = BoardCoords[BoardCoords.size(0) *
                    end + BoardCoords.size(0) * BoardCoords.size(1) * i1];
                  r2[i2 + r2.size(1) * i1] = BoardCoords[(BoardCoords.size(0) *
                    end + BoardCoords.size(0) * BoardCoords.size(1) * i1) + 2];
                  b[i2 + b.size(1) * i1] = BoardCoords[(BoardCoords.size(0) *
                    end + BoardCoords.size(0) * BoardCoords.size(1) * i1) + 1];
                }
              }

              if ((r1.size(1) == b.size(1)) && (r1.size(2) == b.size(2))) {
                r3.set_size(1, r1.size(1), r1.size(2));
                loop_ub = r1.size(1) * r1.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (b_i = 0; b_i < loop_ub; b_i++) {
                    r3[b_i] = (r1[b_i] + r2[b_i]) - 2.0 * b[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < loop_ub; b_i++) {
                    r3[b_i] = (r1[b_i] + r2[b_i]) - 2.0 * b[b_i];
                  }
                }

                squeeze(r3, num);
              } else {
                binary_expand_op(num, r1, r2, b);
              }

              r1.set_size(1, r.size(1), BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              r2.set_size(1, r.size(1), BoardCoords.size(2));
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(1);
                for (i2 = 0; i2 < nx; i2++) {
                  end = r[i2];
                  r1[i2 + r1.size(1) * i1] = BoardCoords[BoardCoords.size(0) *
                    end + BoardCoords.size(0) * BoardCoords.size(1) * i1];
                  r2[i2 + r2.size(1) * i1] = BoardCoords[(BoardCoords.size(0) *
                    end + BoardCoords.size(0) * BoardCoords.size(1) * i1) + 2];
                }
              }

              r3.set_size(1, r1.size(1), r1.size(2));
              loop_ub = r1.size(1) * r1.size(2);
              if (static_cast<int>(loop_ub < 3200)) {
                for (b_i = 0; b_i < loop_ub; b_i++) {
                  r3[b_i] = r1[b_i] - r2[b_i];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < loop_ub; b_i++) {
                  r3[b_i] = r1[b_i] - r2[b_i];
                }
              }

              squeeze(r3, b_denom);
              if (num.size(1) > 1) {
                b_r.set_size(num.size(0));
                nx = num.size(0);
                i1 = (num.size(0) < 3200);
                if (i1) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                }

                c_r.set_size(b_denom.size(0));
                nx = b_denom.size(0);
                if (static_cast<int>(b_denom.size(0) < 3200)) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(b_denom[b_i], b_denom[b_i +
                      b_denom.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(b_denom[b_i], b_denom[b_i +
                      b_denom.size(0)]);
                  }
                }

                if (b_r.size(0) == c_r.size(0)) {
                  loop_ub = b_r.size(0);
                  if (i1) {
                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  }

                  newEnergy = std::fmax(oldEnergy, static_cast<float>(::coder::
                    internal::maximum(b_r)));
                } else {
                  newEnergy = binary_expand_op(oldEnergy, b_r, c_r);
                }
              } else {
                newEnergy = std::fmax(oldEnergy, static_cast<float>
                                      (rt_hypotd_snf(num[0], num[1]) /
                  rt_hypotd_snf(b_denom[0], b_denom[1])));
              }
            }

            validIdx.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = (BoardIdx[BoardIdx.size(0) * b_i] > 0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = (BoardIdx[BoardIdx.size(0) * b_i] > 0.0);
              }
            }

            Checkerboard::arrayFind(validIdx, validNewRowIdx);
            if (validNewRowIdx.size(1) != 0) {
              i = validNewRowIdx.size(1);
              loop_ub = BoardCoords.size(2);
              i1 = BoardCoords.size(2);
              for (c_i = 0; c_i < i; c_i++) {
                d = validNewRowIdx[c_i];
                b_num.set_size(1, 1, i1);
                denom.set_size(1, 1, i1);
                for (i2 = 0; i2 < loop_ub; i2++) {
                  num_tmp = BoardCoords[BoardCoords.size(0) * (static_cast<int>
                    (d) - 1) + BoardCoords.size(0) * BoardCoords.size(1) * i2];
                  b_num_tmp = BoardCoords[BoardCoords.size(0) * (static_cast<int>
                    (d + 2.0) - 1) + BoardCoords.size(0) * BoardCoords.size(1) *
                    i2];
                  b_num[i2] = (num_tmp + b_num_tmp) - 2.0 *
                    BoardCoords[BoardCoords.size(0) * (static_cast<int>(d + 1.0)
                    - 1) + BoardCoords.size(0) * BoardCoords.size(1) * i2];
                  denom[i2] = num_tmp - b_num_tmp;
                }

                if (newEnergy != 0.0F) {
                  nx = b_num.size(2);
                  end = denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = denom.reshape(end);
                  newEnergy = std::fmax(newEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                } else {
                  nx = b_num.size(2);
                  end = denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = denom.reshape(end);
                  newEnergy = std::fmax(oldEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                }
              }
            }

            newEnergy_tmp = static_cast<float>(BoardIdx.size(0) * BoardIdx.size
              (1));
            if (newEnergy != 0.0F) {
              newEnergy = newEnergy * newEnergy_tmp - newEnergy_tmp;
            } else {
              newEnergy = rtInfF;
            }

            return newEnergy;
          }

          float Checkerboard::computeNewEnergyVertical(const ::coder::array<
            double, 2U> &idx, float oldEnergy) const
          {
            array<double, 3U> b;
            array<double, 3U> b_num;
            array<double, 3U> denom;
            array<double, 3U> r1;
            array<double, 3U> r2;
            array<double, 3U> r3;
            array<double, 2U> b_denom;
            array<double, 2U> num;
            array<double, 2U> validNewRowIdx;
            array<double, 1U> b_r;
            array<double, 1U> c_r;
            array<int, 2U> r;
            array<boolean_T, 2U> validIdx;
            double b_num_tmp;
            double d;
            double num_tmp;
            float newEnergy;
            float newEnergy_tmp;
            int b_i;
            int b_idx_tmp;
            int c_i;
            int c_idx_tmp;
            int end;
            int i;
            int i1;
            int i2;
            int idx_tmp;
            int loop_ub;
            int nx;
            int trueCountPrime;
            boolean_T exitg1;
            boolean_T y;
            idx_tmp = static_cast<int>(idx[0]);
            b_idx_tmp = static_cast<int>(idx[1]);
            c_idx_tmp = static_cast<int>(idx[2]);
            validIdx.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            i = (loop_ub < 3200);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[(idx_tmp + BoardIdx.size(0) * b_i) -
                                  1] > 0.0) && (BoardIdx[(b_idx_tmp +
                  BoardIdx.size(0) * b_i) - 1] > 0.0) && (BoardIdx[(c_idx_tmp +
                  BoardIdx.size(0) * b_i) - 1] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = ((BoardIdx[(idx_tmp + BoardIdx.size(0) * b_i) -
                                  1] > 0.0) && (BoardIdx[(b_idx_tmp +
                  BoardIdx.size(0) * b_i) - 1] > 0.0) && (BoardIdx[(c_idx_tmp +
                  BoardIdx.size(0) * b_i) - 1] > 0.0));
              }
            }

            newEnergy = 0.0F;
            y = false;
            nx = 1;
            exitg1 = false;
            while ((!exitg1) && (nx <= validIdx.size(1))) {
              if (validIdx[nx - 1]) {
                y = true;
                exitg1 = true;
              } else {
                nx++;
              }
            }

            if (y) {
              end = validIdx.size(1) - 1;
              nx = 0;
              if (i) {
                for (b_i = 0; b_i <= end; b_i++) {
                  if (validIdx[b_i]) {
                    nx++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (b_i = 0; b_i <= end; b_i++) {
                    if (validIdx[b_i]) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    nx += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              r.set_size(1, nx);
              nx = 0;
              for (c_i = 0; c_i <= end; c_i++) {
                if (validIdx[c_i]) {
                  r[nx] = c_i;
                  nx++;
                }
              }

              r1.set_size(1, r.size(1), BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              r2.set_size(1, r.size(1), BoardCoords.size(2));
              b.set_size(1, r.size(1), BoardCoords.size(2));
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(1);
                for (i2 = 0; i2 < nx; i2++) {
                  end = r[i2];
                  r1[i2 + r1.size(1) * i1] = BoardCoords[((idx_tmp +
                    BoardCoords.size(0) * end) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1) - 1];
                  r2[i2 + r2.size(1) * i1] = BoardCoords[((c_idx_tmp +
                    BoardCoords.size(0) * end) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1) - 1];
                  b[i2 + b.size(1) * i1] = BoardCoords[((b_idx_tmp +
                    BoardCoords.size(0) * end) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1) - 1];
                }
              }

              if ((r1.size(1) == b.size(1)) && (r1.size(2) == b.size(2))) {
                r3.set_size(1, r1.size(1), r1.size(2));
                loop_ub = r1.size(1) * r1.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (b_i = 0; b_i < loop_ub; b_i++) {
                    r3[b_i] = (r1[b_i] + r2[b_i]) - 2.0 * b[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < loop_ub; b_i++) {
                    r3[b_i] = (r1[b_i] + r2[b_i]) - 2.0 * b[b_i];
                  }
                }

                squeeze(r3, num);
              } else {
                binary_expand_op(num, r1, r2, b);
              }

              r1.set_size(1, r.size(1), BoardCoords.size(2));
              loop_ub = BoardCoords.size(2);
              r2.set_size(1, r.size(1), BoardCoords.size(2));
              for (i1 = 0; i1 < loop_ub; i1++) {
                nx = r.size(1);
                for (i2 = 0; i2 < nx; i2++) {
                  end = r[i2];
                  r1[i2 + r1.size(1) * i1] = BoardCoords[((idx_tmp +
                    BoardCoords.size(0) * end) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1) - 1];
                  r2[i2 + r2.size(1) * i1] = BoardCoords[((c_idx_tmp +
                    BoardCoords.size(0) * end) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i1) - 1];
                }
              }

              r3.set_size(1, r1.size(1), r1.size(2));
              loop_ub = r1.size(1) * r1.size(2);
              if (static_cast<int>(loop_ub < 3200)) {
                for (b_i = 0; b_i < loop_ub; b_i++) {
                  r3[b_i] = r1[b_i] - r2[b_i];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < loop_ub; b_i++) {
                  r3[b_i] = r1[b_i] - r2[b_i];
                }
              }

              squeeze(r3, b_denom);
              if (num.size(1) > 1) {
                b_r.set_size(num.size(0));
                nx = num.size(0);
                i1 = (num.size(0) < 3200);
                if (i1) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    b_r[b_i] = rt_hypotd_snf(num[b_i], num[b_i + num.size(0)]);
                  }
                }

                c_r.set_size(b_denom.size(0));
                nx = b_denom.size(0);
                if (static_cast<int>(b_denom.size(0) < 3200)) {
                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(b_denom[b_i], b_denom[b_i +
                      b_denom.size(0)]);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (b_i = 0; b_i < nx; b_i++) {
                    c_r[b_i] = rt_hypotd_snf(b_denom[b_i], b_denom[b_i +
                      b_denom.size(0)]);
                  }
                }

                if (b_r.size(0) == c_r.size(0)) {
                  loop_ub = b_r.size(0);
                  if (i1) {
                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (b_i = 0; b_i < loop_ub; b_i++) {
                      b_r[b_i] = b_r[b_i] / c_r[b_i];
                    }
                  }

                  newEnergy = std::fmax(oldEnergy, static_cast<float>(::coder::
                    internal::maximum(b_r)));
                } else {
                  newEnergy = binary_expand_op(oldEnergy, b_r, c_r);
                }
              } else {
                newEnergy = std::fmax(oldEnergy, static_cast<float>
                                      (rt_hypotd_snf(num[0], num[1]) /
                  rt_hypotd_snf(b_denom[0], b_denom[1])));
              }
            }

            validIdx.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            if (i) {
              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = (BoardIdx[(idx_tmp + BoardIdx.size(0) * b_i) - 1]
                                 > 0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i < loop_ub; b_i++) {
                validIdx[b_i] = (BoardIdx[(idx_tmp + BoardIdx.size(0) * b_i) - 1]
                                 > 0.0);
              }
            }

            Checkerboard::arrayFind(validIdx, validNewRowIdx);
            if (validNewRowIdx.size(1) != 0) {
              i = validNewRowIdx.size(1);
              loop_ub = BoardCoords.size(2);
              i1 = BoardCoords.size(2);
              for (c_i = 0; c_i < i; c_i++) {
                d = validNewRowIdx[c_i];
                b_num.set_size(1, 1, i1);
                denom.set_size(1, 1, i1);
                for (i2 = 0; i2 < loop_ub; i2++) {
                  num_tmp = BoardCoords[((idx_tmp + BoardCoords.size(0) * (
                    static_cast<int>(d) - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i2) - 1];
                  b_num_tmp = BoardCoords[((idx_tmp + BoardCoords.size(0) * (
                    static_cast<int>(d + 2.0) - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * i2) - 1];
                  b_num[i2] = (num_tmp + b_num_tmp) - 2.0 * BoardCoords
                    [((idx_tmp + BoardCoords.size(0) * (static_cast<int>(d + 1.0)
                        - 1)) + BoardCoords.size(0) * BoardCoords.size(1) * i2)
                    - 1];
                  denom[i2] = num_tmp - b_num_tmp;
                }

                if (newEnergy != 0.0F) {
                  nx = b_num.size(2);
                  end = denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = denom.reshape(end);
                  newEnergy = std::fmax(newEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                } else {
                  nx = b_num.size(2);
                  end = denom.size(2);
                  b_r = b_num.reshape(nx);
                  c_r = denom.reshape(end);
                  newEnergy = std::fmax(oldEnergy, static_cast<float>(b_norm(b_r)
                    / b_norm(c_r)));
                }
              }
            }

            newEnergy_tmp = static_cast<float>(BoardIdx.size(0) * BoardIdx.size
              (1));
            if (newEnergy != 0.0F) {
              newEnergy = newEnergy * newEnergy_tmp - newEnergy_tmp;
            } else {
              newEnergy = rtInfF;
            }

            return newEnergy;
          }

          void Checkerboard::d_fitPolynomialIndices(::coder::array<double, 2U>
            &newIndices) const
          {
            array<double, 2U> b_index;
            array<double, 2U> b_this;
            array<double, 2U> removedIdx;
            array<int, 2U> validIdx;
            array<int, 1U> currCurve_tmp;
            double currCurve_data[5];
            double coordsToUse[2];
            double currPt[2];
            double b_coordDist_tmp;
            double coordDist;
            double currCoord;
            double currRad;
            double y;
            int currCurve_size[2];
            int coordDist_tmp;
            int i;
            int i1;
            int i2;
            int j;
            int k;
            int loop_ub;
            int n;
            int nPrime;
            boolean_T exitg1;
            boolean_T exitg2;
            boolean_T p;
            b_findIndependentVar(coordsToUse);
            newIndices.set_size(1, BoardCoords.size(0));
            loop_ub = BoardCoords.size(0);
            i = (loop_ub < 3200);
            if (i) {
              for (k = 0; k < loop_ub; k++) {
                newIndices[k] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (k = 0; k < loop_ub; k++) {
                newIndices[k] = 0.0;
              }
            }

            removedIdx.set_size(1, 0);
            i1 = BoardCoords.size(0);
            for (j = 0; j < i1; j++) {
              b_index.set_size(1, BoardCoords.size(1));
              loop_ub = BoardCoords.size(1);
              for (i2 = 0; i2 < loop_ub; i2++) {
                b_index[i2] = BoardCoords[(j + BoardCoords.size(0) * i2) +
                  BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                  (coordsToUse[0]) - 1)];
              }

              eml_find(b_index, validIdx);
              if (validIdx.size(1) >= 2) {
                currRad = coordsToUse[0];
                b_coordDist_tmp = BoardCoords[(j + BoardCoords.size(0) *
                  (validIdx[0] - 1)) + BoardCoords.size(0) * BoardCoords.size(1)
                  * (static_cast<int>(coordsToUse[0]) - 1)];
                coordDist_tmp = validIdx[0];
                coordDist = (b_coordDist_tmp - BoardCoords[(j + BoardCoords.size
                  (0) * (validIdx[1] - 1)) + BoardCoords.size(0) *
                             BoardCoords.size(1) * (static_cast<int>
                  (coordsToUse[0]) - 1)]) / (static_cast<double>(validIdx[1]) -
                  static_cast<double>(coordDist_tmp));
                n = 0;
                i2 = validIdx.size(1);
                for (loop_ub = 0; loop_ub < i2; loop_ub++) {
                  if (validIdx[loop_ub] != 0) {
                    n++;
                  }
                }

                currCurve_tmp.set_size(validIdx.size(1));
                loop_ub = validIdx.size(1);
                for (i2 = 0; i2 < loop_ub; i2++) {
                  currCurve_tmp[i2] = validIdx[i2];
                }

                b_index.set_size(1, currCurve_tmp.size(0));
                loop_ub = currCurve_tmp.size(0);
                b_this.set_size(1, currCurve_tmp.size(0));
                for (i2 = 0; i2 < loop_ub; i2++) {
                  b_index[i2] = BoardCoords[(j + BoardCoords.size(0) *
                    (currCurve_tmp[i2] - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * (static_cast<int>(currRad) - 1)];
                  b_this[i2] = BoardCoords[(j + BoardCoords.size(0) *
                    (currCurve_tmp[i2] - 1)) + BoardCoords.size(0) *
                    BoardCoords.size(1) * (static_cast<int>(coordsToUse[1]) - 1)];
                }

                if (n > 5) {
                  i2 = 4;
                } else {
                  i2 = 2;
                }

                polyfit(b_index, b_this, static_cast<double>(i2), currCurve_data,
                        currCurve_size);
                currRad = coordDist / 4.0;
                currCoord = currRad + b_coordDist_tmp;
                exitg1 = false;
                while ((!exitg1) && (std::abs(currCoord - b_coordDist_tmp) <
                                     static_cast<double>(coordDist_tmp) * 1.5 *
                                     std::abs(coordDist))) {
                  p = true;
                  loop_ub = 0;
                  exitg2 = false;
                  while ((!exitg2) && (loop_ub < 2)) {
                    if (!(coordsToUse[loop_ub] == static_cast<double>(loop_ub) +
                          1.0)) {
                      p = false;
                      exitg2 = true;
                    } else {
                      loop_ub++;
                    }
                  }

                  if (p) {
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (loop_ub = 0; loop_ub <= i2 - 2; loop_ub++) {
                      y = currCoord * y + currCurve_data[loop_ub + 1];
                    }

                    currPt[0] = currCoord;
                    currPt[1] = y;
                  } else {
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (loop_ub = 0; loop_ub <= i2 - 2; loop_ub++) {
                      y = currCoord * y + currCurve_data[loop_ub + 1];
                    }

                    currPt[0] = y;
                    currPt[1] = currCoord;
                  }

                  findClosestOnCurve(currPt, std::abs(currRad), currCurve_data,
                                     currCurve_size, coordsToUse, removedIdx,
                                     b_index);
                  if (b_index.size(1) != 0) {
                    newIndices[j] = b_index[0];
                    i2 = removedIdx.size(1);
                    loop_ub = b_index.size(1);
                    removedIdx.set_size(removedIdx.size(0), removedIdx.size(1) +
                                        b_index.size(1));
                    for (coordDist_tmp = 0; coordDist_tmp < loop_ub;
                         coordDist_tmp++) {
                      removedIdx[i2 + coordDist_tmp] = b_index[coordDist_tmp];
                    }

                    exitg1 = true;
                  } else {
                    currCoord += currRad;
                  }
                }
              }
            }

            n = 0;
            i1 = newIndices.size(1);
            if (i) {
              for (k = 0; k < i1; k++) {
                if (newIndices[k] != 0.0) {
                  n++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(nPrime)

              {
                nPrime = 0;

#pragma omp for nowait

                for (k = 0; k < i1; k++) {
                  if (newIndices[k] != 0.0) {
                    nPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  n += nPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            if (n < 4) {
              coordDist_tmp = newIndices.size(1) - 1;
              if (i) {
                for (k = 0; k <= coordDist_tmp; k++) {
                  if (newIndices[k] > 0.0) {
                    newIndices[k] = 0.0;
                  }
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (k = 0; k <= coordDist_tmp; k++) {
                  if (newIndices[k] > 0.0) {
                    newIndices[k] = 0.0;
                  }
                }
              }
            }
          }

          void Checkerboard::expandBoardDirectionally(double direction)
          {
            array<double, 3U> b_this;
            array<double, 3U> r;
            array<double, 2U> b_p2;
            array<double, 2U> e_this;
            array<double, 2U> idx;
            array<double, 2U> newIndices;
            array<double, 2U> p1;
            array<double, 2U> p2;
            array<double, 2U> removedIdx;
            array<double, 2U> validIdx;
            array<double, 1U> b_validIdx;
            array<double, 1U> c_this;
            array<double, 1U> d_this;
            array<int, 2U> r1;
            array<int, 1U> r2;
            double currCurve_data[5];
            double currCoord;
            double moveDistMultiplier;
            float oldEnergy;
            oldEnergy = static_cast<float>(BoardIdx.size(0) * BoardIdx.size(1));
            oldEnergy = (Energy + oldEnergy) / oldEnergy;
            switch (static_cast<int>(direction)) {
             case 1:
              {
                int loop_ub;
                if (IsDistortionHigh) {
                  int numCols;
                  boolean_T exitg1;
                  boolean_T p;
                  fitPolynomialIndices(newIndices);
                  p = true;
                  numCols = 1;
                  exitg1 = false;
                  while ((!exitg1) && (numCols <= newIndices.size(1))) {
                    if (newIndices[numCols - 1] == 0.0) {
                      p = false;
                      exitg1 = true;
                    } else {
                      numCols++;
                    }
                  }

                  if (!p) {
                    int b_loop_ub;
                    b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (int i{0}; i < loop_ub; i++) {
                      b_loop_ub = BoardCoords.size(1);
                      for (int i1{0}; i1 < b_loop_ub; i1++) {
                        b_this[i1 + b_this.size(1) * i] = BoardCoords
                          [(BoardCoords.size(0) * i1 + BoardCoords.size(0) *
                            BoardCoords.size(1) * i) + 1];
                      }
                    }

                    squeeze(b_this, p1);
                    b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (int i{0}; i < loop_ub; i++) {
                      b_loop_ub = BoardCoords.size(1);
                      for (int i1{0}; i1 < b_loop_ub; i1++) {
                        b_this[i1 + b_this.size(1) * i] =
                          BoardCoords[BoardCoords.size(0) * i1 +
                          BoardCoords.size(0) * BoardCoords.size(1) * i];
                      }
                    }

                    squeeze(b_this, p2);
                    if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                    {
                      b_p2.set_size(p2.size(0), p2.size(1));
                      loop_ub = p2.size(0) * p2.size(1);
                      if (static_cast<int>(loop_ub < 3200)) {
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                        for (int b_i = 0; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      }

                      findClosestIndices(b_p2, validIdx);
                    } else {
                      binary_expand_op(validIdx, this, p2, p1);
                    }

                    numCols = newIndices.size(1) - 1;
                    if (static_cast<int>(newIndices.size(1) < 3200)) {
                      for (int b_i{0}; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    }
                  }
                } else {
                  int b_loop_ub;
                  b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (int i{0}; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(1);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(1) * i] = BoardCoords
                        [(BoardCoords.size(0) * i1 + BoardCoords.size(0) *
                          BoardCoords.size(1) * i) + 1];
                    }
                  }

                  squeeze(b_this, p1);
                  b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (int i{0}; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(1);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(1) * i] =
                        BoardCoords[BoardCoords.size(0) * i1 + BoardCoords.size
                        (0) * BoardCoords.size(1) * i];
                    }
                  }

                  squeeze(b_this, p2);
                  if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                  {
                    b_p2.set_size(p2.size(0), p2.size(1));
                    loop_ub = p2.size(0) * p2.size(1);
                    if (static_cast<int>(loop_ub < 3200)) {
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    }

                    findClosestIndices(b_p2, newIndices);
                  } else {
                    binary_expand_op(newIndices, this, p2, p1);
                  }
                }

                expandBoardUp(newIndices, p1, r);
                BoardIdx.set_size(p1.size(0), p1.size(1));
                loop_ub = p1.size(0) * p1.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                }

                BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                loop_ub = r.size(0) * r.size(1) * r.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                }

                oldEnergy = computeNewEnergyVertical(oldEnergy);
              }
              break;

             case 2:
              {
                int i;
                int loop_ub;
                int numCols;
                numCols = BoardCoords.size(0);
                if (numCols < numCols - 2) {
                  idx.set_size(1, 0);
                } else {
                  idx.set_size(1, 3);
                  for (i = 0; i < 3; i++) {
                    idx[i] = numCols - i;
                  }
                }

                if (IsDistortionHigh) {
                  double coordsToUse[2];
                  int b_loop_ub;
                  int i1;
                  int i2;
                  boolean_T exitg1;
                  boolean_T p;
                  findIndependentVar(idx, coordsToUse);
                  newIndices.set_size(1, BoardCoords.size(1));
                  loop_ub = BoardCoords.size(1);
                  i = (loop_ub < 3200);
                  if (i) {
                    for (int b_i{0}; b_i < loop_ub; b_i++) {
                      newIndices[b_i] = 0.0;
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (int b_i = 0; b_i < loop_ub; b_i++) {
                      newIndices[b_i] = 0.0;
                    }
                  }

                  removedIdx.set_size(1, 0);
                  i1 = newIndices.size(1);
                  for (int j{0}; j < i1; j++) {
                    b_validIdx.set_size(BoardCoords.size(0));
                    loop_ub = BoardCoords.size(0);
                    for (i2 = 0; i2 < loop_ub; i2++) {
                      b_validIdx[i2] = BoardCoords[(i2 + BoardCoords.size(0) * j)
                        + BoardCoords.size(0) * BoardCoords.size(1) * (
                        static_cast<int>(coordsToUse[0]) - 1)];
                    }

                    eml_find(b_validIdx, r2);
                    b_validIdx.set_size(r2.size(0));
                    loop_ub = r2.size(0);
                    for (i2 = 0; i2 < loop_ub; i2++) {
                      b_validIdx[i2] = r2[i2];
                    }

                    if (b_validIdx.size(0) >= 2) {
                      double coordDist;
                      double currRad;
                      double refCoordValue;
                      int currCurve_size[2];
                      coordDist = findSearchParams(idx, b_validIdx, static_cast<
                        double>(j) + 1.0, coordsToUse, moveDistMultiplier,
                        currCoord);
                      numCols = 0;
                      i2 = b_validIdx.size(0);
                      c_this.set_size(b_validIdx.size(0));
                      d_this.set_size(b_validIdx.size(0));
                      for (b_loop_ub = 0; b_loop_ub < i2; b_loop_ub++) {
                        int this_tmp;
                        if (b_validIdx[b_loop_ub] != 0.0) {
                          numCols++;
                        }

                        this_tmp = static_cast<int>(b_validIdx[b_loop_ub]) - 1;
                        c_this[b_loop_ub] = BoardCoords[(this_tmp +
                          BoardCoords.size(0) * j) + BoardCoords.size(0) *
                          BoardCoords.size(1) * (static_cast<int>(coordsToUse[0])
                          - 1)];
                        d_this[b_loop_ub] = BoardCoords[(this_tmp +
                          BoardCoords.size(0) * j) + BoardCoords.size(0) *
                          BoardCoords.size(1) * (static_cast<int>(coordsToUse[1])
                          - 1)];
                      }

                      if (numCols > 5) {
                        i2 = 4;
                      } else {
                        i2 = 2;
                      }

                      polyfit(c_this, d_this, static_cast<double>(i2),
                              currCurve_data, currCurve_size);
                      currRad = coordDist / 4.0;
                      refCoordValue = BoardCoords[((static_cast<int>(currCoord)
                        + BoardCoords.size(0) * j) + BoardCoords.size(0) *
                        BoardCoords.size(1) * (static_cast<int>(coordsToUse[0])
                        - 1)) - 1];
                      currCoord = currRad + refCoordValue;
                      exitg1 = false;
                      while ((!exitg1) && (std::abs(currCoord - refCoordValue) <
                                           moveDistMultiplier * 1.5 * std::abs
                                           (coordDist))) {
                        double currPt[2];
                        boolean_T exitg2;
                        p = true;
                        b_loop_ub = 0;
                        exitg2 = false;
                        while ((!exitg2) && (b_loop_ub < 2)) {
                          if (!(coordsToUse[b_loop_ub] == static_cast<double>
                                (b_loop_ub) + 1.0)) {
                            p = false;
                            exitg2 = true;
                          } else {
                            b_loop_ub++;
                          }
                        }

                        if (p) {
                          double y;
                          y = currCurve_data[0];
                          i2 = currCurve_size[1];
                          for (b_loop_ub = 0; b_loop_ub <= i2 - 2; b_loop_ub++)
                          {
                            y = currCoord * y + currCurve_data[b_loop_ub + 1];
                          }

                          currPt[0] = currCoord;
                          currPt[1] = y;
                        } else {
                          double y;
                          y = currCurve_data[0];
                          i2 = currCurve_size[1];
                          for (b_loop_ub = 0; b_loop_ub <= i2 - 2; b_loop_ub++)
                          {
                            y = currCoord * y + currCurve_data[b_loop_ub + 1];
                          }

                          currPt[0] = y;
                          currPt[1] = currCoord;
                        }

                        findClosestOnCurve(currPt, std::abs(currRad),
                                           currCurve_data, currCurve_size,
                                           coordsToUse, removedIdx, validIdx);
                        if (validIdx.size(1) != 0) {
                          newIndices[j] = validIdx[0];
                          i2 = removedIdx.size(1);
                          loop_ub = validIdx.size(1);
                          removedIdx.set_size(removedIdx.size(0),
                                              removedIdx.size(1) + validIdx.size
                                              (1));
                          for (numCols = 0; numCols < loop_ub; numCols++) {
                            removedIdx[i2 + numCols] = validIdx[numCols];
                          }

                          exitg1 = true;
                        } else {
                          currCoord += currRad;
                        }
                      }
                    }
                  }

                  p = true;
                  numCols = 1;
                  exitg1 = false;
                  while ((!exitg1) && (numCols <= newIndices.size(1))) {
                    if (newIndices[numCols - 1] == 0.0) {
                      p = false;
                      exitg1 = true;
                    } else {
                      numCols++;
                    }
                  }

                  if (!p) {
                    numCols = static_cast<int>(idx[1]);
                    b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (i1 = 0; i1 < loop_ub; i1++) {
                      b_loop_ub = BoardCoords.size(1);
                      for (i2 = 0; i2 < b_loop_ub; i2++) {
                        b_this[i2 + b_this.size(1) * i1] = BoardCoords[((numCols
                          + BoardCoords.size(0) * i2) + BoardCoords.size(0) *
                          BoardCoords.size(1) * i1) - 1];
                      }
                    }

                    squeeze(b_this, p1);
                    numCols = static_cast<int>(idx[0]);
                    b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (i1 = 0; i1 < loop_ub; i1++) {
                      b_loop_ub = BoardCoords.size(1);
                      for (i2 = 0; i2 < b_loop_ub; i2++) {
                        b_this[i2 + b_this.size(1) * i1] = BoardCoords[((numCols
                          + BoardCoords.size(0) * i2) + BoardCoords.size(0) *
                          BoardCoords.size(1) * i1) - 1];
                      }
                    }

                    squeeze(b_this, p2);
                    if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                    {
                      b_p2.set_size(p2.size(0), p2.size(1));
                      loop_ub = p2.size(0) * p2.size(1);
                      if (static_cast<int>(loop_ub < 3200)) {
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                        for (int b_i = 0; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      }

                      findClosestIndices(b_p2, validIdx);
                    } else {
                      binary_expand_op(validIdx, this, p2, p1);
                    }

                    numCols = newIndices.size(1) - 1;
                    if (i) {
                      for (int b_i{0}; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    }
                  }
                } else {
                  int b_loop_ub;
                  numCols = static_cast<int>(idx[1]);
                  b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (i = 0; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(1);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(1) * i] = BoardCoords[((numCols +
                        BoardCoords.size(0) * i1) + BoardCoords.size(0) *
                        BoardCoords.size(1) * i) - 1];
                    }
                  }

                  squeeze(b_this, p1);
                  numCols = static_cast<int>(idx[0]);
                  b_this.set_size(1, BoardCoords.size(1), BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (i = 0; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(1);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(1) * i] = BoardCoords[((numCols +
                        BoardCoords.size(0) * i1) + BoardCoords.size(0) *
                        BoardCoords.size(1) * i) - 1];
                    }
                  }

                  squeeze(b_this, p2);
                  if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                  {
                    b_p2.set_size(p2.size(0), p2.size(1));
                    loop_ub = p2.size(0) * p2.size(1);
                    if (static_cast<int>(loop_ub < 3200)) {
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    }

                    findClosestIndices(b_p2, newIndices);
                  } else {
                    binary_expand_op(newIndices, this, p2, p1);
                  }
                }

                expandBoardDown(newIndices, p1, r);
                BoardIdx.set_size(p1.size(0), p1.size(1));
                loop_ub = p1.size(0) * p1.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                }

                BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                loop_ub = r.size(0) * r.size(1) * r.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                }

                idx.set_size(1, idx.size(1));
                numCols = idx.size(1) - 1;
                loop_ub = idx.size(1) - 1;
                if (static_cast<int>(idx.size(1) < 3200)) {
                  for (int b_i{0}; b_i <= numCols; b_i++) {
                    idx[b_i] = idx[b_i] + 1.0;
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i <= loop_ub; b_i++) {
                    idx[b_i] = idx[b_i] + 1.0;
                  }
                }

                oldEnergy = computeNewEnergyVertical(idx, oldEnergy);
              }
              break;

             case 3:
              {
                int loop_ub;
                if (IsDistortionHigh) {
                  int numCols;
                  boolean_T exitg1;
                  boolean_T p;
                  b_fitPolynomialIndices(newIndices);
                  p = true;
                  numCols = 1;
                  exitg1 = false;
                  while ((!exitg1) && (numCols <= newIndices.size(1))) {
                    if (newIndices[numCols - 1] == 0.0) {
                      p = false;
                      exitg1 = true;
                    } else {
                      numCols++;
                    }
                  }

                  if (!p) {
                    int b_loop_ub;
                    b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (int i{0}; i < loop_ub; i++) {
                      b_loop_ub = BoardCoords.size(0);
                      for (int i1{0}; i1 < b_loop_ub; i1++) {
                        b_this[i1 + b_this.size(0) * i] = BoardCoords[(i1 +
                          BoardCoords.size(0)) + BoardCoords.size(0) *
                          BoardCoords.size(1) * i];
                      }
                    }

                    b_squeeze(b_this, p1);
                    b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (int i{0}; i < loop_ub; i++) {
                      b_loop_ub = BoardCoords.size(0);
                      for (int i1{0}; i1 < b_loop_ub; i1++) {
                        b_this[i1 + b_this.size(0) * i] = BoardCoords[i1 +
                          BoardCoords.size(0) * BoardCoords.size(1) * i];
                      }
                    }

                    b_squeeze(b_this, p2);
                    if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                    {
                      b_p2.set_size(p2.size(0), p2.size(1));
                      loop_ub = p2.size(0) * p2.size(1);
                      if (static_cast<int>(loop_ub < 3200)) {
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                        for (int b_i = 0; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      }

                      findClosestIndices(b_p2, validIdx);
                    } else {
                      binary_expand_op(validIdx, this, p2, p1);
                    }

                    numCols = newIndices.size(1) - 1;
                    if (static_cast<int>(newIndices.size(1) < 3200)) {
                      for (int b_i{0}; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    }
                  }
                } else {
                  int b_loop_ub;
                  b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (int i{0}; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(0);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(0) * i] = BoardCoords[(i1 +
                        BoardCoords.size(0)) + BoardCoords.size(0) *
                        BoardCoords.size(1) * i];
                    }
                  }

                  b_squeeze(b_this, p1);
                  b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (int i{0}; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(0);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(0) * i] = BoardCoords[i1 +
                        BoardCoords.size(0) * BoardCoords.size(1) * i];
                    }
                  }

                  b_squeeze(b_this, p2);
                  if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                  {
                    b_p2.set_size(p2.size(0), p2.size(1));
                    loop_ub = p2.size(0) * p2.size(1);
                    if (static_cast<int>(loop_ub < 3200)) {
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    }

                    findClosestIndices(b_p2, newIndices);
                  } else {
                    binary_expand_op(newIndices, this, p2, p1);
                  }
                }

                expandBoardLeft(newIndices, p1, r);
                BoardIdx.set_size(p1.size(0), p1.size(1));
                loop_ub = p1.size(0) * p1.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                }

                BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                loop_ub = r.size(0) * r.size(1) * r.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                }

                oldEnergy = computeNewEnergyHorizontal(oldEnergy);
              }
              break;

             default:
              {
                int i;
                int loop_ub;
                int numCols;
                numCols = BoardCoords.size(1);
                if (numCols < numCols - 2) {
                  idx.set_size(1, 0);
                } else {
                  idx.set_size(1, 3);
                  for (i = 0; i < 3; i++) {
                    idx[i] = numCols - i;
                  }
                }

                if (IsDistortionHigh) {
                  double coordsToUse[2];
                  int b_loop_ub;
                  int i1;
                  int i2;
                  boolean_T exitg1;
                  boolean_T p;
                  b_findIndependentVar(idx, coordsToUse);
                  newIndices.set_size(1, BoardCoords.size(0));
                  loop_ub = BoardCoords.size(0);
                  i = (loop_ub < 3200);
                  if (i) {
                    for (int b_i{0}; b_i < loop_ub; b_i++) {
                      newIndices[b_i] = 0.0;
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (int b_i = 0; b_i < loop_ub; b_i++) {
                      newIndices[b_i] = 0.0;
                    }
                  }

                  removedIdx.set_size(1, 0);
                  i1 = newIndices.size(1);
                  for (int j{0}; j < i1; j++) {
                    validIdx.set_size(1, BoardCoords.size(1));
                    loop_ub = BoardCoords.size(1);
                    for (i2 = 0; i2 < loop_ub; i2++) {
                      validIdx[i2] = BoardCoords[(j + BoardCoords.size(0) * i2)
                        + BoardCoords.size(0) * BoardCoords.size(1) * (
                        static_cast<int>(coordsToUse[0]) - 1)];
                    }

                    eml_find(validIdx, r1);
                    validIdx.set_size(1, r1.size(1));
                    loop_ub = r1.size(1);
                    for (i2 = 0; i2 < loop_ub; i2++) {
                      validIdx[i2] = r1[i2];
                    }

                    if (validIdx.size(1) >= 2) {
                      double coordDist;
                      double currRad;
                      double refCoordValue;
                      int currCurve_size[2];
                      coordDist = findSearchParams(idx, validIdx, static_cast<
                        double>(j) + 1.0, coordsToUse, moveDistMultiplier,
                        currCoord);
                      numCols = 0;
                      i2 = validIdx.size(1);
                      b_validIdx.set_size(validIdx.size(1));
                      for (b_loop_ub = 0; b_loop_ub < i2; b_loop_ub++) {
                        refCoordValue = validIdx[b_loop_ub];
                        if (static_cast<int>(refCoordValue) != 0) {
                          numCols++;
                        }

                        b_validIdx[b_loop_ub] = refCoordValue;
                      }

                      validIdx.set_size(1, b_validIdx.size(0));
                      loop_ub = b_validIdx.size(0);
                      e_this.set_size(1, b_validIdx.size(0));
                      for (i2 = 0; i2 < loop_ub; i2++) {
                        int this_tmp;
                        this_tmp = static_cast<int>(b_validIdx[i2]) - 1;
                        validIdx[i2] = BoardCoords[(j + BoardCoords.size(0) *
                          this_tmp) + BoardCoords.size(0) * BoardCoords.size(1) *
                          (static_cast<int>(coordsToUse[0]) - 1)];
                        e_this[i2] = BoardCoords[(j + BoardCoords.size(0) *
                          this_tmp) + BoardCoords.size(0) * BoardCoords.size(1) *
                          (static_cast<int>(coordsToUse[1]) - 1)];
                      }

                      if (numCols > 5) {
                        i2 = 4;
                      } else {
                        i2 = 2;
                      }

                      polyfit(validIdx, e_this, static_cast<double>(i2),
                              currCurve_data, currCurve_size);
                      currRad = coordDist / 4.0;
                      refCoordValue = BoardCoords[(j + BoardCoords.size(0) * (
                        static_cast<int>(currCoord) - 1)) + BoardCoords.size(0) *
                        BoardCoords.size(1) * (static_cast<int>(coordsToUse[0])
                        - 1)];
                      currCoord = currRad + refCoordValue;
                      exitg1 = false;
                      while ((!exitg1) && (std::abs(currCoord - refCoordValue) <
                                           moveDistMultiplier * 1.5 * std::abs
                                           (coordDist))) {
                        double currPt[2];
                        boolean_T exitg2;
                        p = true;
                        b_loop_ub = 0;
                        exitg2 = false;
                        while ((!exitg2) && (b_loop_ub < 2)) {
                          if (!(coordsToUse[b_loop_ub] == static_cast<double>
                                (b_loop_ub) + 1.0)) {
                            p = false;
                            exitg2 = true;
                          } else {
                            b_loop_ub++;
                          }
                        }

                        if (p) {
                          double y;
                          y = currCurve_data[0];
                          i2 = currCurve_size[1];
                          for (b_loop_ub = 0; b_loop_ub <= i2 - 2; b_loop_ub++)
                          {
                            y = currCoord * y + currCurve_data[b_loop_ub + 1];
                          }

                          currPt[0] = currCoord;
                          currPt[1] = y;
                        } else {
                          double y;
                          y = currCurve_data[0];
                          i2 = currCurve_size[1];
                          for (b_loop_ub = 0; b_loop_ub <= i2 - 2; b_loop_ub++)
                          {
                            y = currCoord * y + currCurve_data[b_loop_ub + 1];
                          }

                          currPt[0] = y;
                          currPt[1] = currCoord;
                        }

                        findClosestOnCurve(currPt, std::abs(currRad),
                                           currCurve_data, currCurve_size,
                                           coordsToUse, removedIdx, validIdx);
                        if (validIdx.size(1) != 0) {
                          newIndices[j] = validIdx[0];
                          i2 = removedIdx.size(1);
                          loop_ub = validIdx.size(1);
                          removedIdx.set_size(removedIdx.size(0),
                                              removedIdx.size(1) + validIdx.size
                                              (1));
                          for (numCols = 0; numCols < loop_ub; numCols++) {
                            removedIdx[i2 + numCols] = validIdx[numCols];
                          }

                          exitg1 = true;
                        } else {
                          currCoord += currRad;
                        }
                      }
                    }
                  }

                  p = true;
                  numCols = 1;
                  exitg1 = false;
                  while ((!exitg1) && (numCols <= newIndices.size(1))) {
                    if (newIndices[numCols - 1] == 0.0) {
                      p = false;
                      exitg1 = true;
                    } else {
                      numCols++;
                    }
                  }

                  if (!p) {
                    numCols = static_cast<int>(idx[1]);
                    b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (i1 = 0; i1 < loop_ub; i1++) {
                      b_loop_ub = BoardCoords.size(0);
                      for (i2 = 0; i2 < b_loop_ub; i2++) {
                        b_this[i2 + b_this.size(0) * i1] = BoardCoords[(i2 +
                          BoardCoords.size(0) * (numCols - 1)) +
                          BoardCoords.size(0) * BoardCoords.size(1) * i1];
                      }
                    }

                    b_squeeze(b_this, p1);
                    numCols = static_cast<int>(idx[0]);
                    b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                    loop_ub = BoardCoords.size(2);
                    for (i1 = 0; i1 < loop_ub; i1++) {
                      b_loop_ub = BoardCoords.size(0);
                      for (i2 = 0; i2 < b_loop_ub; i2++) {
                        b_this[i2 + b_this.size(0) * i1] = BoardCoords[(i2 +
                          BoardCoords.size(0) * (numCols - 1)) +
                          BoardCoords.size(0) * BoardCoords.size(1) * i1];
                      }
                    }

                    b_squeeze(b_this, p2);
                    if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                    {
                      b_p2.set_size(p2.size(0), p2.size(1));
                      loop_ub = p2.size(0) * p2.size(1);
                      if (static_cast<int>(loop_ub < 3200)) {
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                        for (int b_i = 0; b_i < loop_ub; b_i++) {
                          b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                        }
                      }

                      findClosestIndices(b_p2, validIdx);
                    } else {
                      binary_expand_op(validIdx, this, p2, p1);
                    }

                    numCols = newIndices.size(1) - 1;
                    if (i) {
                      for (int b_i{0}; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i <= numCols; b_i++) {
                        if (newIndices[b_i] == 0.0) {
                          newIndices[b_i] = validIdx[b_i];
                        }
                      }
                    }
                  }
                } else {
                  int b_loop_ub;
                  numCols = static_cast<int>(idx[1]);
                  b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (i = 0; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(0);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(0) * i] = BoardCoords[(i1 +
                        BoardCoords.size(0) * (numCols - 1)) + BoardCoords.size
                        (0) * BoardCoords.size(1) * i];
                    }
                  }

                  b_squeeze(b_this, p1);
                  numCols = static_cast<int>(idx[0]);
                  b_this.set_size(BoardCoords.size(0), 1, BoardCoords.size(2));
                  loop_ub = BoardCoords.size(2);
                  for (i = 0; i < loop_ub; i++) {
                    b_loop_ub = BoardCoords.size(0);
                    for (int i1{0}; i1 < b_loop_ub; i1++) {
                      b_this[i1 + b_this.size(0) * i] = BoardCoords[(i1 +
                        BoardCoords.size(0) * (numCols - 1)) + BoardCoords.size
                        (0) * BoardCoords.size(1) * i];
                    }
                  }

                  b_squeeze(b_this, p2);
                  if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size(1)))
                  {
                    b_p2.set_size(p2.size(0), p2.size(1));
                    loop_ub = p2.size(0) * p2.size(1);
                    if (static_cast<int>(loop_ub < 3200)) {
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                      for (int b_i = 0; b_i < loop_ub; b_i++) {
                        b_p2[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                      }
                    }

                    findClosestIndices(b_p2, newIndices);
                  } else {
                    binary_expand_op(newIndices, this, p2, p1);
                  }
                }

                expandBoardRight(newIndices, p1, r);
                BoardIdx.set_size(p1.size(0), p1.size(1));
                loop_ub = p1.size(0) * p1.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardIdx[b_i] = p1[b_i];
                  }
                }

                BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                loop_ub = r.size(0) * r.size(1) * r.size(2);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int b_i{0}; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i < loop_ub; b_i++) {
                    BoardCoords[b_i] = r[b_i];
                  }
                }

                idx.set_size(1, idx.size(1));
                numCols = idx.size(1) - 1;
                loop_ub = idx.size(1) - 1;
                if (static_cast<int>(idx.size(1) < 3200)) {
                  for (int b_i{0}; b_i <= numCols; b_i++) {
                    idx[b_i] = idx[b_i] + 1.0;
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int b_i = 0; b_i <= loop_ub; b_i++) {
                    idx[b_i] = idx[b_i] + 1.0;
                  }
                }

                oldEnergy = computeNewEnergyHorizontal(idx, oldEnergy);
              }
              break;
            }

            Energy = oldEnergy;
          }

          void Checkerboard::expandBoardDown(const ::coder::array<double, 2U>
            &indices, ::coder::array<double, 2U> &newBoard, ::coder::array<
            double, 3U> &newBoardCoords) const
          {
            array<double, 2U> r2;
            array<int, 2U> r;
            array<int, 1U> r1;
            int b_i;
            int b_loop_ub;
            int b_this;
            int i;
            int i1;
            int loop_ub;
            int trueCount;
            int trueCountPrime;
            newBoard.set_size(BoardIdx.size(0) + 1, BoardIdx.size(1));
            loop_ub = (BoardIdx.size(0) + 1) * BoardIdx.size(1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            }

            b_this = BoardIdx.size(0);
            loop_ub = indices.size(1);
            b_i = (indices.size(1) < 3200);
            if (b_i) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[b_this + newBoard.size(0) * i] = indices[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[b_this + newBoard.size(0) * i] = indices[i];
              }
            }

            loop_ub = BoardIdx.size(1);
            for (i1 = 0; i1 < loop_ub; i1++) {
              b_loop_ub = BoardIdx.size(0);
              for (b_this = 0; b_this < b_loop_ub; b_this++) {
                newBoard[b_this + newBoard.size(0) * i1] = BoardIdx[b_this +
                  BoardIdx.size(0) * i1];
              }
            }

            newBoardCoords.set_size(BoardCoords.size(0) + 1, BoardCoords.size(1),
              BoardCoords.size(2));
            loop_ub = (BoardCoords.size(0) + 1) * BoardCoords.size(1) *
              BoardCoords.size(2);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            }

            b_loop_ub = indices.size(1) - 1;
            trueCount = 0;
            if (b_i) {
              for (i = 0; i <= b_loop_ub; i++) {
                if (indices[i] > 0.0) {
                  trueCount++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (i = 0; i <= b_loop_ub; i++) {
                  if (indices[i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  trueCount += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(1, trueCount);
            trueCount = 0;
            for (b_this = 0; b_this <= b_loop_ub; b_this++) {
              if (indices[b_this] > 0.0) {
                r[trueCount] = b_this;
                trueCount++;
              }
            }

            r1.set_size(r.size(1));
            loop_ub = r.size(1);
            if (static_cast<int>(r.size(1) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            }

            r2.set_size(r.size(1), Points.size(1));
            loop_ub = Points.size(1);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = r.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                r2[i1 + r2.size(0) * b_i] = Points[(static_cast<int>
                  (indices[r[i1]]) + Points.size(0) * b_i) - 1];
              }
            }

            trueCount = r1.size(0);
            b_loop_ub = BoardCoords.size(2);
            b_this = BoardCoords.size(0);
            for (b_i = 0; b_i < b_loop_ub; b_i++) {
              for (i1 = 0; i1 < trueCount; i1++) {
                newBoardCoords[(b_this + newBoardCoords.size(0) * r1[i1]) +
                  newBoardCoords.size(0) * newBoardCoords.size(1) * b_i] = r2[i1
                  + trueCount * b_i];
              }
            }

            loop_ub = BoardCoords.size(2);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = BoardCoords.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                trueCount = BoardCoords.size(0);
                for (b_this = 0; b_this < trueCount; b_this++) {
                  newBoardCoords[(b_this + newBoardCoords.size(0) * i1) +
                    newBoardCoords.size(0) * newBoardCoords.size(1) * b_i] =
                    BoardCoords[(b_this + BoardCoords.size(0) * i1) +
                    BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                }
              }
            }
          }

          void Checkerboard::expandBoardLeft(const ::coder::array<double, 2U>
            &indices, ::coder::array<double, 2U> &newBoard, ::coder::array<
            double, 3U> &newBoardCoords) const
          {
            array<double, 2U> r2;
            array<int, 2U> r;
            array<int, 1U> r1;
            int b_i;
            int b_loop_ub;
            int i;
            int i1;
            int i2;
            int i3;
            int loop_ub;
            int trueCount;
            int trueCountPrime;
            newBoard.set_size(BoardIdx.size(0), BoardIdx.size(1) + 1);
            loop_ub = BoardIdx.size(0) * (BoardIdx.size(1) + 1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            }

            loop_ub = BoardIdx.size(0);
            if (static_cast<int>(BoardIdx.size(0) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = indices[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = indices[i];
              }
            }

            b_i = (newBoard.size(1) >= 2);
            loop_ub = BoardIdx.size(1);
            for (i1 = 0; i1 < loop_ub; i1++) {
              b_loop_ub = BoardIdx.size(0);
              for (i2 = 0; i2 < b_loop_ub; i2++) {
                newBoard[i2 + newBoard.size(0) * (b_i + i1)] = BoardIdx[i2 +
                  BoardIdx.size(0) * i1];
              }
            }

            newBoardCoords.set_size(BoardCoords.size(0), BoardCoords.size(1) + 1,
              BoardCoords.size(2));
            loop_ub = BoardCoords.size(0) * (BoardCoords.size(1) + 1) *
              BoardCoords.size(2);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            }

            b_loop_ub = indices.size(1) - 1;
            trueCount = 0;
            if (static_cast<int>(indices.size(1) < 3200)) {
              for (i = 0; i <= b_loop_ub; i++) {
                if (indices[i] > 0.0) {
                  trueCount++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (i = 0; i <= b_loop_ub; i++) {
                  if (indices[i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  trueCount += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(1, trueCount);
            trueCount = 0;
            for (loop_ub = 0; loop_ub <= b_loop_ub; loop_ub++) {
              if (indices[loop_ub] > 0.0) {
                r[trueCount] = loop_ub;
                trueCount++;
              }
            }

            r1.set_size(r.size(1));
            loop_ub = r.size(1);
            if (static_cast<int>(r.size(1) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            }

            r2.set_size(r.size(1), Points.size(1));
            loop_ub = Points.size(1);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = r.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                r2[i1 + r2.size(0) * b_i] = Points[(static_cast<int>
                  (indices[r[i1]]) + Points.size(0) * b_i) - 1];
              }
            }

            trueCount = r1.size(0);
            b_loop_ub = BoardCoords.size(2);
            for (b_i = 0; b_i < b_loop_ub; b_i++) {
              for (i1 = 0; i1 < trueCount; i1++) {
                newBoardCoords[r1[i1] + newBoardCoords.size(0) *
                  newBoardCoords.size(1) * b_i] = r2[i1 + trueCount * b_i];
              }
            }

            b_i = (newBoardCoords.size(1) >= 2);
            loop_ub = BoardCoords.size(2);
            for (i1 = 0; i1 < loop_ub; i1++) {
              b_loop_ub = BoardCoords.size(1);
              for (i2 = 0; i2 < b_loop_ub; i2++) {
                trueCount = BoardCoords.size(0);
                for (i3 = 0; i3 < trueCount; i3++) {
                  newBoardCoords[(i3 + newBoardCoords.size(0) * (b_i + i2)) +
                    newBoardCoords.size(0) * newBoardCoords.size(1) * i1] =
                    BoardCoords[(i3 + BoardCoords.size(0) * i2) +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1];
                }
              }
            }
          }

          void Checkerboard::expandBoardRight(const ::coder::array<double, 2U>
            &indices, ::coder::array<double, 2U> &newBoard, ::coder::array<
            double, 3U> &newBoardCoords) const
          {
            array<double, 2U> r2;
            array<int, 2U> r;
            array<int, 1U> r1;
            int b_i;
            int b_loop_ub;
            int b_this;
            int i;
            int i1;
            int loop_ub;
            int trueCount;
            int trueCountPrime;
            newBoard.set_size(BoardIdx.size(0), BoardIdx.size(1) + 1);
            loop_ub = BoardIdx.size(0) * (BoardIdx.size(1) + 1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            }

            b_this = BoardIdx.size(1);
            loop_ub = BoardIdx.size(0);
            if (static_cast<int>(BoardIdx.size(0) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i + newBoard.size(0) * b_this] = indices[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i + newBoard.size(0) * b_this] = indices[i];
              }
            }

            loop_ub = BoardIdx.size(1);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = BoardIdx.size(0);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                newBoard[i1 + newBoard.size(0) * b_i] = BoardIdx[i1 +
                  BoardIdx.size(0) * b_i];
              }
            }

            newBoardCoords.set_size(BoardCoords.size(0), BoardCoords.size(1) + 1,
              BoardCoords.size(2));
            loop_ub = BoardCoords.size(0) * (BoardCoords.size(1) + 1) *
              BoardCoords.size(2);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            }

            b_loop_ub = indices.size(1) - 1;
            trueCount = 0;
            if (static_cast<int>(indices.size(1) < 3200)) {
              for (i = 0; i <= b_loop_ub; i++) {
                if (indices[i] > 0.0) {
                  trueCount++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (i = 0; i <= b_loop_ub; i++) {
                  if (indices[i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  trueCount += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(1, trueCount);
            trueCount = 0;
            for (b_this = 0; b_this <= b_loop_ub; b_this++) {
              if (indices[b_this] > 0.0) {
                r[trueCount] = b_this;
                trueCount++;
              }
            }

            r1.set_size(r.size(1));
            loop_ub = r.size(1);
            if (static_cast<int>(r.size(1) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            }

            r2.set_size(r.size(1), Points.size(1));
            loop_ub = Points.size(1);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = r.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                r2[i1 + r2.size(0) * b_i] = Points[(static_cast<int>
                  (indices[r[i1]]) + Points.size(0) * b_i) - 1];
              }
            }

            trueCount = r1.size(0);
            b_loop_ub = BoardCoords.size(2);
            b_this = BoardCoords.size(1);
            for (b_i = 0; b_i < b_loop_ub; b_i++) {
              for (i1 = 0; i1 < trueCount; i1++) {
                newBoardCoords[(r1[i1] + newBoardCoords.size(0) * b_this) +
                  newBoardCoords.size(0) * newBoardCoords.size(1) * b_i] = r2[i1
                  + trueCount * b_i];
              }
            }

            loop_ub = BoardCoords.size(2);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = BoardCoords.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                trueCount = BoardCoords.size(0);
                for (b_this = 0; b_this < trueCount; b_this++) {
                  newBoardCoords[(b_this + newBoardCoords.size(0) * i1) +
                    newBoardCoords.size(0) * newBoardCoords.size(1) * b_i] =
                    BoardCoords[(b_this + BoardCoords.size(0) * i1) +
                    BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                }
              }
            }
          }

          void Checkerboard::expandBoardUp(const ::coder::array<double, 2U>
            &indices, ::coder::array<double, 2U> &newBoard, ::coder::array<
            double, 3U> &newBoardCoords) const
          {
            array<double, 2U> r2;
            array<int, 2U> r;
            array<int, 1U> r1;
            int b_i;
            int b_loop_ub;
            int i;
            int i1;
            int i2;
            int i3;
            int loop_ub;
            int trueCount;
            int trueCountPrime;
            newBoard.set_size(BoardIdx.size(0) + 1, BoardIdx.size(1));
            loop_ub = (BoardIdx.size(0) + 1) * BoardIdx.size(1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[i] = 0.0;
              }
            }

            loop_ub = indices.size(1);
            b_i = (indices.size(1) < 3200);
            if (b_i) {
              for (i = 0; i < loop_ub; i++) {
                newBoard[newBoard.size(0) * i] = indices[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoard[newBoard.size(0) * i] = indices[i];
              }
            }

            i1 = (newBoard.size(0) >= 2);
            loop_ub = BoardIdx.size(1);
            for (i2 = 0; i2 < loop_ub; i2++) {
              b_loop_ub = BoardIdx.size(0);
              for (i3 = 0; i3 < b_loop_ub; i3++) {
                newBoard[(i1 + i3) + newBoard.size(0) * i2] = BoardIdx[i3 +
                  BoardIdx.size(0) * i2];
              }
            }

            newBoardCoords.set_size(BoardCoords.size(0) + 1, BoardCoords.size(1),
              BoardCoords.size(2));
            loop_ub = (BoardCoords.size(0) + 1) * BoardCoords.size(1) *
              BoardCoords.size(2);
            if (static_cast<int>(loop_ub < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                newBoardCoords[i] = 0.0;
              }
            }

            b_loop_ub = indices.size(1) - 1;
            trueCount = 0;
            if (b_i) {
              for (i = 0; i <= b_loop_ub; i++) {
                if (indices[i] > 0.0) {
                  trueCount++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (i = 0; i <= b_loop_ub; i++) {
                  if (indices[i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  trueCount += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(1, trueCount);
            trueCount = 0;
            for (loop_ub = 0; loop_ub <= b_loop_ub; loop_ub++) {
              if (indices[loop_ub] > 0.0) {
                r[trueCount] = loop_ub;
                trueCount++;
              }
            }

            r1.set_size(r.size(1));
            loop_ub = r.size(1);
            if (static_cast<int>(r.size(1) < 3200)) {
              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i = 0; i < loop_ub; i++) {
                r1[i] = r[i];
              }
            }

            r2.set_size(r.size(1), Points.size(1));
            loop_ub = Points.size(1);
            for (b_i = 0; b_i < loop_ub; b_i++) {
              b_loop_ub = r.size(1);
              for (i1 = 0; i1 < b_loop_ub; i1++) {
                r2[i1 + r2.size(0) * b_i] = Points[(static_cast<int>
                  (indices[r[i1]]) + Points.size(0) * b_i) - 1];
              }
            }

            trueCount = r1.size(0);
            b_loop_ub = BoardCoords.size(2);
            for (b_i = 0; b_i < b_loop_ub; b_i++) {
              for (i1 = 0; i1 < trueCount; i1++) {
                newBoardCoords[newBoardCoords.size(0) * r1[i1] +
                  newBoardCoords.size(0) * newBoardCoords.size(1) * b_i] = r2[i1
                  + trueCount * b_i];
              }
            }

            b_i = (newBoardCoords.size(0) >= 2);
            loop_ub = BoardCoords.size(2);
            for (i1 = 0; i1 < loop_ub; i1++) {
              b_loop_ub = BoardCoords.size(1);
              for (i2 = 0; i2 < b_loop_ub; i2++) {
                trueCount = BoardCoords.size(0);
                for (i3 = 0; i3 < trueCount; i3++) {
                  newBoardCoords[((b_i + i3) + newBoardCoords.size(0) * i2) +
                    newBoardCoords.size(0) * newBoardCoords.size(1) * i1] =
                    BoardCoords[(i3 + BoardCoords.size(0) * i2) +
                    BoardCoords.size(0) * BoardCoords.size(1) * i1];
                }
              }
            }
          }

          void Checkerboard::findClosestIndices(const ::coder::array<double, 2U>
            &predictedPoints, ::coder::array<double, 2U> &indices) const
          {
            array<double, 2U> remIdx;
            array<double, 2U> y;
            array<double, 1U> b_this;
            array<float, 2U> c_this;
            array<float, 2U> diffs;
            array<float, 1U> dists;
            array<int, 2U> r1;
            array<int, 1U> validPredictions;
            array<boolean_T, 2U> r2;
            array<boolean_T, 1U> r;
            int b_loop_ub;
            int c_loop_ub;
            int i;
            int loop_ub;
            int nx;
            indices.set_size(1, predictedPoints.size(0));
            loop_ub = predictedPoints.size(0);
            i = (predictedPoints.size(0) < 3200);
            if (i) {
              for (int i1{0}; i1 < loop_ub; i1++) {
                indices[i1] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i1 = 0; i1 < loop_ub; i1++) {
                indices[i1] = 0.0;
              }
            }

            nx = Points.size(0);
            if (nx < 1) {
              y.set_size(1, 0);
            } else {
              y.set_size(1, nx);
              loop_ub = nx - 1;
              if (static_cast<int>(nx < 3200)) {
                for (int i1{0}; i1 <= loop_ub; i1++) {
                  y[i1] = static_cast<double>(i1) + 1.0;
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int i1 = 0; i1 <= loop_ub; i1++) {
                  y[i1] = static_cast<double>(i1) + 1.0;
                }
              }
            }

            nx = BoardIdx.size(0) * BoardIdx.size(1);
            b_this = BoardIdx.reshape(nx);
            do_vectors(y, b_this, remIdx, validPredictions);
            if (remIdx.size(1) != 0) {
              r.set_size(predictedPoints.size(0));
              loop_ub = predictedPoints.size(0);
              if (i) {
                for (int i1{0}; i1 < loop_ub; i1++) {
                  r[i1] = !std::isnan(predictedPoints[i1]);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int i1 = 0; i1 < loop_ub; i1++) {
                  r[i1] = !std::isnan(predictedPoints[i1]);
                }
              }

              b_eml_find(r, validPredictions);
              i = validPredictions.size(0);
              if (validPredictions.size(0) - 1 >= 0) {
                b_loop_ub = Points.size(1);
                c_loop_ub = predictedPoints.size(1);
              }

              for (int b_i{0}; b_i < i; b_i++) {
                c_this.set_size(remIdx.size(1), Points.size(1));
                for (nx = 0; nx < b_loop_ub; nx++) {
                  loop_ub = remIdx.size(1);
                  for (int c_i{0}; c_i < loop_ub; c_i++) {
                    c_this[c_i + c_this.size(0) * nx] = Points[(static_cast<int>
                      (remIdx[c_i]) + Points.size(0) * nx) - 1];
                  }
                }

                y.set_size(1, predictedPoints.size(1));
                for (nx = 0; nx < c_loop_ub; nx++) {
                  y[nx] = predictedPoints[(validPredictions[b_i] +
                    predictedPoints.size(0) * nx) - 1];
                }

                bsxfun(c_this, y, diffs);
                dists.set_size(diffs.size(0));
                nx = diffs.size(0);
                for (loop_ub = 0; loop_ub < nx; loop_ub++) {
                  dists[loop_ub] = rt_hypotf_snf(diffs[loop_ub], diffs[loop_ub +
                    diffs.size(0)]);
                }

                loop_ub = indices.size(1) - 1;
                nx = 0;
                for (int c_i{0}; c_i <= loop_ub; c_i++) {
                  if (indices[c_i] > 0.0) {
                    nx++;
                  }
                }

                r1.set_size(1, nx);
                nx = 0;
                for (int c_i{0}; c_i <= loop_ub; c_i++) {
                  if (indices[c_i] > 0.0) {
                    r1[nx] = c_i;
                    nx++;
                  }
                }

                loop_ub = r1.size(1);
                y.set_size(1, r1.size(1));
                for (nx = 0; nx < loop_ub; nx++) {
                  y[nx] = indices[r1[nx]];
                }

                isMember(remIdx, y, r2);
                loop_ub = r2.size(1) - 1;
                for (int c_i{0}; c_i <= loop_ub; c_i++) {
                  if (r2[c_i]) {
                    dists[c_i] = rtInfF;
                  }
                }

                ::coder::internal::minimum(dists, nx);
                indices[validPredictions[b_i] - 1] = remIdx[nx - 1];
              }
            }
          }

          void Checkerboard::findClosestOnCurve(const double predictedPoint[2],
            double radius, const double curve_data[], const int curve_size[2],
            const double coordsToUse[2], const ::coder::array<double, 2U>
            &removedIdx, ::coder::array<double, 2U> &idx) const
          {
            array<double, 2U> dataPts;
            array<double, 2U> firstCoord;
            array<double, 2U> remIdx;
            array<double, 2U> y;
            array<double, 1U> b_this;
            array<double, 1U> dist;
            array<float, 2U> b_a;
            array<float, 2U> currPt;
            array<float, 2U> diffs;
            array<float, 2U> queryPts;
            array<float, 1U> r;
            array<int, 1U> b_r;
            array<int, 1U> ii;
            array<boolean_T, 1U> candIdx;
            double a;
            double a_tmp;
            float varargin_1;
            int acoef;
            int b_acoef;
            int b_k;
            int b_loop_ub;
            int i;
            int ibmat;
            int k;
            int loop_ub;
            int nPrime;
            int outsize_idx_1;
            int trueCountPrime;
            boolean_T exitg1;
            boolean_T p;
            acoef = Points.size(0);
            if (acoef < 1) {
              y.set_size(1, 0);
            } else {
              y.set_size(1, acoef);
              loop_ub = acoef - 1;
              if (static_cast<int>(acoef < 3200)) {
                for (k = 0; k <= loop_ub; k++) {
                  y[k] = static_cast<double>(k) + 1.0;
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (k = 0; k <= loop_ub; k++) {
                  y[k] = static_cast<double>(k) + 1.0;
                }
              }
            }

            b_acoef = BoardIdx.size(0) * BoardIdx.size(1);
            b_this = BoardIdx.reshape(b_acoef);
            do_vectors(y, b_this, remIdx, ii);
            firstCoord.set_size(1, remIdx.size(1));
            loop_ub = remIdx.size(0) * remIdx.size(1) - 1;
            for (i = 0; i <= loop_ub; i++) {
              firstCoord[i] = remIdx[i];
            }

            do_vectors(firstCoord, removedIdx, remIdx, ii);
            diffs.set_size(remIdx.size(1), 2);
            if (remIdx.size(1) != 0) {
              b_acoef = (Points.size(1) != 1);
              acoef = (remIdx.size(1) != 1);
              for (b_k = 0; b_k < 2; b_k++) {
                ibmat = b_acoef * b_k;
                i = diffs.size(0) - 1;
                for (loop_ub = 0; loop_ub <= i; loop_ub++) {
                  diffs[loop_ub + diffs.size(0) * b_k] = Points[(static_cast<int>
                    (remIdx[acoef * loop_ub]) + Points.size(0) * ibmat) - 1] -
                    static_cast<float>(predictedPoint[b_k]);
                }
              }
            }

            r.set_size(diffs.size(0));
            b_acoef = diffs.size(0);
            i = (diffs.size(0) < 3200);
            if (i) {
              for (k = 0; k < b_acoef; k++) {
                r[k] = rt_hypotf_snf(diffs[k], diffs[k + diffs.size(0)]);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (k = 0; k < b_acoef; k++) {
                r[k] = rt_hypotf_snf(diffs[k], diffs[k + diffs.size(0)]);
              }
            }

            candIdx.set_size(r.size(0));
            loop_ub = r.size(0);
            acoef = 0;
            if (i) {
              for (k = 0; k < loop_ub; k++) {
                candIdx[k] = (r[k] < radius);
                if (r[k] < radius) {
                  acoef++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(nPrime)

              {
                nPrime = 0;

#pragma omp for nowait

                for (k = 0; k < loop_ub; k++) {
                  candIdx[k] = (r[k] < radius);
                  if (r[k] < radius) {
                    nPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  acoef += nPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            if (acoef > 1) {
              a_tmp = predictedPoint[static_cast<int>(coordsToUse[0]) - 1];
              a = a_tmp - radius;
              a_tmp += radius;
              if (std::isnan(a) || std::isnan(a_tmp)) {
                firstCoord.set_size(1, 1);
                firstCoord[0] = rtNaN;
              } else if (a_tmp < a) {
                firstCoord.set_size(1, 0);
              } else if ((std::isinf(a) || std::isinf(a_tmp)) && (a == a_tmp)) {
                firstCoord.set_size(1, 1);
                firstCoord[0] = rtNaN;
              } else if (std::floor(a) == a) {
                loop_ub = static_cast<int>(a_tmp - a);
                firstCoord.set_size(1, loop_ub + 1);
                if (static_cast<int>(loop_ub + 1 < 3200)) {
                  for (k = 0; k <= loop_ub; k++) {
                    firstCoord[k] = a + static_cast<double>(k);
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (k = 0; k <= loop_ub; k++) {
                    firstCoord[k] = a + static_cast<double>(k);
                  }
                }
              } else {
                eml_float_colon(a, a_tmp, firstCoord);
              }

              p = true;
              b_k = 0;
              exitg1 = false;
              while ((!exitg1) && (b_k < 2)) {
                if (!(coordsToUse[b_k] == static_cast<double>(b_k) + 1.0)) {
                  p = false;
                  exitg1 = true;
                } else {
                  b_k++;
                }
              }

              if (p) {
                y.set_size(1, firstCoord.size(1));
                if (firstCoord.size(1) != 0) {
                  acoef = firstCoord.size(1);
                  y.set_size(1, firstCoord.size(1));
                  loop_ub = firstCoord.size(1);
                  if (static_cast<int>(firstCoord.size(1) < 3200)) {
                    for (k = 0; k < acoef; k++) {
                      y[k] = curve_data[0];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (k = 0; k < loop_ub; k++) {
                      y[k] = curve_data[0];
                    }
                  }

                  b_acoef = curve_size[1];
                  for (b_k = 0; b_k <= b_acoef - 2; b_k++) {
                    if (firstCoord.size(1) == y.size(1)) {
                      a_tmp = curve_data[b_k + 1];
                      loop_ub = firstCoord.size(1) - 1;
                      y.set_size(1, firstCoord.size(1));
                      for (ibmat = 0; ibmat <= loop_ub; ibmat++) {
                        y[ibmat] = firstCoord[ibmat] * y[ibmat] + a_tmp;
                      }
                    } else {
                      binary_expand_op(y, firstCoord, curve_data, b_k);
                    }
                  }
                }

                dataPts.set_size(firstCoord.size(1), 2);
                loop_ub = firstCoord.size(1);
                if (static_cast<int>(firstCoord.size(1) < 3200)) {
                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k] = firstCoord[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k] = firstCoord[k];
                  }
                }

                loop_ub = y.size(1);
                if (static_cast<int>(y.size(1) < 3200)) {
                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k + dataPts.size(0)] = y[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k + dataPts.size(0)] = y[k];
                  }
                }
              } else {
                y.set_size(1, firstCoord.size(1));
                if (firstCoord.size(1) != 0) {
                  acoef = firstCoord.size(1);
                  y.set_size(1, firstCoord.size(1));
                  loop_ub = firstCoord.size(1);
                  if (static_cast<int>(firstCoord.size(1) < 3200)) {
                    for (k = 0; k < acoef; k++) {
                      y[k] = curve_data[0];
                    }
                  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                    for (k = 0; k < loop_ub; k++) {
                      y[k] = curve_data[0];
                    }
                  }

                  b_acoef = curve_size[1];
                  for (b_k = 0; b_k <= b_acoef - 2; b_k++) {
                    if (firstCoord.size(1) == y.size(1)) {
                      a_tmp = curve_data[b_k + 1];
                      loop_ub = firstCoord.size(1) - 1;
                      y.set_size(1, firstCoord.size(1));
                      for (ibmat = 0; ibmat <= loop_ub; ibmat++) {
                        y[ibmat] = firstCoord[ibmat] * y[ibmat] + a_tmp;
                      }
                    } else {
                      binary_expand_op(y, firstCoord, curve_data, b_k);
                    }
                  }
                }

                dataPts.set_size(y.size(1), 2);
                loop_ub = y.size(1);
                if (static_cast<int>(y.size(1) < 3200)) {
                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k] = y[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k] = y[k];
                  }
                }

                loop_ub = firstCoord.size(1);
                if (static_cast<int>(firstCoord.size(1) < 3200)) {
                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k + dataPts.size(0)] = firstCoord[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (k = 0; k < loop_ub; k++) {
                    dataPts[k + dataPts.size(0)] = firstCoord[k];
                  }
                }
              }

              b_acoef = r.size(0) - 1;
              acoef = 0;
              if (i) {
                for (k = 0; k <= b_acoef; k++) {
                  if (r[k] < radius) {
                    acoef++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (k = 0; k <= b_acoef; k++) {
                    if (r[k] < radius) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    acoef += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              b_r.set_size(acoef);
              acoef = 0;
              for (b_k = 0; b_k <= b_acoef; b_k++) {
                if (r[b_k] < radius) {
                  b_r[acoef] = b_k;
                  acoef++;
                }
              }

              queryPts.set_size(b_r.size(0), Points.size(1));
              loop_ub = Points.size(1);
              for (i = 0; i < loop_ub; i++) {
                acoef = b_r.size(0);
                for (b_acoef = 0; b_acoef < acoef; b_acoef++) {
                  queryPts[b_acoef + queryPts.size(0) * i] = Points[(
                    static_cast<int>(remIdx[b_r[b_acoef]]) + Points.size(0) * i)
                    - 1];
                }
              }

              dist.set_size(b_r.size(0));
              i = b_r.size(0);
              if (b_r.size(0) - 1 >= 0) {
                b_loop_ub = Points.size(1);
                outsize_idx_1 = Points.size(1);
              }

              for (b_k = 0; b_k < i; b_k++) {
                b_a.set_size(1, Points.size(1));
                currPt.set_size(dataPts.size(0), outsize_idx_1);
                acoef = dataPts.size(0);
                for (b_acoef = 0; b_acoef < b_loop_ub; b_acoef++) {
                  b_a[b_acoef] = queryPts[b_k + queryPts.size(0) * b_acoef];
                  ibmat = b_acoef * acoef;
                  for (loop_ub = 0; loop_ub < acoef; loop_ub++) {
                    currPt[ibmat + loop_ub] = b_a[b_acoef];
                  }
                }

                if ((dataPts.size(0) == currPt.size(0)) && (currPt.size(1) == 2))
                {
                  diffs.set_size(dataPts.size(0), 2);
                  loop_ub = dataPts.size(0) << 1;
                  for (b_acoef = 0; b_acoef < loop_ub; b_acoef++) {
                    varargin_1 = static_cast<float>(dataPts[b_acoef]) -
                      currPt[b_acoef];
                    diffs[b_acoef] = varargin_1 * varargin_1;
                  }
                } else {
                  binary_expand_op(diffs, dataPts, currPt);
                }

                if (diffs.size(0) == 0) {
                  r.set_size(0);
                } else {
                  acoef = diffs.size(0);
                  r.set_size(diffs.size(0));
                  for (ibmat = 0; ibmat < acoef; ibmat++) {
                    r[ibmat] = diffs[ibmat] + diffs[acoef + ibmat];
                  }
                }

                dist[b_k] = std::sqrt(::coder::internal::minimum(r));
              }

              acoef = dist.size(0);
              if (dist.size(0) <= 2) {
                if (dist.size(0) == 1) {
                  ibmat = 1;
                } else {
                  a = dist[dist.size(0) - 1];
                  if ((dist[0] > a) || (std::isnan(dist[0]) && (!std::isnan(a))))
                  {
                    ibmat = dist.size(0);
                  } else {
                    ibmat = 1;
                  }
                }
              } else {
                if (!std::isnan(dist[0])) {
                  ibmat = 1;
                } else {
                  ibmat = 0;
                  b_k = 2;
                  exitg1 = false;
                  while ((!exitg1) && (b_k <= acoef)) {
                    if (!std::isnan(dist[b_k - 1])) {
                      ibmat = b_k;
                      exitg1 = true;
                    } else {
                      b_k++;
                    }
                  }
                }

                if (ibmat == 0) {
                  ibmat = 1;
                } else {
                  a_tmp = dist[ibmat - 1];
                  i = ibmat + 1;
                  for (b_k = i; b_k <= acoef; b_k++) {
                    a = dist[b_k - 1];
                    if (a_tmp > a) {
                      a_tmp = a;
                      ibmat = b_k;
                    }
                  }
                }
              }

              acoef = candIdx.size(0);
              if (ibmat <= acoef) {
                acoef = ibmat;
              }

              ibmat = 0;
              ii.set_size(acoef);
              b_acoef = 0;
              exitg1 = false;
              while ((!exitg1) && (b_acoef <= candIdx.size(0) - 1)) {
                if (candIdx[b_acoef]) {
                  ibmat++;
                  ii[ibmat - 1] = b_acoef + 1;
                  if (ibmat >= acoef) {
                    exitg1 = true;
                  } else {
                    b_acoef++;
                  }
                } else {
                  b_acoef++;
                }
              }

              if (acoef == 1) {
                if (ibmat == 0) {
                  ii.set_size(0);
                }
              } else {
                if (ibmat < 1) {
                  ibmat = 0;
                }

                ii.set_size(ibmat);
              }

              dist.set_size(ii.size(0));
              loop_ub = ii.size(0);
              if (static_cast<int>(ii.size(0) < 3200)) {
                for (k = 0; k < loop_ub; k++) {
                  dist[k] = ii[k];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (k = 0; k < loop_ub; k++) {
                  dist[k] = ii[k];
                }
              }

              idx.set_size(1, 1);
              idx[0] = remIdx[static_cast<int>(dist[dist.size(0) - 1]) - 1];
            } else if (acoef == 1) {
              b_acoef = r.size(0) - 1;
              acoef = 0;
              if (i) {
                for (k = 0; k <= b_acoef; k++) {
                  if (r[k] < radius) {
                    acoef++;
                  }
                }
              } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

                {
                  trueCountPrime = 0;

#pragma omp for nowait

                  for (k = 0; k <= b_acoef; k++) {
                    if (r[k] < radius) {
                      trueCountPrime++;
                    }
                  }

                  omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                  {
                    acoef += trueCountPrime;
                  }

                  omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
                }
              }

              idx.set_size(1, acoef);
              acoef = 0;
              for (b_k = 0; b_k <= b_acoef; b_k++) {
                if (r[b_k] < radius) {
                  idx[acoef] = remIdx[b_k];
                  acoef++;
                }
              }
            } else {
              idx.set_size(1, 0);
            }
          }

          void Checkerboard::findIndependentVar(double coordsToUse[2]) const
          {
            array<double, 2U> b_x;
            array<double, 2U> r2;
            array<double, 2U> x;
            array<int, 2U> r1;
            array<boolean_T, 2U> r;
            int b_i;
            int c_i;
            int end;
            int i;
            int i1;
            int loop_ub;
            int trueCountPrime;
            r.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            i = (loop_ub < 3200);
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                r[i1] = ((BoardIdx[BoardIdx.size(0) * i1] > 0.0) &&
                         (BoardIdx[BoardIdx.size(0) * i1 + 1] > 0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 < loop_ub; i1++) {
                r[i1] = ((BoardIdx[BoardIdx.size(0) * i1] > 0.0) &&
                         (BoardIdx[BoardIdx.size(0) * i1 + 1] > 0.0));
              }
            }

            end = r.size(1) - 1;
            loop_ub = 0;
            if (i) {
              for (b_i = 0; b_i <= end; b_i++) {
                if (r[b_i]) {
                  loop_ub++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= end; b_i++) {
                  if (r[b_i]) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  loop_ub += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r1.set_size(1, loop_ub);
            loop_ub = 0;
            for (c_i = 0; c_i <= end; c_i++) {
              if (r[c_i]) {
                r1[loop_ub] = c_i;
                loop_ub++;
              }
            }

            x.set_size(1, r1.size(1));
            loop_ub = r1.size(1);
            r2.set_size(1, r1.size(1));
            i = (r1.size(1) < 3200);
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                x[i1] = BoardCoords[BoardCoords.size(0) * b_i + 1];
                r2[i1] = BoardCoords[BoardCoords.size(0) * b_i];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(b_i)

              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                x[i1] = BoardCoords[BoardCoords.size(0) * b_i + 1];
                r2[i1] = BoardCoords[BoardCoords.size(0) * b_i];
              }
            }

            x.set_size(1, x.size(1));
            c_i = x.size(1) - 1;
            loop_ub = x.size(1) - 1;
            if (i) {
              for (i1 = 0; i1 <= c_i; i1++) {
                x[i1] = x[i1] - r2[i1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 <= loop_ub; i1++) {
                x[i1] = x[i1] - r2[i1];
              }
            }

            b_x.set_size(1, r1.size(1));
            loop_ub = r1.size(1);
            r2.set_size(1, r1.size(1));
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                b_x[i1] = BoardCoords[(b_i + BoardCoords.size(1)) *
                  BoardCoords.size(0) + 1];
                r2[i1] = BoardCoords[(b_i + BoardCoords.size(1)) *
                  BoardCoords.size(0)];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(b_i)

              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                b_x[i1] = BoardCoords[(b_i + BoardCoords.size(1)) *
                  BoardCoords.size(0) + 1];
                r2[i1] = BoardCoords[(b_i + BoardCoords.size(1)) *
                  BoardCoords.size(0)];
              }
            }

            b_x.set_size(1, b_x.size(1));
            if (i) {
              for (i1 = 0; i1 <= c_i; i1++) {
                b_x[i1] = b_x[i1] - r2[i1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 <= c_i; i1++) {
                b_x[i1] = b_x[i1] - r2[i1];
              }
            }

            if (std::abs(combineVectorElements(x) / static_cast<double>(x.size(1)))
                > std::abs(combineVectorElements(b_x) / static_cast<double>
                           (b_x.size(1)))) {
              coordsToUse[0] = 1.0;
              coordsToUse[1] = 2.0;
            } else {
              coordsToUse[0] = 2.0;
              coordsToUse[1] = 1.0;
            }
          }

          void Checkerboard::findIndependentVar(const ::coder::array<double, 2U>
            &idx, double coordsToUse[2]) const
          {
            array<double, 2U> b_x;
            array<double, 2U> r2;
            array<double, 2U> x;
            array<int, 2U> r1;
            array<boolean_T, 2U> r;
            int b_i;
            int b_idx_tmp;
            int end;
            int i;
            int i1;
            int idx_tmp;
            int loop_ub;
            int trueCount;
            int trueCountPrime;
            idx_tmp = static_cast<int>(idx[0]);
            b_idx_tmp = static_cast<int>(idx[1]);
            r.set_size(1, BoardIdx.size(1));
            loop_ub = BoardIdx.size(1);
            i = (loop_ub < 3200);
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                r[i1] = ((BoardIdx[(idx_tmp + BoardIdx.size(0) * i1) - 1] > 0.0)
                         && (BoardIdx[(b_idx_tmp + BoardIdx.size(0) * i1) - 1] >
                             0.0));
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 < loop_ub; i1++) {
                r[i1] = ((BoardIdx[(idx_tmp + BoardIdx.size(0) * i1) - 1] > 0.0)
                         && (BoardIdx[(b_idx_tmp + BoardIdx.size(0) * i1) - 1] >
                             0.0));
              }
            }

            end = r.size(1) - 1;
            trueCount = 0;
            if (i) {
              for (b_i = 0; b_i <= end; b_i++) {
                if (r[b_i]) {
                  trueCount++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= end; b_i++) {
                  if (r[b_i]) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  trueCount += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r1.set_size(1, trueCount);
            trueCount = 0;
            for (loop_ub = 0; loop_ub <= end; loop_ub++) {
              if (r[loop_ub]) {
                r1[trueCount] = loop_ub;
                trueCount++;
              }
            }

            x.set_size(1, r1.size(1));
            loop_ub = r1.size(1);
            r2.set_size(1, r1.size(1));
            i = (r1.size(1) < 3200);
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                x[i1] = BoardCoords[(b_idx_tmp + BoardCoords.size(0) * b_i) - 1];
                r2[i1] = BoardCoords[(idx_tmp + BoardCoords.size(0) * b_i) - 1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(b_i)

              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                x[i1] = BoardCoords[(b_idx_tmp + BoardCoords.size(0) * b_i) - 1];
                r2[i1] = BoardCoords[(idx_tmp + BoardCoords.size(0) * b_i) - 1];
              }
            }

            x.set_size(1, x.size(1));
            trueCount = x.size(1) - 1;
            loop_ub = x.size(1) - 1;
            if (i) {
              for (i1 = 0; i1 <= trueCount; i1++) {
                x[i1] = x[i1] - r2[i1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 <= loop_ub; i1++) {
                x[i1] = x[i1] - r2[i1];
              }
            }

            b_x.set_size(1, r1.size(1));
            loop_ub = r1.size(1);
            r2.set_size(1, r1.size(1));
            if (i) {
              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                b_x[i1] = BoardCoords[((b_idx_tmp + BoardCoords.size(0) * b_i) +
                  BoardCoords.size(0) * BoardCoords.size(1)) - 1];
                r2[i1] = BoardCoords[((idx_tmp + BoardCoords.size(0) * b_i) +
                                      BoardCoords.size(0) * BoardCoords.size(1))
                  - 1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(b_i)

              for (i1 = 0; i1 < loop_ub; i1++) {
                b_i = r1[i1];
                b_x[i1] = BoardCoords[((b_idx_tmp + BoardCoords.size(0) * b_i) +
                  BoardCoords.size(0) * BoardCoords.size(1)) - 1];
                r2[i1] = BoardCoords[((idx_tmp + BoardCoords.size(0) * b_i) +
                                      BoardCoords.size(0) * BoardCoords.size(1))
                  - 1];
              }
            }

            b_x.set_size(1, b_x.size(1));
            if (i) {
              for (i1 = 0; i1 <= trueCount; i1++) {
                b_x[i1] = b_x[i1] - r2[i1];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (i1 = 0; i1 <= trueCount; i1++) {
                b_x[i1] = b_x[i1] - r2[i1];
              }
            }

            if (std::abs(combineVectorElements(x) / static_cast<double>(x.size(1)))
                > std::abs(combineVectorElements(b_x) / static_cast<double>
                           (b_x.size(1)))) {
              coordsToUse[0] = 1.0;
              coordsToUse[1] = 2.0;
            } else {
              coordsToUse[0] = 2.0;
              coordsToUse[1] = 1.0;
            }
          }

          double Checkerboard::findNeighbor(const ::coder::array<float, 2U>
            &pointVectors, const ::coder::array<float, 1U> &euclideanDists,
            const ::coder::array<float, 2U> &v) const
          {
            array<float, 1U> angleCosines;
            array<float, 1U> dists;
            array<int, 1U> r;
            double neighborIdx;
            float b;
            int aoffset;
            int b_i;
            int c_i;
            int i;
            int inner;
            int k;
            int mc;
            int trueCountPrime;
            mc = pointVectors.size(0) - 1;
            inner = pointVectors.size(1);
            angleCosines.set_size(pointVectors.size(0));
            i = (pointVectors.size(0) < 3200);
            if (i) {
              for (b_i = 0; b_i <= mc; b_i++) {
                angleCosines[b_i] = 0.0F;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i <= mc; b_i++) {
                angleCosines[b_i] = 0.0F;
              }
            }

            for (k = 0; k < inner; k++) {
              aoffset = k * pointVectors.size(0);
              for (c_i = 0; c_i <= mc; c_i++) {
                angleCosines[c_i] = angleCosines[c_i] + pointVectors[aoffset +
                  c_i] * v[k];
              }
            }

            b = rt_hypotf_snf(v[0], v[1]);
            if (angleCosines.size(0) == euclideanDists.size(0)) {
              aoffset = angleCosines.size(0);
              if (i) {
                for (b_i = 0; b_i < aoffset; b_i++) {
                  angleCosines[b_i] = angleCosines[b_i] / (euclideanDists[b_i] *
                    b);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < aoffset; b_i++) {
                  angleCosines[b_i] = angleCosines[b_i] / (euclideanDists[b_i] *
                    b);
                }
              }
            } else {
              binary_expand_op(angleCosines, euclideanDists, b);
            }

            if (euclideanDists.size(0) == 1) {
              i = angleCosines.size(0);
            } else {
              i = euclideanDists.size(0);
            }

            if ((euclideanDists.size(0) == angleCosines.size(0)) &&
                (euclideanDists.size(0) == i)) {
              dists.set_size(euclideanDists.size(0));
              aoffset = euclideanDists.size(0);
              if (static_cast<int>(euclideanDists.size(0) < 3200)) {
                for (b_i = 0; b_i < aoffset; b_i++) {
                  dists[b_i] = euclideanDists[b_i] + 1.5F * euclideanDists[b_i] *
                    (1.0F - angleCosines[b_i]);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < aoffset; b_i++) {
                  dists[b_i] = euclideanDists[b_i] + 1.5F * euclideanDists[b_i] *
                    (1.0F - angleCosines[b_i]);
                }
              }
            } else {
              binary_expand_op(dists, euclideanDists, angleCosines);
            }

            mc = BoardIdx.size(0) * BoardIdx.size(1) - 1;
            aoffset = 0;
            if (static_cast<int>(mc + 1 < 3200)) {
              for (b_i = 0; b_i <= mc; b_i++) {
                if (BoardIdx[b_i] > 0.0) {
                  aoffset++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= mc; b_i++) {
                  if (BoardIdx[b_i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  aoffset += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(aoffset);
            aoffset = 0;
            for (c_i = 0; c_i <= mc; c_i++) {
              if (BoardIdx[c_i] > 0.0) {
                r[aoffset] = static_cast<int>(BoardIdx[c_i]);
                aoffset++;
              }
            }

            aoffset = r.size(0);
            for (i = 0; i < aoffset; i++) {
              dists[r[i] - 1] = rtInfF;
            }

            mc = angleCosines.size(0) - 1;
            if (static_cast<int>(angleCosines.size(0) < 3200)) {
              for (b_i = 0; b_i <= mc; b_i++) {
                if (angleCosines[b_i] < 0.0F) {
                  dists[b_i] = rtInfF;
                }
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i <= mc; b_i++) {
                if (angleCosines[b_i] < 0.0F) {
                  dists[b_i] = rtInfF;
                }
              }
            }

            b = ::coder::internal::minimum(dists, aoffset);
            neighborIdx = aoffset;
            if (std::isinf(b)) {
              neighborIdx = -1.0;
            }

            return neighborIdx;
          }

          double Checkerboard::findNeighbor(const ::coder::array<float, 2U>
            &pointVectors, const ::coder::array<float, 1U> &euclideanDists,
            const float v[2]) const
          {
            array<float, 1U> angleCosines;
            array<float, 1U> dists;
            array<int, 1U> r;
            double neighborIdx;
            float b;
            int aoffset;
            int b_i;
            int c_i;
            int i;
            int inner;
            int k;
            int mc;
            int trueCountPrime;
            mc = pointVectors.size(0) - 1;
            inner = pointVectors.size(1);
            angleCosines.set_size(pointVectors.size(0));
            i = (pointVectors.size(0) < 3200);
            if (i) {
              for (b_i = 0; b_i <= mc; b_i++) {
                angleCosines[b_i] = 0.0F;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i <= mc; b_i++) {
                angleCosines[b_i] = 0.0F;
              }
            }

            for (k = 0; k < inner; k++) {
              aoffset = k * pointVectors.size(0);
              for (c_i = 0; c_i <= mc; c_i++) {
                angleCosines[c_i] = angleCosines[c_i] + pointVectors[aoffset +
                  c_i] * v[k];
              }
            }

            b = rt_hypotf_snf(v[0], v[1]);
            if (angleCosines.size(0) == euclideanDists.size(0)) {
              aoffset = angleCosines.size(0);
              if (i) {
                for (b_i = 0; b_i < aoffset; b_i++) {
                  angleCosines[b_i] = angleCosines[b_i] / (euclideanDists[b_i] *
                    b);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < aoffset; b_i++) {
                  angleCosines[b_i] = angleCosines[b_i] / (euclideanDists[b_i] *
                    b);
                }
              }
            } else {
              binary_expand_op(angleCosines, euclideanDists, b);
            }

            if (euclideanDists.size(0) == 1) {
              i = angleCosines.size(0);
            } else {
              i = euclideanDists.size(0);
            }

            if ((euclideanDists.size(0) == angleCosines.size(0)) &&
                (euclideanDists.size(0) == i)) {
              dists.set_size(euclideanDists.size(0));
              aoffset = euclideanDists.size(0);
              if (static_cast<int>(euclideanDists.size(0) < 3200)) {
                for (b_i = 0; b_i < aoffset; b_i++) {
                  dists[b_i] = euclideanDists[b_i] + 1.5F * euclideanDists[b_i] *
                    (1.0F - angleCosines[b_i]);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (b_i = 0; b_i < aoffset; b_i++) {
                  dists[b_i] = euclideanDists[b_i] + 1.5F * euclideanDists[b_i] *
                    (1.0F - angleCosines[b_i]);
                }
              }
            } else {
              binary_expand_op(dists, euclideanDists, angleCosines);
            }

            mc = BoardIdx.size(0) * BoardIdx.size(1) - 1;
            aoffset = 0;
            if (static_cast<int>(mc + 1 < 3200)) {
              for (b_i = 0; b_i <= mc; b_i++) {
                if (BoardIdx[b_i] > 0.0) {
                  aoffset++;
                }
              }
            } else {

#pragma omp parallel \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(trueCountPrime)

              {
                trueCountPrime = 0;

#pragma omp for nowait

                for (b_i = 0; b_i <= mc; b_i++) {
                  if (BoardIdx[b_i] > 0.0) {
                    trueCountPrime++;
                  }
                }

                omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);

                {
                  aoffset += trueCountPrime;
                }

                omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
              }
            }

            r.set_size(aoffset);
            aoffset = 0;
            for (c_i = 0; c_i <= mc; c_i++) {
              if (BoardIdx[c_i] > 0.0) {
                r[aoffset] = static_cast<int>(BoardIdx[c_i]);
                aoffset++;
              }
            }

            aoffset = r.size(0);
            for (i = 0; i < aoffset; i++) {
              dists[r[i] - 1] = rtInfF;
            }

            mc = angleCosines.size(0) - 1;
            if (static_cast<int>(angleCosines.size(0) < 3200)) {
              for (b_i = 0; b_i <= mc; b_i++) {
                if (angleCosines[b_i] < 0.0F) {
                  dists[b_i] = rtInfF;
                }
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (b_i = 0; b_i <= mc; b_i++) {
                if (angleCosines[b_i] < 0.0F) {
                  dists[b_i] = rtInfF;
                }
              }
            }

            b = ::coder::internal::minimum(dists, aoffset);
            neighborIdx = aoffset;
            if (std::isinf(b)) {
              neighborIdx = -1.0;
            }

            return neighborIdx;
          }

          double Checkerboard::findSearchParams(const ::coder::array<double, 2U>
            &idx, const ::coder::array<double, 1U> &validIdx, double currIdx,
            const double coordsToUse[2], double &moveMultiplier, double
            &firstValidIdx) const
          {
            double coordDist;
            if (idx[0] == 1.0) {
              moveMultiplier = validIdx[0];
              firstValidIdx = validIdx[0];
              coordDist = (BoardCoords[((static_cast<int>(validIdx[0]) +
                BoardCoords.size(0) * (static_cast<int>(currIdx) - 1)) +
                BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                (coordsToUse[0]) - 1)) - 1] - BoardCoords[((static_cast<int>
                (validIdx[1]) + BoardCoords.size(0) * (static_cast<int>(currIdx)
                - 1)) + BoardCoords.size(0) * BoardCoords.size(1) * (
                static_cast<int>(coordsToUse[0]) - 1)) - 1]) / (validIdx[1] -
                validIdx[0]);
            } else {
              double coordDist_tmp;
              firstValidIdx = validIdx[validIdx.size(0) - 1];
              moveMultiplier = (static_cast<double>(BoardCoords.size(0)) -
                                firstValidIdx) + 1.0;
              coordDist_tmp = validIdx[validIdx.size(0) - 2];
              coordDist = (BoardCoords[((static_cast<int>(firstValidIdx) +
                BoardCoords.size(0) * (static_cast<int>(currIdx) - 1)) +
                BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                (coordsToUse[0]) - 1)) - 1] - BoardCoords[((static_cast<int>
                (coordDist_tmp) + BoardCoords.size(0) * (static_cast<int>
                (currIdx) - 1)) + BoardCoords.size(0) * BoardCoords.size(1) * (
                static_cast<int>(coordsToUse[0]) - 1)) - 1]) / (firstValidIdx -
                coordDist_tmp);
            }

            return coordDist;
          }

          double Checkerboard::findSearchParams(const ::coder::array<double, 2U>
            &idx, const ::coder::array<double, 2U> &validIdx, double currIdx,
            const double coordsToUse[2], double &moveMultiplier, double
            &firstValidIdx) const
          {
            double coordDist;
            if (idx[0] == 1.0) {
              moveMultiplier = validIdx[0];
              firstValidIdx = validIdx[0];
              coordDist = (BoardCoords[((static_cast<int>(currIdx) +
                BoardCoords.size(0) * (static_cast<int>(validIdx[0]) - 1)) +
                BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                (coordsToUse[0]) - 1)) - 1] - BoardCoords[((static_cast<int>
                (currIdx) + BoardCoords.size(0) * (static_cast<int>(validIdx[1])
                - 1)) + BoardCoords.size(0) * BoardCoords.size(1) * (
                static_cast<int>(coordsToUse[0]) - 1)) - 1]) / (validIdx[1] -
                validIdx[0]);
            } else {
              double coordDist_tmp;
              firstValidIdx = validIdx[validIdx.size(1) - 1];
              moveMultiplier = (static_cast<double>(BoardCoords.size(1)) -
                                firstValidIdx) + 1.0;
              coordDist_tmp = validIdx[validIdx.size(1) - 2];
              coordDist = (BoardCoords[((static_cast<int>(currIdx) +
                BoardCoords.size(0) * (static_cast<int>(firstValidIdx) - 1)) +
                BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                (coordsToUse[0]) - 1)) - 1] - BoardCoords[((static_cast<int>
                (currIdx) + BoardCoords.size(0) * (static_cast<int>
                (coordDist_tmp) - 1)) + BoardCoords.size(0) * BoardCoords.size(1)
                * (static_cast<int>(coordsToUse[0]) - 1)) - 1]) / (firstValidIdx
                - coordDist_tmp);
            }

            return coordDist;
          }

          void Checkerboard::fitPolynomialIndices(::coder::array<double, 2U>
            &newIndices) const
          {
            array<double, 2U> b_index;
            array<double, 2U> removedIdx;
            array<double, 1U> b_this;
            array<double, 1U> c_this;
            array<int, 1U> validIdx;
            double currCurve_data[5];
            double coordsToUse[2];
            int i1;
            int loop_ub;
            findIndependentVar(coordsToUse);
            newIndices.set_size(1, BoardCoords.size(1));
            loop_ub = BoardCoords.size(1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (int i{0}; i < loop_ub; i++) {
                newIndices[i] = 0.0;
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int i = 0; i < loop_ub; i++) {
                newIndices[i] = 0.0;
              }
            }

            removedIdx.set_size(1, 0);
            i1 = BoardCoords.size(1);
            for (int j{0}; j < i1; j++) {
              int i2;
              b_this.set_size(BoardCoords.size(0));
              loop_ub = BoardCoords.size(0);
              for (i2 = 0; i2 < loop_ub; i2++) {
                b_this[i2] = BoardCoords[(i2 + BoardCoords.size(0) * j) +
                  BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<int>
                  (coordsToUse[0]) - 1)];
              }

              eml_find(b_this, validIdx);
              if (validIdx.size(0) >= 2) {
                double coordDist;
                double coordDist_tmp;
                double currCoord;
                double currRad;
                int currCurve_size[2];
                int k;
                boolean_T exitg1;
                currRad = coordsToUse[0];
                coordDist_tmp = BoardCoords[((validIdx[0] + BoardCoords.size(0) *
                  j) + BoardCoords.size(0) * BoardCoords.size(1) * (static_cast<
                  int>(coordsToUse[0]) - 1)) - 1];
                coordDist = (coordDist_tmp - BoardCoords[((validIdx[1] +
                  BoardCoords.size(0) * j) + BoardCoords.size(0) *
                  BoardCoords.size(1) * (static_cast<int>(coordsToUse[0]) - 1))
                             - 1]) / (static_cast<double>(validIdx[1]) -
                                      static_cast<double>(validIdx[0]));
                loop_ub = 0;
                i2 = validIdx.size(0);
                b_this.set_size(validIdx.size(0));
                c_this.set_size(validIdx.size(0));
                for (k = 0; k < i2; k++) {
                  if (validIdx[k] != 0) {
                    loop_ub++;
                  }

                  b_this[k] = BoardCoords[((validIdx[k] + BoardCoords.size(0) *
                    j) + BoardCoords.size(0) * BoardCoords.size(1) * (
                    static_cast<int>(currRad) - 1)) - 1];
                  c_this[k] = BoardCoords[((validIdx[k] + BoardCoords.size(0) *
                    j) + BoardCoords.size(0) * BoardCoords.size(1) * (
                    static_cast<int>(coordsToUse[1]) - 1)) - 1];
                }

                if (loop_ub > 5) {
                  i2 = 4;
                } else {
                  i2 = 2;
                }

                polyfit(b_this, c_this, static_cast<double>(i2), currCurve_data,
                        currCurve_size);
                currRad = coordDist / 4.0;
                currCoord = currRad + coordDist_tmp;
                exitg1 = false;
                while ((!exitg1) && (std::abs(currCoord - coordDist_tmp) <
                                     static_cast<double>(validIdx[0]) * 1.5 *
                                     std::abs(coordDist))) {
                  double currPt[2];
                  boolean_T exitg2;
                  boolean_T p;
                  p = true;
                  k = 0;
                  exitg2 = false;
                  while ((!exitg2) && (k < 2)) {
                    if (!(coordsToUse[k] == static_cast<double>(k) + 1.0)) {
                      p = false;
                      exitg2 = true;
                    } else {
                      k++;
                    }
                  }

                  if (p) {
                    double y;
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (k = 0; k <= i2 - 2; k++) {
                      y = currCoord * y + currCurve_data[k + 1];
                    }

                    currPt[0] = currCoord;
                    currPt[1] = y;
                  } else {
                    double y;
                    y = currCurve_data[0];
                    i2 = currCurve_size[1];
                    for (k = 0; k <= i2 - 2; k++) {
                      y = currCoord * y + currCurve_data[k + 1];
                    }

                    currPt[0] = y;
                    currPt[1] = currCoord;
                  }

                  findClosestOnCurve(currPt, std::abs(currRad), currCurve_data,
                                     currCurve_size, coordsToUse, removedIdx,
                                     b_index);
                  if (b_index.size(1) != 0) {
                    newIndices[j] = b_index[0];
                    i2 = removedIdx.size(1);
                    loop_ub = b_index.size(1);
                    removedIdx.set_size(removedIdx.size(0), removedIdx.size(1) +
                                        b_index.size(1));
                    for (k = 0; k < loop_ub; k++) {
                      removedIdx[i2 + k] = b_index[k];
                    }

                    exitg1 = true;
                  } else {
                    currCoord += currRad;
                  }
                }
              }
            }
          }

          void Checkerboard::undoLastExpansion()
          {
            Energy = PreviousEnergy;
            switch (static_cast<int>(LastExpandDirection)) {
             case 1:
              {
                int b_this;
                int c_this;
                int i;
                int i1;
                int loop_ub_tmp;
                i = BoardIdx.size(0);
                if (i < 2) {
                  i1 = -1;
                  i = -1;
                } else {
                  i1 = 0;
                  i--;
                }

                b_this = BoardIdx.size(1);
                for (int i2{0}; i2 < b_this; i2++) {
                  loop_ub_tmp = i - i1;
                  for (int i3{0}; i3 < loop_ub_tmp; i3++) {
                    BoardIdx[i3 + loop_ub_tmp * i2] = BoardIdx[((i1 + i3) +
                      BoardIdx.size(0) * i2) + 1];
                  }
                }

                BoardIdx.set_size(i - i1, b_this);
                i = BoardCoords.size(0);
                if (i < 2) {
                  i1 = -1;
                  i = -1;
                } else {
                  i1 = 0;
                  i--;
                }

                b_this = BoardCoords.size(1);
                c_this = BoardCoords.size(2);
                for (int i2{0}; i2 < c_this; i2++) {
                  for (int i3{0}; i3 < b_this; i3++) {
                    loop_ub_tmp = i - i1;
                    for (int i4{0}; i4 < loop_ub_tmp; i4++) {
                      BoardCoords[(i4 + loop_ub_tmp * i3) + loop_ub_tmp * b_this
                        * i2] = BoardCoords[(((i1 + i4) + BoardCoords.size(0) *
                        i3) + BoardCoords.size(0) * BoardCoords.size(1) * i2) +
                        1];
                    }
                  }
                }

                BoardCoords.set_size(i - i1, b_this, c_this);
              }
              break;

             case 2:
              {
                int b_this;
                int c_this;
                int i;
                int loop_ub_tmp;
                i = BoardIdx.size(0) - 2;
                if (i + 1 < 1) {
                  loop_ub_tmp = 0;
                } else {
                  loop_ub_tmp = i + 1;
                }

                b_this = BoardIdx.size(1);
                for (i = 0; i < b_this; i++) {
                  for (int i1{0}; i1 < loop_ub_tmp; i1++) {
                    BoardIdx[i1 + loop_ub_tmp * i] = BoardIdx[i1 + BoardIdx.size
                      (0) * i];
                  }
                }

                BoardIdx.set_size(loop_ub_tmp, b_this);
                i = BoardCoords.size(0) - 2;
                if (i + 1 < 1) {
                  loop_ub_tmp = 0;
                } else {
                  loop_ub_tmp = i + 1;
                }

                b_this = BoardCoords.size(1);
                c_this = BoardCoords.size(2);
                for (i = 0; i < c_this; i++) {
                  for (int i1{0}; i1 < b_this; i1++) {
                    for (int i2{0}; i2 < loop_ub_tmp; i2++) {
                      BoardCoords[(i2 + loop_ub_tmp * i1) + loop_ub_tmp * b_this
                        * i] = BoardCoords[(i2 + BoardCoords.size(0) * i1) +
                        BoardCoords.size(0) * BoardCoords.size(1) * i];
                    }
                  }
                }

                BoardCoords.set_size(loop_ub_tmp, b_this, c_this);
              }
              break;

             case 3:
              {
                int b_this;
                int c_this;
                int i;
                int i1;
                int loop_ub_tmp;
                i = BoardIdx.size(1);
                if (i < 2) {
                  i1 = 0;
                  i = 0;
                } else {
                  i1 = 1;
                }

                b_this = BoardIdx.size(0);
                loop_ub_tmp = i - i1;
                for (i = 0; i < loop_ub_tmp; i++) {
                  for (int i2{0}; i2 < b_this; i2++) {
                    BoardIdx[i2 + b_this * i] = BoardIdx[i2 + BoardIdx.size(0) *
                      (i1 + i)];
                  }
                }

                BoardIdx.set_size(b_this, loop_ub_tmp);
                i = BoardCoords.size(1);
                if (i < 2) {
                  i1 = -1;
                  i = -1;
                } else {
                  i1 = 0;
                  i--;
                }

                b_this = BoardCoords.size(0);
                c_this = BoardCoords.size(2);
                for (int i2{0}; i2 < c_this; i2++) {
                  loop_ub_tmp = i - i1;
                  for (int i3{0}; i3 < loop_ub_tmp; i3++) {
                    for (int i4{0}; i4 < b_this; i4++) {
                      BoardCoords[(i4 + b_this * i3) + b_this * loop_ub_tmp * i2]
                        = BoardCoords[(i4 + BoardCoords.size(0) * ((i1 + i3) + 1))
                        + BoardCoords.size(0) * BoardCoords.size(1) * i2];
                    }
                  }
                }

                BoardCoords.set_size(b_this, i - i1, c_this);
              }
              break;

             case 4:
              {
                int b_this;
                int c_this;
                int i;
                int loop_ub_tmp;
                i = BoardIdx.size(1) - 2;
                if (i + 1 < 1) {
                  loop_ub_tmp = -1;
                } else {
                  loop_ub_tmp = i;
                }

                b_this = BoardIdx.size(0);
                for (i = 0; i <= loop_ub_tmp; i++) {
                  for (int i1{0}; i1 < b_this; i1++) {
                    BoardIdx[i1 + b_this * i] = BoardIdx[i1 + BoardIdx.size(0) *
                      i];
                  }
                }

                BoardIdx.set_size(b_this, loop_ub_tmp + 1);
                i = BoardCoords.size(1) - 2;
                if (i + 1 < 1) {
                  loop_ub_tmp = 0;
                } else {
                  loop_ub_tmp = i + 1;
                }

                b_this = BoardCoords.size(0);
                c_this = BoardCoords.size(2);
                for (i = 0; i < c_this; i++) {
                  for (int i1{0}; i1 < loop_ub_tmp; i1++) {
                    for (int i2{0}; i2 < b_this; i2++) {
                      BoardCoords[(i2 + b_this * i1) + b_this * loop_ub_tmp * i]
                        = BoardCoords[(i2 + BoardCoords.size(0) * i1) +
                        BoardCoords.size(0) * BoardCoords.size(1) * i];
                    }
                  }
                }

                BoardCoords.set_size(b_this, loop_ub_tmp, c_this);
              }
              break;
            }
          }
        }
      }
    }
  }
}

static void b_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5)
{
  coder::array<float, 2U> b_in4;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in5.size(1) == 1) {
    loop_ub = in4.size(1);
  } else {
    loop_ub = in5.size(1);
  }

  b_in4.set_size(1, loop_ub);
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (in5.size(1) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  }

  in1->BoardIdx[in1->BoardIdx.size(0) * 2 + 2] = in1->findNeighbor(in2, in3,
    b_in4);
}

static void binary_expand_op(coder::vision::internal::calibration::checkerboard::
  Checkerboard *in1, const coder::array<float, 2U> &in2, const coder::array<
  float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::array<float,
  2U> &in5)
{
  coder::array<float, 2U> b_in4;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in5.size(1) == 1) {
    loop_ub = in4.size(1);
  } else {
    loop_ub = in5.size(1);
  }

  b_in4.set_size(1, loop_ub);
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (in5.size(1) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  }

  in1->BoardIdx[in1->BoardIdx.size(0) * 2] = in1->findNeighbor(in2, in3, b_in4);
}

static void binary_expand_op(coder::array<double, 2U> &in1, const coder::array<
  double, 2U> &in2, const coder::array<double, 2U> &in3)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }

  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }

  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double d;
      d = in2[i1 * stride_0_0 + in2.size(0) * aux_0_1];
      in1[i1 + in1.size(0) * i] = (d + d) - in3[i1 * stride_1_0 + in3.size(0) *
        aux_1_1];
    }

    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op(coder::array<double, 2U> &in1, const coder::vision::
  internal::calibration::checkerboard::Checkerboard *in2, const coder::array<
  double, 2U> &in3, const coder::array<double, 2U> &in4)
{
  coder::array<double, 2U> b_in3;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in4.size(0) == 1) {
    loop_ub = in3.size(0);
  } else {
    loop_ub = in4.size(0);
  }

  if (in4.size(1) == 1) {
    b_loop_ub = in3.size(1);
  } else {
    b_loop_ub = in4.size(1);
  }

  b_in3.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in3.size(0) != 1);
  stride_0_1 = (in3.size(1) != 1);
  stride_1_0 = (in4.size(0) != 1);
  stride_1_1 = (in4.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      double in3_tmp;
      in3_tmp = in3[i1 * stride_0_0 + in3.size(0) * aux_0_1];
      b_in3[i1 + b_in3.size(0) * i] = (in3_tmp + in3_tmp) - in4[i1 * stride_1_0
        + in4.size(0) * aux_1_1];
    }

    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }

  in2->findClosestIndices(b_in3, in1);
}

static void binary_expand_op(coder::array<float, 1U> &in1, const coder::array<
  float, 1U> &in2, const coder::array<float, 1U> &in3)
{
  float f1;
  int loop_ub;
  int stride_0_0_tmp;
  int stride_2_0;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }

  if (loop_ub == 1) {
    loop_ub = in2.size(0);
  }

  in1.set_size(loop_ub);
  stride_0_0_tmp = (in2.size(0) != 1);
  stride_2_0 = (in3.size(0) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      float f;
      f = in2[i * stride_0_0_tmp];
      in1[i] = f + 1.5F * f * (1.0F - in3[i * stride_2_0]);
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32) \
 private(f1)

    for (int i = 0; i < loop_ub; i++) {
      f1 = in2[i * stride_0_0_tmp];
      in1[i] = f1 + 1.5F * f1 * (1.0F - in3[i * stride_2_0]);
    }
  }
}

static void binary_expand_op(coder::array<double, 2U> &in1, const coder::array<
  double, 3U> &in2, const coder::array<double, 3U> &in3, const coder::array<
  double, 3U> &in4)
{
  coder::array<double, 3U> b_in2;
  int aux_0_2;
  int aux_1_2;
  int b_loop_ub;
  int loop_ub;
  int stride_0_1;
  int stride_0_2;
  int stride_1_1;
  int stride_1_2;
  if (in4.size(1) == 1) {
    loop_ub = in2.size(1);
  } else {
    loop_ub = in4.size(1);
  }

  if (in4.size(2) == 1) {
    b_loop_ub = in2.size(2);
  } else {
    b_loop_ub = in4.size(2);
  }

  b_in2.set_size(1, loop_ub, b_loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_0_2 = (in2.size(2) != 1);
  stride_1_1 = (in4.size(1) != 1);
  stride_1_2 = (in4.size(2) != 1);
  aux_0_2 = 0;
  aux_1_2 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      int in2_tmp;
      in2_tmp = i1 * stride_0_1;
      b_in2[i1 + b_in2.size(1) * i] = (in2[in2_tmp + in2.size(1) * aux_0_2] +
        in3[in2_tmp + in3.size(1) * aux_0_2]) - 2.0 * in4[i1 * stride_1_1 +
        in4.size(1) * aux_1_2];
    }

    aux_1_2 += stride_1_2;
    aux_0_2 += stride_0_2;
  }

  coder::squeeze(b_in2, in1);
}

static void binary_expand_op(coder::array<float, 2U> &in1, const coder::vision::
  internal::calibration::checkerboard::Checkerboard *in2, double in3)
{
  coder::array<float, 2U> b_in1;
  int b_in3;
  int i;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  b_in3 = static_cast<int>(in3);
  if (in2->Points.size(1) == 1) {
    loop_ub = in1.size(1);
  } else {
    loop_ub = in2->Points.size(1);
  }

  b_in1.set_size(1, loop_ub);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_1 = (in2->Points.size(1) != 1);
  i = (loop_ub < 3200);
  if (i) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1] = in1[i1 * stride_0_1] - in2->Points[(static_cast<int>(in3) +
        in2->Points.size(0) * (i1 * stride_1_1)) - 1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      b_in1[i1] = in1[i1 * stride_0_1] - in2->Points[(b_in3 + in2->Points.size(0)
        * (i1 * stride_1_1)) - 1];
    }
  }

  in1.set_size(1, b_in1.size(1));
  loop_ub = b_in1.size(1);
  if (i) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1] = b_in1[i1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      in1[i1] = b_in1[i1];
    }
  }
}

static void c_binary_expand_op(coder::array<float, 2U> &in1, const coder::array<
  float, 2U> &in2, const coder::array<float, 2U> &in3)
{
  coder::array<float, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  int stride_2_1;
  if (in1.size(1) == 1) {
    if (in3.size(1) == 1) {
      loop_ub = in2.size(1);
    } else {
      loop_ub = in3.size(1);
    }
  } else {
    loop_ub = in1.size(1);
  }

  b_in2.set_size(3, loop_ub);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_1 = (in3.size(1) != 1);
  stride_2_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < loop_ub; i++) {
    b_in2[3 * i] = (in2[3 * aux_0_1] + in3[3 * aux_1_1]) - 2.0F * in1[3 *
      aux_2_1];
    b_in2[3 * i + 1] = (in2[3 * aux_0_1 + 1] + in3[3 * aux_1_1 + 1]) - 2.0F *
      in1[3 * aux_2_1 + 1];
    b_in2[3 * i + 2] = (in2[3 * aux_0_1 + 2] + in3[3 * aux_1_1 + 2]) - 2.0F *
      in1[3 * aux_2_1 + 2];
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }

  in1.set_size(3, b_in2.size(1));
  loop_ub = b_in2.size(1);
  if (static_cast<int>(b_in2.size(1) * 3 < 3200)) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[3 * i1] = b_in2[3 * i1];
      in1[3 * i1 + 1] = b_in2[3 * i1 + 1];
      in1[3 * i1 + 2] = b_in2[3 * i1 + 2];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      in1[3 * i1] = b_in2[3 * i1];
      in1[3 * i1 + 1] = b_in2[3 * i1 + 1];
      in1[3 * i1 + 2] = b_in2[3 * i1 + 2];
    }
  }
}

static void c_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5)
{
  coder::array<float, 2U> b_in4;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in5.size(1) == 1) {
    loop_ub = in4.size(1);
  } else {
    loop_ub = in5.size(1);
  }

  b_in4.set_size(1, loop_ub);
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (in5.size(1) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  }

  in1->BoardIdx[2] = in1->findNeighbor(in2, in3, b_in4);
}

static void d_binary_expand_op(coder::vision::internal::calibration::
  checkerboard::Checkerboard *in1, const coder::array<float, 2U> &in2, const
  coder::array<float, 1U> &in3, const coder::array<float, 2U> &in4, const coder::
  array<float, 2U> &in5)
{
  coder::array<float, 2U> b_in4;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in5.size(1) == 1) {
    loop_ub = in4.size(1);
  } else {
    loop_ub = in5.size(1);
  }

  b_in4.set_size(1, loop_ub);
  stride_0_1 = (in4.size(1) != 1);
  stride_1_1 = (in5.size(1) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub; i++) {
      b_in4[i] = in4[i * stride_0_1] + in5[i * stride_1_1];
    }
  }

  in1->BoardIdx[0] = in1->findNeighbor(in2, in3, b_in4);
}

static void e_binary_expand_op(coder::array<boolean_T, 1U> &in1, const coder::
  array<double, 2U> &in2, const coder::array<double, 2U> &in3)
{
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }

  in1.set_size(loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_1_0 = (in3.size(0) != 1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int i{0}; i < loop_ub; i++) {
      in1[i] = ((in2[i * stride_0_0] == 0.0) || (in3[i * stride_1_0] == 0.0));
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub; i++) {
      in1[i] = ((in2[i * stride_0_0] == 0.0) || (in3[i * stride_1_0] == 0.0));
    }
  }
}

static void minus(coder::array<float, 2U> &in1, const coder::array<float, 2U>
                  &in2)
{
  coder::array<float, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int loop_ub;
  int stride_0_1;
  int stride_1_1;
  if (in2.size(1) == 1) {
    loop_ub = in1.size(1);
  } else {
    loop_ub = in2.size(1);
  }

  b_in1.set_size(3, loop_ub);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < loop_ub; i++) {
    b_in1[3 * i] = in1[3 * aux_0_1] - in2[3 * aux_1_1];
    b_in1[3 * i + 1] = in1[3 * aux_0_1 + 1] - in2[3 * aux_1_1 + 1];
    b_in1[3 * i + 2] = in1[3 * aux_0_1 + 2] - in2[3 * aux_1_1 + 2];
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }

  in1.set_size(3, b_in1.size(1));
  loop_ub = b_in1.size(1);
  if (static_cast<int>(b_in1.size(1) * 3 < 3200)) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[3 * i1] = b_in1[3 * i1];
      in1[3 * i1 + 1] = b_in1[3 * i1 + 1];
      in1[3 * i1 + 2] = b_in1[3 * i1 + 2];
    }
  } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      in1[3 * i1] = b_in1[3 * i1];
      in1[3 * i1 + 1] = b_in1[3 * i1 + 1];
      in1[3 * i1 + 2] = b_in1[3 * i1 + 2];
    }
  }
}

namespace coder
{
  namespace vision
  {
    namespace internal
    {
      namespace calibration
      {
        namespace checkerboard
        {
          boolean_T Checkerboard::b_expandBoardOnce()
          {
            array<double, 3U> b_this;
            array<double, 3U> c_this;
            array<double, 3U> r;
            array<double, 2U> f_this;
            array<double, 2U> idx;
            array<double, 2U> newIndices;
            array<double, 2U> p1;
            array<double, 2U> p2;
            array<double, 2U> predictedPoints;
            array<double, 2U> removedIdx;
            array<double, 2U> validIdx;
            array<double, 1U> b_validIdx;
            array<double, 1U> d_this;
            array<double, 1U> e_this;
            array<int, 2U> r3;
            array<int, 1U> r10;
            array<int, 1U> r4;
            array<int, 1U> r6;
            array<int, 1U> r8;
            array<int, 1U> r9;
            array<boolean_T, 1U> r1;
            array<boolean_T, 1U> r2;
            array<boolean_T, 1U> r5;
            array<boolean_T, 1U> r7;
            double currCurve_data[5];
            double currCoord;
            double moveDistMultiplier;
            int i;
            boolean_T success;
            PreviousEnergy = Energy;
            i = 0;
            int exitg1;
            do {
              exitg1 = 0;
              if (i < 4) {
                if (!IsDirectionBad[i]) {
                  float oldEnergy;
                  LastExpandDirection = static_cast<double>(i) + 1.0;
                  oldEnergy = (Energy + static_cast<float>(BoardIdx.size(0) *
                    BoardIdx.size(1))) / static_cast<float>(BoardIdx.size(0) *
                    BoardIdx.size(1));
                  switch (i + 1) {
                   case 1:
                    {
                      int loop_ub;
                      if (IsDistortionHigh) {
                        c_fitPolynomialIndices(newIndices);
                      } else {
                        int b_loop_ub;
                        int numCols;
                        b_this.set_size(1, BoardCoords.size(1), BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(1);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            b_this[i1 + b_this.size(1) * b_i] = BoardCoords
                              [(BoardCoords.size(0) * i1 + BoardCoords.size(0) *
                                BoardCoords.size(1) * b_i) + 1];
                          }
                        }

                        squeeze(b_this, p1);
                        b_this.set_size(1, BoardCoords.size(1), BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(1);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            b_this[i1 + b_this.size(1) * b_i] =
                              BoardCoords[BoardCoords.size(0) * i1 +
                              BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                          }
                        }

                        squeeze(b_this, p2);
                        if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size
                             (1))) {
                          predictedPoints.set_size(p2.size(0), p2.size(1));
                          loop_ub = p2.size(0) * p2.size(1);
                          for (int b_i{0}; b_i < loop_ub; b_i++) {
                            predictedPoints[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                          }
                        } else {
                          binary_expand_op(predictedPoints, p2, p1);
                        }

                        if (p1.size(0) == p2.size(0)) {
                          r1.set_size(p1.size(0));
                          loop_ub = p1.size(0);
                          for (int b_i{0}; b_i < loop_ub; b_i++) {
                            r1[b_i] = ((p1[b_i] == 0.0) || (p2[b_i] == 0.0));
                          }
                        } else {
                          e_binary_expand_op(r1, p1, p2);
                        }

                        b_loop_ub = r1.size(0) - 1;
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r1[c_i]) {
                            numCols++;
                          }
                        }

                        r6.set_size(numCols);
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r1[c_i]) {
                            r6[numCols] = c_i;
                            numCols++;
                          }
                        }

                        loop_ub = predictedPoints.size(1);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = r6.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            predictedPoints[r6[i1] + predictedPoints.size(0) *
                              b_i] = rtNaN;
                          }
                        }

                        b_findClosestIndices(predictedPoints, newIndices);
                      }

                      expandBoardUp(newIndices, p1, r);
                      BoardIdx.set_size(p1.size(0), p1.size(1));
                      loop_ub = p1.size(0) * p1.size(1);
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        BoardIdx[b_i] = p1[b_i];
                      }

                      BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                      loop_ub = r.size(0) * r.size(1) * r.size(2);
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        BoardCoords[b_i] = r[b_i];
                      }

                      oldEnergy = computeNewEnergyVertical(oldEnergy);
                    }
                    break;

                   case 2:
                    {
                      int b_i;
                      int loop_ub;
                      int numCols;
                      numCols = BoardCoords.size(0);
                      if (numCols < numCols - 2) {
                        idx.set_size(1, 0);
                      } else {
                        idx.set_size(1, 3);
                        for (b_i = 0; b_i < 3; b_i++) {
                          idx[b_i] = numCols - b_i;
                        }
                      }

                      if (IsDistortionHigh) {
                        double coordsToUse[2];
                        int b_loop_ub;
                        int c_i;
                        findIndependentVar(idx, coordsToUse);
                        newIndices.set_size(1, BoardCoords.size(1));
                        loop_ub = BoardCoords.size(1);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          newIndices[b_i] = 0.0;
                        }

                        removedIdx.set_size(1, 0);
                        b_i = newIndices.size(1);
                        for (int j{0}; j < b_i; j++) {
                          int i1;
                          b_validIdx.set_size(BoardCoords.size(0));
                          loop_ub = BoardCoords.size(0);
                          for (i1 = 0; i1 < loop_ub; i1++) {
                            b_validIdx[i1] = BoardCoords[(i1 + BoardCoords.size
                              (0) * j) + BoardCoords.size(0) * BoardCoords.size
                              (1) * (static_cast<int>(coordsToUse[0]) - 1)];
                          }

                          eml_find(b_validIdx, r4);
                          b_validIdx.set_size(r4.size(0));
                          loop_ub = r4.size(0);
                          for (i1 = 0; i1 < loop_ub; i1++) {
                            b_validIdx[i1] = r4[i1];
                          }

                          if (b_validIdx.size(0) >= 2) {
                            double coordDist;
                            double currRad;
                            double refCoordValue;
                            int currCurve_size[2];
                            boolean_T exitg2;
                            coordDist = findSearchParams(idx, b_validIdx,
                              static_cast<double>(j) + 1.0, coordsToUse,
                              moveDistMultiplier, currCoord);
                            c_i = 0;
                            i1 = b_validIdx.size(0);
                            d_this.set_size(b_validIdx.size(0));
                            e_this.set_size(b_validIdx.size(0));
                            for (b_loop_ub = 0; b_loop_ub < i1; b_loop_ub++) {
                              if (b_validIdx[b_loop_ub] != 0.0) {
                                c_i++;
                              }

                              numCols = static_cast<int>(b_validIdx[b_loop_ub])
                                - 1;
                              d_this[b_loop_ub] = BoardCoords[(numCols +
                                BoardCoords.size(0) * j) + BoardCoords.size(0) *
                                BoardCoords.size(1) * (static_cast<int>
                                (coordsToUse[0]) - 1)];
                              e_this[b_loop_ub] = BoardCoords[(numCols +
                                BoardCoords.size(0) * j) + BoardCoords.size(0) *
                                BoardCoords.size(1) * (static_cast<int>
                                (coordsToUse[1]) - 1)];
                            }

                            if (c_i > 5) {
                              i1 = 4;
                            } else {
                              i1 = 2;
                            }

                            polyfit(d_this, e_this, static_cast<double>(i1),
                                    currCurve_data, currCurve_size);
                            currRad = coordDist / 4.0;
                            refCoordValue = BoardCoords[((static_cast<int>
                              (currCoord) + BoardCoords.size(0) * j) +
                              BoardCoords.size(0) * BoardCoords.size(1) * (
                              static_cast<int>(coordsToUse[0]) - 1)) - 1];
                            currCoord = currRad + refCoordValue;
                            exitg2 = false;
                            while ((!exitg2) && (std::abs(currCoord -
                                     refCoordValue) < moveDistMultiplier * 1.5 *
                                                 std::abs(coordDist))) {
                              double currPt[2];
                              boolean_T exitg3;
                              boolean_T p;
                              p = true;
                              b_loop_ub = 0;
                              exitg3 = false;
                              while ((!exitg3) && (b_loop_ub < 2)) {
                                if (!(coordsToUse[b_loop_ub] == static_cast<
                                      double>(b_loop_ub) + 1.0)) {
                                  p = false;
                                  exitg3 = true;
                                } else {
                                  b_loop_ub++;
                                }
                              }

                              if (p) {
                                double y;
                                y = currCurve_data[0];
                                i1 = currCurve_size[1];
                                for (b_loop_ub = 0; b_loop_ub <= i1 - 2;
                                     b_loop_ub++) {
                                  y = currCoord * y + currCurve_data[b_loop_ub +
                                    1];
                                }

                                currPt[0] = currCoord;
                                currPt[1] = y;
                              } else {
                                double y;
                                y = currCurve_data[0];
                                i1 = currCurve_size[1];
                                for (b_loop_ub = 0; b_loop_ub <= i1 - 2;
                                     b_loop_ub++) {
                                  y = currCoord * y + currCurve_data[b_loop_ub +
                                    1];
                                }

                                currPt[0] = y;
                                currPt[1] = currCoord;
                              }

                              findClosestOnCurve(currPt, std::abs(currRad),
                                                 currCurve_data, currCurve_size,
                                                 coordsToUse, removedIdx,
                                                 validIdx);
                              if (validIdx.size(1) != 0) {
                                newIndices[j] = validIdx[0];
                                i1 = removedIdx.size(1);
                                loop_ub = validIdx.size(1);
                                removedIdx.set_size(removedIdx.size(0),
                                                    removedIdx.size(1) +
                                                    validIdx.size(1));
                                for (numCols = 0; numCols < loop_ub; numCols++)
                                {
                                  removedIdx[i1 + numCols] = validIdx[numCols];
                                }

                                exitg2 = true;
                              } else {
                                currCoord += currRad;
                              }
                            }
                          }
                        }

                        c_i = 0;
                        b_i = newIndices.size(1);
                        for (b_loop_ub = 0; b_loop_ub < b_i; b_loop_ub++) {
                          if (newIndices[b_loop_ub] != 0.0) {
                            c_i++;
                          }
                        }

                        if (c_i < 4) {
                          b_loop_ub = newIndices.size(1) - 1;
                          for (c_i = 0; c_i <= b_loop_ub; c_i++) {
                            if (newIndices[c_i] > 0.0) {
                              newIndices[c_i] = 0.0;
                            }
                          }
                        }
                      } else {
                        int b_loop_ub;
                        numCols = static_cast<int>(idx[1]);
                        b_this.set_size(1, BoardCoords.size(1), BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(1);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            b_this[i1 + b_this.size(1) * b_i] = BoardCoords
                              [((numCols + BoardCoords.size(0) * i1) +
                                BoardCoords.size(0) * BoardCoords.size(1) * b_i)
                              - 1];
                          }
                        }

                        squeeze(b_this, p1);
                        numCols = static_cast<int>(idx[0]);
                        b_this.set_size(1, BoardCoords.size(1), BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(1);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            b_this[i1 + b_this.size(1) * b_i] = BoardCoords
                              [((numCols + BoardCoords.size(0) * i1) +
                                BoardCoords.size(0) * BoardCoords.size(1) * b_i)
                              - 1];
                          }
                        }

                        squeeze(b_this, p2);
                        if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size
                             (1))) {
                          predictedPoints.set_size(p2.size(0), p2.size(1));
                          loop_ub = p2.size(0) * p2.size(1);
                          for (b_i = 0; b_i < loop_ub; b_i++) {
                            predictedPoints[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                          }
                        } else {
                          binary_expand_op(predictedPoints, p2, p1);
                        }

                        if (p1.size(0) == p2.size(0)) {
                          r7.set_size(p1.size(0));
                          loop_ub = p1.size(0);
                          for (b_i = 0; b_i < loop_ub; b_i++) {
                            r7[b_i] = ((p1[b_i] == 0.0) || (p2[b_i] == 0.0));
                          }
                        } else {
                          e_binary_expand_op(r7, p1, p2);
                        }

                        b_loop_ub = r7.size(0) - 1;
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r7[c_i]) {
                            numCols++;
                          }
                        }

                        r10.set_size(numCols);
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r7[c_i]) {
                            r10[numCols] = c_i;
                            numCols++;
                          }
                        }

                        loop_ub = predictedPoints.size(1);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = r10.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            predictedPoints[r10[i1] + predictedPoints.size(0) *
                              b_i] = rtNaN;
                          }
                        }

                        b_findClosestIndices(predictedPoints, newIndices);
                      }

                      expandBoardDown(newIndices, p1, r);
                      BoardIdx.set_size(p1.size(0), p1.size(1));
                      loop_ub = p1.size(0) * p1.size(1);
                      for (b_i = 0; b_i < loop_ub; b_i++) {
                        BoardIdx[b_i] = p1[b_i];
                      }

                      BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                      loop_ub = r.size(0) * r.size(1) * r.size(2);
                      for (b_i = 0; b_i < loop_ub; b_i++) {
                        BoardCoords[b_i] = r[b_i];
                      }

                      idx.set_size(1, idx.size(1));
                      loop_ub = idx.size(1) - 1;
                      for (b_i = 0; b_i <= loop_ub; b_i++) {
                        idx[b_i] = idx[b_i] + 1.0;
                      }

                      oldEnergy = computeNewEnergyVertical(idx, oldEnergy);
                    }
                    break;

                   case 3:
                    {
                      int loop_ub;
                      if (IsDistortionHigh) {
                        d_fitPolynomialIndices(newIndices);
                      } else {
                        int b_loop_ub;
                        int numCols;
                        c_this.set_size(BoardCoords.size(0), 1, BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            c_this[i1 + c_this.size(0) * b_i] = BoardCoords[(i1
                              + BoardCoords.size(0)) + BoardCoords.size(0) *
                              BoardCoords.size(1) * b_i];
                          }
                        }

                        b_squeeze(c_this, p1);
                        c_this.set_size(BoardCoords.size(0), 1, BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            c_this[i1 + c_this.size(0) * b_i] = BoardCoords[i1 +
                              BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                          }
                        }

                        b_squeeze(c_this, p2);
                        if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size
                             (1))) {
                          predictedPoints.set_size(p2.size(0), p2.size(1));
                          loop_ub = p2.size(0) * p2.size(1);
                          for (int b_i{0}; b_i < loop_ub; b_i++) {
                            predictedPoints[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                          }
                        } else {
                          binary_expand_op(predictedPoints, p2, p1);
                        }

                        if (p1.size(0) == p2.size(0)) {
                          r2.set_size(p1.size(0));
                          loop_ub = p1.size(0);
                          for (int b_i{0}; b_i < loop_ub; b_i++) {
                            r2[b_i] = ((p1[b_i] == 0.0) || (p2[b_i] == 0.0));
                          }
                        } else {
                          e_binary_expand_op(r2, p1, p2);
                        }

                        b_loop_ub = r2.size(0) - 1;
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r2[c_i]) {
                            numCols++;
                          }
                        }

                        r8.set_size(numCols);
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r2[c_i]) {
                            r8[numCols] = c_i;
                            numCols++;
                          }
                        }

                        loop_ub = predictedPoints.size(1);
                        for (int b_i{0}; b_i < loop_ub; b_i++) {
                          b_loop_ub = r8.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            predictedPoints[r8[i1] + predictedPoints.size(0) *
                              b_i] = rtNaN;
                          }
                        }

                        b_findClosestIndices(predictedPoints, newIndices);
                      }

                      expandBoardLeft(newIndices, p1, r);
                      BoardIdx.set_size(p1.size(0), p1.size(1));
                      loop_ub = p1.size(0) * p1.size(1);
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        BoardIdx[b_i] = p1[b_i];
                      }

                      BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                      loop_ub = r.size(0) * r.size(1) * r.size(2);
                      for (int b_i{0}; b_i < loop_ub; b_i++) {
                        BoardCoords[b_i] = r[b_i];
                      }

                      oldEnergy = computeNewEnergyHorizontal(oldEnergy);
                    }
                    break;

                   default:
                    {
                      int b_i;
                      int loop_ub;
                      int numCols;
                      numCols = BoardCoords.size(1);
                      if (numCols < numCols - 2) {
                        idx.set_size(1, 0);
                      } else {
                        idx.set_size(1, 3);
                        for (b_i = 0; b_i < 3; b_i++) {
                          idx[b_i] = numCols - b_i;
                        }
                      }

                      if (IsDistortionHigh) {
                        double coordsToUse[2];
                        int b_loop_ub;
                        int c_i;
                        b_findIndependentVar(idx, coordsToUse);
                        newIndices.set_size(1, BoardCoords.size(0));
                        loop_ub = BoardCoords.size(0);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          newIndices[b_i] = 0.0;
                        }

                        removedIdx.set_size(1, 0);
                        b_i = newIndices.size(1);
                        for (int j{0}; j < b_i; j++) {
                          int i1;
                          validIdx.set_size(1, BoardCoords.size(1));
                          loop_ub = BoardCoords.size(1);
                          for (i1 = 0; i1 < loop_ub; i1++) {
                            validIdx[i1] = BoardCoords[(j + BoardCoords.size(0) *
                              i1) + BoardCoords.size(0) * BoardCoords.size(1) *
                              (static_cast<int>(coordsToUse[0]) - 1)];
                          }

                          eml_find(validIdx, r3);
                          validIdx.set_size(1, r3.size(1));
                          loop_ub = r3.size(1);
                          for (i1 = 0; i1 < loop_ub; i1++) {
                            validIdx[i1] = r3[i1];
                          }

                          if (validIdx.size(1) >= 2) {
                            double coordDist;
                            double currRad;
                            double refCoordValue;
                            int currCurve_size[2];
                            boolean_T exitg2;
                            coordDist = findSearchParams(idx, validIdx,
                              static_cast<double>(j) + 1.0, coordsToUse,
                              moveDistMultiplier, currCoord);
                            c_i = 0;
                            i1 = validIdx.size(1);
                            b_validIdx.set_size(validIdx.size(1));
                            for (b_loop_ub = 0; b_loop_ub < i1; b_loop_ub++) {
                              refCoordValue = validIdx[b_loop_ub];
                              if (static_cast<int>(refCoordValue) != 0) {
                                c_i++;
                              }

                              b_validIdx[b_loop_ub] = refCoordValue;
                            }

                            validIdx.set_size(1, b_validIdx.size(0));
                            loop_ub = b_validIdx.size(0);
                            f_this.set_size(1, b_validIdx.size(0));
                            for (i1 = 0; i1 < loop_ub; i1++) {
                              numCols = static_cast<int>(b_validIdx[i1]) - 1;
                              validIdx[i1] = BoardCoords[(j + BoardCoords.size(0)
                                * numCols) + BoardCoords.size(0) *
                                BoardCoords.size(1) * (static_cast<int>
                                (coordsToUse[0]) - 1)];
                              f_this[i1] = BoardCoords[(j + BoardCoords.size(0) *
                                numCols) + BoardCoords.size(0) *
                                BoardCoords.size(1) * (static_cast<int>
                                (coordsToUse[1]) - 1)];
                            }

                            if (c_i > 5) {
                              i1 = 4;
                            } else {
                              i1 = 2;
                            }

                            polyfit(validIdx, f_this, static_cast<double>(i1),
                                    currCurve_data, currCurve_size);
                            currRad = coordDist / 4.0;
                            refCoordValue = BoardCoords[(j + BoardCoords.size(0)
                              * (static_cast<int>(currCoord) - 1)) +
                              BoardCoords.size(0) * BoardCoords.size(1) * (
                              static_cast<int>(coordsToUse[0]) - 1)];
                            currCoord = currRad + refCoordValue;
                            exitg2 = false;
                            while ((!exitg2) && (std::abs(currCoord -
                                     refCoordValue) < moveDistMultiplier * 1.5 *
                                                 std::abs(coordDist))) {
                              double currPt[2];
                              boolean_T exitg3;
                              boolean_T p;
                              p = true;
                              b_loop_ub = 0;
                              exitg3 = false;
                              while ((!exitg3) && (b_loop_ub < 2)) {
                                if (!(coordsToUse[b_loop_ub] == static_cast<
                                      double>(b_loop_ub) + 1.0)) {
                                  p = false;
                                  exitg3 = true;
                                } else {
                                  b_loop_ub++;
                                }
                              }

                              if (p) {
                                double y;
                                y = currCurve_data[0];
                                i1 = currCurve_size[1];
                                for (b_loop_ub = 0; b_loop_ub <= i1 - 2;
                                     b_loop_ub++) {
                                  y = currCoord * y + currCurve_data[b_loop_ub +
                                    1];
                                }

                                currPt[0] = currCoord;
                                currPt[1] = y;
                              } else {
                                double y;
                                y = currCurve_data[0];
                                i1 = currCurve_size[1];
                                for (b_loop_ub = 0; b_loop_ub <= i1 - 2;
                                     b_loop_ub++) {
                                  y = currCoord * y + currCurve_data[b_loop_ub +
                                    1];
                                }

                                currPt[0] = y;
                                currPt[1] = currCoord;
                              }

                              findClosestOnCurve(currPt, std::abs(currRad),
                                                 currCurve_data, currCurve_size,
                                                 coordsToUse, removedIdx,
                                                 validIdx);
                              if (validIdx.size(1) != 0) {
                                newIndices[j] = validIdx[0];
                                i1 = removedIdx.size(1);
                                loop_ub = validIdx.size(1);
                                removedIdx.set_size(removedIdx.size(0),
                                                    removedIdx.size(1) +
                                                    validIdx.size(1));
                                for (numCols = 0; numCols < loop_ub; numCols++)
                                {
                                  removedIdx[i1 + numCols] = validIdx[numCols];
                                }

                                exitg2 = true;
                              } else {
                                currCoord += currRad;
                              }
                            }
                          }
                        }

                        c_i = 0;
                        b_i = newIndices.size(1);
                        for (b_loop_ub = 0; b_loop_ub < b_i; b_loop_ub++) {
                          if (newIndices[b_loop_ub] != 0.0) {
                            c_i++;
                          }
                        }

                        if (c_i < 4) {
                          b_loop_ub = newIndices.size(1) - 1;
                          for (c_i = 0; c_i <= b_loop_ub; c_i++) {
                            if (newIndices[c_i] > 0.0) {
                              newIndices[c_i] = 0.0;
                            }
                          }
                        }
                      } else {
                        int b_loop_ub;
                        numCols = static_cast<int>(idx[1]);
                        c_this.set_size(BoardCoords.size(0), 1, BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            c_this[i1 + c_this.size(0) * b_i] = BoardCoords[(i1
                              + BoardCoords.size(0) * (numCols - 1)) +
                              BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                          }
                        }

                        b_squeeze(c_this, p1);
                        numCols = static_cast<int>(idx[0]);
                        c_this.set_size(BoardCoords.size(0), 1, BoardCoords.size
                                        (2));
                        loop_ub = BoardCoords.size(2);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = BoardCoords.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            c_this[i1 + c_this.size(0) * b_i] = BoardCoords[(i1
                              + BoardCoords.size(0) * (numCols - 1)) +
                              BoardCoords.size(0) * BoardCoords.size(1) * b_i];
                          }
                        }

                        b_squeeze(c_this, p2);
                        if ((p2.size(0) == p1.size(0)) && (p2.size(1) == p1.size
                             (1))) {
                          predictedPoints.set_size(p2.size(0), p2.size(1));
                          loop_ub = p2.size(0) * p2.size(1);
                          for (b_i = 0; b_i < loop_ub; b_i++) {
                            predictedPoints[b_i] = (p2[b_i] + p2[b_i]) - p1[b_i];
                          }
                        } else {
                          binary_expand_op(predictedPoints, p2, p1);
                        }

                        if (p1.size(0) == p2.size(0)) {
                          r5.set_size(p1.size(0));
                          loop_ub = p1.size(0);
                          for (b_i = 0; b_i < loop_ub; b_i++) {
                            r5[b_i] = ((p1[b_i] == 0.0) || (p2[b_i] == 0.0));
                          }
                        } else {
                          e_binary_expand_op(r5, p1, p2);
                        }

                        b_loop_ub = r5.size(0) - 1;
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r5[c_i]) {
                            numCols++;
                          }
                        }

                        r9.set_size(numCols);
                        numCols = 0;
                        for (int c_i{0}; c_i <= b_loop_ub; c_i++) {
                          if (r5[c_i]) {
                            r9[numCols] = c_i;
                            numCols++;
                          }
                        }

                        loop_ub = predictedPoints.size(1);
                        for (b_i = 0; b_i < loop_ub; b_i++) {
                          b_loop_ub = r9.size(0);
                          for (int i1{0}; i1 < b_loop_ub; i1++) {
                            predictedPoints[r9[i1] + predictedPoints.size(0) *
                              b_i] = rtNaN;
                          }
                        }

                        b_findClosestIndices(predictedPoints, newIndices);
                      }

                      expandBoardRight(newIndices, p1, r);
                      BoardIdx.set_size(p1.size(0), p1.size(1));
                      loop_ub = p1.size(0) * p1.size(1);
                      for (b_i = 0; b_i < loop_ub; b_i++) {
                        BoardIdx[b_i] = p1[b_i];
                      }

                      BoardCoords.set_size(r.size(0), r.size(1), r.size(2));
                      loop_ub = r.size(0) * r.size(1) * r.size(2);
                      for (b_i = 0; b_i < loop_ub; b_i++) {
                        BoardCoords[b_i] = r[b_i];
                      }

                      idx.set_size(1, idx.size(1));
                      loop_ub = idx.size(1) - 1;
                      for (b_i = 0; b_i <= loop_ub; b_i++) {
                        idx[b_i] = idx[b_i] + 1.0;
                      }

                      oldEnergy = computeNewEnergyHorizontal(idx, oldEnergy);
                    }
                    break;
                  }

                  Energy = oldEnergy;
                  if (Energy < PreviousEnergy) {
                    success = true;
                    exitg1 = 1;
                  } else {
                    undoLastExpansion();
                    IsDirectionBad[i] = true;
                    i++;
                  }
                } else {
                  i++;
                }
              } else {
                success = false;
                exitg1 = 1;
              }
            } while (exitg1 == 0);

            return success;
          }

          boolean_T Checkerboard::expandBoardOnce()
          {
            int i;
            boolean_T success;
            PreviousEnergy = Energy;
            i = 0;
            int exitg1;
            do {
              exitg1 = 0;
              if (i < 4) {
                if (!IsDirectionBad[i]) {
                  LastExpandDirection = static_cast<double>(i) + 1.0;
                  expandBoardDirectionally(static_cast<double>(i) + 1.0);
                  if (Energy < PreviousEnergy) {
                    success = true;
                    exitg1 = 1;
                  } else {
                    undoLastExpansion();
                    IsDirectionBad[i] = true;
                    i++;
                  }
                } else {
                  i++;
                }
              } else {
                success = false;
                exitg1 = 1;
              }
            } while (exitg1 == 0);

            return success;
          }

          void Checkerboard::initialize(double seedIdx, const ::coder::array<
            float, 2U> &points, const float v1[2], const float v2[2])
          {
            array<double, 2U> b_r;
            array<float, 2U> b_u;
            array<float, 2U> d;
            array<float, 2U> l;
            array<float, 2U> pointVectors;
            array<float, 2U> r;
            array<float, 2U> u;
            array<float, 1U> euclideanDists;
            array<boolean_T, 1U> x;
            float b_v1[2];
            int csz_idx_1;
            int i;
            int loop_ub;
            boolean_T exitg1;
            boolean_T y;
            BoardIdx.set_size(3, 3);
            for (i = 0; i < 9; i++) {
              BoardIdx[i] = 0.0;
            }

            IsDirectionBad[0] = false;
            IsDirectionBad[1] = false;
            IsDirectionBad[2] = false;
            IsDirectionBad[3] = false;
            BoardCoords.set_size(3, 3, 2);
            for (i = 0; i < 18; i++) {
              BoardCoords[i] = 0.0;
            }

            Points.set_size(points.size(0), 2);
            loop_ub = points.size(0) << 1;
            if (static_cast<int>(loop_ub < 3200)) {
              for (int k{0}; k < loop_ub; k++) {
                Points[k] = points[k];
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int k = 0; k < loop_ub; k++) {
                Points[k] = points[k];
              }
            }

            BoardIdx[BoardIdx.size(0) + 1] = seedIdx;
            loop_ub = BoardCoords.size(2);
            for (i = 0; i < loop_ub; i++) {
              BoardCoords[(BoardCoords.size(0) + BoardCoords.size(0) *
                           BoardCoords.size(1) * i) + 1] = Points[(static_cast<
                int>(seedIdx) + Points.size(0) * i) - 1];
            }

            LastExpandDirection = 1.0;
            PreviousEnergy = rtInfF;
            isValid = false;
            csz_idx_1 = Points.size(1);
            pointVectors.set_size(Points.size(0), Points.size(1));
            if ((Points.size(0) != 0) && (csz_idx_1 != 0)) {
              int acoef;
              int bcoef;
              acoef = (Points.size(1) != 1);
              bcoef = (Points.size(1) != 1);
              i = csz_idx_1 - 1;
              csz_idx_1 = (Points.size(0) != 1);
              for (int b_k{0}; b_k <= i; b_k++) {
                int i1;
                int varargin_3;
                loop_ub = acoef * b_k;
                varargin_3 = bcoef * b_k;
                i1 = pointVectors.size(0) - 1;
                for (int c_k{0}; c_k <= i1; c_k++) {
                  pointVectors[c_k + pointVectors.size(0) * b_k] =
                    Points[csz_idx_1 * c_k + Points.size(0) * loop_ub] - Points
                    [(static_cast<int>(seedIdx) + Points.size(0) * varargin_3) -
                    1];
                }
              }
            }

            euclideanDists.set_size(pointVectors.size(0));
            csz_idx_1 = pointVectors.size(0);
            if (static_cast<int>(pointVectors.size(0) < 3200)) {
              for (int k{0}; k < csz_idx_1; k++) {
                euclideanDists[k] = rt_hypotf_snf(pointVectors[k],
                  pointVectors[k + pointVectors.size(0)]);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int k = 0; k < csz_idx_1; k++) {
                euclideanDists[k] = rt_hypotf_snf(pointVectors[k],
                  pointVectors[k + pointVectors.size(0)]);
              }
            }

            BoardIdx[BoardIdx.size(0) * 2 + 1] = findNeighbor(pointVectors,
              euclideanDists, v1);
            b_v1[0] = -v1[0];
            b_v1[1] = -v1[1];
            BoardIdx[1] = findNeighbor(pointVectors, euclideanDists, b_v1);
            BoardIdx[BoardIdx.size(0) + 2] = findNeighbor(pointVectors,
              euclideanDists, v2);
            b_v1[0] = -v2[0];
            b_v1[1] = -v2[1];
            BoardIdx[BoardIdx.size(0)] = findNeighbor(pointVectors,
              euclideanDists, b_v1);
            x.set_size(BoardIdx.size(0) * BoardIdx.size(1));
            loop_ub = BoardIdx.size(0) * BoardIdx.size(1);
            if (static_cast<int>(loop_ub < 3200)) {
              for (int k{0}; k < loop_ub; k++) {
                x[k] = (BoardIdx[k] < 0.0);
              }
            } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

              for (int k = 0; k < loop_ub; k++) {
                x[k] = (BoardIdx[k] < 0.0);
              }
            }

            y = false;
            csz_idx_1 = 1;
            exitg1 = false;
            while ((!exitg1) && (csz_idx_1 <= x.size(0))) {
              if (x[csz_idx_1 - 1]) {
                y = true;
                exitg1 = true;
              } else {
                csz_idx_1++;
              }
            }

            if (y) {
              isValid = false;
            } else {
              csz_idx_1 = static_cast<int>(BoardIdx[BoardIdx.size(0) * 2 + 1]);
              r.set_size(1, Points.size(1));
              loop_ub = Points.size(1);
              if (static_cast<int>(loop_ub < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              }

              loop_ub = BoardCoords.size(2);
              if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  BoardCoords[(BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                               BoardCoords.size(1) * k) + 1] = r[k];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  BoardCoords[(BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                               BoardCoords.size(1) * k) + 1] = r[k];
                }
              }

              csz_idx_1 = static_cast<int>(BoardIdx[1]);
              l.set_size(1, Points.size(1));
              loop_ub = Points.size(1);
              if (static_cast<int>(loop_ub < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  l[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  l[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              }

              loop_ub = BoardCoords.size(2);
              if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k + 1]
                    = l[k];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k + 1]
                    = l[k];
                }
              }

              csz_idx_1 = static_cast<int>(BoardIdx[BoardIdx.size(0) + 2]);
              d.set_size(1, Points.size(1));
              loop_ub = Points.size(1);
              if (static_cast<int>(loop_ub < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  d[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  d[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              }

              loop_ub = BoardCoords.size(2);
              if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  BoardCoords[(BoardCoords.size(0) + BoardCoords.size(0) *
                               BoardCoords.size(1) * k) + 2] = d[k];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  BoardCoords[(BoardCoords.size(0) + BoardCoords.size(0) *
                               BoardCoords.size(1) * k) + 2] = d[k];
                }
              }

              csz_idx_1 = static_cast<int>(BoardIdx[BoardIdx.size(0)]);
              u.set_size(1, Points.size(1));
              loop_ub = Points.size(1);
              if (static_cast<int>(loop_ub < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  u[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  u[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                }
              }

              loop_ub = BoardCoords.size(2);
              if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  BoardCoords[BoardCoords.size(0) + BoardCoords.size(0) *
                    BoardCoords.size(1) * k] = u[k];
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  BoardCoords[BoardCoords.size(0) + BoardCoords.size(0) *
                    BoardCoords.size(1) * k] = u[k];
                }
              }

              if (u.size(1) == Points.size(1)) {
                csz_idx_1 = static_cast<int>(seedIdx);
                u.set_size(1, u.size(1));
                loop_ub = u.size(1);
                if (static_cast<int>(u.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    u[k] = u[k] - Points[(static_cast<int>(seedIdx) +
                                          Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    u[k] = u[k] - Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }
              } else {
                binary_expand_op(u, this, seedIdx);
              }

              if (d.size(1) == Points.size(1)) {
                csz_idx_1 = static_cast<int>(seedIdx);
                d.set_size(1, d.size(1));
                loop_ub = d.size(1);
                if (static_cast<int>(d.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    d[k] = d[k] - Points[(static_cast<int>(seedIdx) +
                                          Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    d[k] = d[k] - Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }
              } else {
                binary_expand_op(d, this, seedIdx);
              }

              if (r.size(1) == Points.size(1)) {
                csz_idx_1 = static_cast<int>(seedIdx);
                r.set_size(1, r.size(1));
                loop_ub = r.size(1);
                if (static_cast<int>(r.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    r[k] = r[k] - Points[(static_cast<int>(seedIdx) +
                                          Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    r[k] = r[k] - Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }
              } else {
                binary_expand_op(r, this, seedIdx);
              }

              if (l.size(1) == Points.size(1)) {
                csz_idx_1 = static_cast<int>(seedIdx);
                l.set_size(1, l.size(1));
                loop_ub = l.size(1);
                if (static_cast<int>(l.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    l[k] = l[k] - Points[(static_cast<int>(seedIdx) +
                                          Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    l[k] = l[k] - Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }
              } else {
                binary_expand_op(l, this, seedIdx);
              }

              if (u.size(1) == l.size(1)) {
                b_u.set_size(1, u.size(1));
                loop_ub = u.size(1);
                if (static_cast<int>(u.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_u[k] = u[k] + l[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_u[k] = u[k] + l[k];
                  }
                }

                BoardIdx[0] = findNeighbor(pointVectors, euclideanDists, b_u);
              } else {
                d_binary_expand_op(this, pointVectors, euclideanDists, u, l);
              }

              if (d.size(1) == l.size(1)) {
                b_u.set_size(1, d.size(1));
                loop_ub = d.size(1);
                if (static_cast<int>(d.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_u[k] = d[k] + l[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_u[k] = d[k] + l[k];
                  }
                }

                BoardIdx[2] = findNeighbor(pointVectors, euclideanDists, b_u);
              } else {
                c_binary_expand_op(this, pointVectors, euclideanDists, d, l);
              }

              if (d.size(1) == r.size(1)) {
                b_u.set_size(1, d.size(1));
                loop_ub = d.size(1);
                if (static_cast<int>(d.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_u[k] = d[k] + r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_u[k] = d[k] + r[k];
                  }
                }

                BoardIdx[BoardIdx.size(0) * 2 + 2] = findNeighbor(pointVectors,
                  euclideanDists, b_u);
              } else {
                b_binary_expand_op(this, pointVectors, euclideanDists, d, r);
              }

              if (u.size(1) == r.size(1)) {
                b_u.set_size(1, u.size(1));
                loop_ub = u.size(1);
                if (static_cast<int>(u.size(1) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_u[k] = u[k] + r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_u[k] = u[k] + r[k];
                  }
                }

                BoardIdx[BoardIdx.size(0) * 2] = findNeighbor(pointVectors,
                  euclideanDists, b_u);
              } else {
                binary_expand_op(this, pointVectors, euclideanDists, u, r);
              }

              x.set_size(BoardIdx.size(0) * BoardIdx.size(1));
              loop_ub = BoardIdx.size(0) * BoardIdx.size(1);
              if (static_cast<int>(loop_ub < 3200)) {
                for (int k{0}; k < loop_ub; k++) {
                  x[k] = (BoardIdx[k] > 0.0);
                }
              } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                for (int k = 0; k < loop_ub; k++) {
                  x[k] = (BoardIdx[k] > 0.0);
                }
              }

              isValid = true;
              csz_idx_1 = 1;
              exitg1 = false;
              while ((!exitg1) && (csz_idx_1 <= x.size(0))) {
                if (!x[csz_idx_1 - 1]) {
                  isValid = false;
                  exitg1 = true;
                } else {
                  csz_idx_1++;
                }
              }

              if (isValid) {
                csz_idx_1 = static_cast<int>(BoardIdx[0]);
                b_r.set_size(1, Points.size(1));
                loop_ub = Points.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }

                loop_ub = BoardCoords.size(2);
                if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k] =
                      b_r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k] =
                      b_r[k];
                  }
                }

                csz_idx_1 = static_cast<int>(BoardIdx[2]);
                b_r.set_size(1, Points.size(1));
                loop_ub = Points.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }

                loop_ub = BoardCoords.size(2);
                if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k +
                      2] = b_r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * BoardCoords.size(1) * k +
                      2] = b_r[k];
                  }
                }

                csz_idx_1 = static_cast<int>(BoardIdx[BoardIdx.size(0) * 2 + 2]);
                b_r.set_size(1, Points.size(1));
                loop_ub = Points.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }

                loop_ub = BoardCoords.size(2);
                if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    BoardCoords[(BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                                 BoardCoords.size(1) * k) + 2] = b_r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    BoardCoords[(BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                                 BoardCoords.size(1) * k) + 2] = b_r[k];
                  }
                }

                csz_idx_1 = static_cast<int>(BoardIdx[BoardIdx.size(0) * 2]);
                b_r.set_size(1, Points.size(1));
                loop_ub = Points.size(1);
                if (static_cast<int>(loop_ub < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    b_r[k] = Points[(csz_idx_1 + Points.size(0) * k) - 1];
                  }
                }

                loop_ub = BoardCoords.size(2);
                if (static_cast<int>(BoardCoords.size(2) < 3200)) {
                  for (int k{0}; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                      BoardCoords.size(1) * k] = b_r[k];
                  }
                } else {

#pragma omp parallel for \
 num_threads(32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

                  for (int k = 0; k < loop_ub; k++) {
                    BoardCoords[BoardCoords.size(0) * 2 + BoardCoords.size(0) *
                      BoardCoords.size(1) * k] = b_r[k];
                  }
                }

                Energy = computeInitialEnergy();
                if (IsDistortionHigh) {
                  i = -5;
                } else {
                  i = -7;
                }

                isValid = (static_cast<double>(Energy) < i);
              }
            }
          }
        }
      }
    }
  }
}

// End of code generation (Checkerboard.cpp)
