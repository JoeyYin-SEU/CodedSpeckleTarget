//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// unsafeSxfun.h
//
// Code generation for function 'unsafeSxfun'
//

#ifndef UNSAFESXFUN_H
#define UNSAFESXFUN_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op(coder::array<float, 2U> &in1,
                      const coder::array<double, 2U> &in3,
                      const coder::array<float, 2U> &in4);

#endif
// End of code generation (unsafeSxfun.h)
