//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// any1.cpp
//
// Code generation for function 'any1'
//

// Include files
#include "any1.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>

// Function Definitions
namespace coder {
void any(const ::coder::array<double, 2U> &x, ::coder::array<boolean_T, 2U> &y)
{
  int i2;
  int npages;
  y.set_size(1, x.size(1));
  npages = x.size(1);
  if (static_cast<int>(x.size(1) < 3200)) {
    for (int i{0}; i < npages; i++) {
      y[i] = false;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < npages; i++) {
      y[i] = false;
    }
  }
  npages = x.size(1);
  i2 = 0;
  for (int b_i{0}; b_i < npages; b_i++) {
    int a;
    int ix;
    boolean_T exitg1;
    a = i2 + x.size(0);
    ix = i2;
    i2 += x.size(0);
    exitg1 = false;
    while ((!exitg1) && (ix + 1 <= a)) {
      if ((x[ix] == 0.0) || std::isnan(x[ix])) {
        ix++;
      } else {
        y[b_i] = true;
        exitg1 = true;
      }
    }
  }
}

void b_any(const ::coder::array<double, 2U> &x, boolean_T y[6])
{
  int i2;
  for (i2 = 0; i2 < 6; i2++) {
    y[i2] = false;
  }
  i2 = 0;
  for (int i{0}; i < 6; i++) {
    int a;
    int ix;
    boolean_T exitg1;
    a = i2 + x.size(0);
    ix = i2;
    i2 += x.size(0);
    exitg1 = false;
    while ((!exitg1) && (ix + 1 <= a)) {
      if ((x[ix] == 0.0) || std::isnan(x[ix])) {
        ix++;
      } else {
        y[i] = true;
        exitg1 = true;
      }
    }
  }
}

} // namespace coder

// End of code generation (any1.cpp)
