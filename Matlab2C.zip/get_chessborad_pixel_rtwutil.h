//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel_rtwutil.h
//
// Code generation for function 'get_chessborad_pixel_rtwutil'
//

#ifndef GET_CHESSBORAD_PIXEL_RTWUTIL_H
#define GET_CHESSBORAD_PIXEL_RTWUTIL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern int div_s32(int numerator, int denominator);

extern double rt_hypotd_snf(double u0, double u1);

extern float rt_hypotf_snf(float u0, float u1);

#endif
// End of code generation (get_chessborad_pixel_rtwutil.h)
