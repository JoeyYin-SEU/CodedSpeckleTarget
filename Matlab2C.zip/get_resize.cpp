//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_resize.cpp
//
// Code generation for function 'get_resize'
//

// Include files
#include "get_resize.h"
#include "get_chessborad_pixel_data.h"
#include "get_chessborad_pixel_initialize.h"
#include "imresize.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>

// Function Definitions
void get_resize(const coder::array<double, 2U> &b_I, double W, double H,
                unsigned long long method, boolean_T Antialiasing,
                coder::array<double, 2U> &img)
{
  coder::array<double, 2U> out;
  coder::array<double, 2U> weights;
  coder::array<int, 2U> indices;
  double outputSize[2];
  if (!isInitialized_get_chessborad_pixel) {
    get_chessborad_pixel_initialize();
  }
  if (Antialiasing) {
    switch (method) {
    case 0ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::imresize(b_I, outputSize, img);
      break;
    case 1ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::b_imresize(b_I, outputSize, img);
      break;
    case 2ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::c_imresize(b_I, outputSize, img);
      break;
    case 3ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::imresize(b_I, outputSize, img);
      break;
    case 4ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::b_imresize(b_I, outputSize, img);
      break;
    case 5ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::c_imresize(b_I, outputSize, img);
      break;
    case 6ULL: {
      double scale_idx_0;
      double scale_idx_1;
      if (std::isnan(W)) {
        outputSize[0] = std::ceil(H * static_cast<double>(b_I.size(0)) /
                                  static_cast<double>(b_I.size(1)));
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[1] / static_cast<double>(b_I.size(1));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      } else if (std::isnan(H)) {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(W * static_cast<double>(b_I.size(1)) /
                                  static_cast<double>(b_I.size(0)));
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = scale_idx_0;
      } else {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      }
      if (scale_idx_0 <= scale_idx_1) {
        //  Resize first dimension
        coder::d_contributions(b_I.size(0), outputSize[0], scale_idx_0, 4.0,
                               weights, indices);
        out.set_size(weights.size(1), b_I.size(1));
        coder::resizeAlongDim2D(b_I, weights, indices,
                                static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::d_contributions(b_I.size(1), outputSize[1], scale_idx_1, 4.0,
                               weights, indices);
        img.set_size(out.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(out, weights, indices,
                                  static_cast<double>(weights.size(1)), img);
      } else {
        coder::d_contributions(b_I.size(1), outputSize[1], scale_idx_1, 4.0,
                               weights, indices);
        out.set_size(b_I.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(b_I, weights, indices,
                                  static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::d_contributions(b_I.size(0), outputSize[0], scale_idx_0, 4.0,
                               weights, indices);
        img.set_size(weights.size(1), out.size(1));
        coder::resizeAlongDim2D(out, weights, indices,
                                static_cast<double>(weights.size(1)), img);
      }
    } break;
    case 7ULL: {
      double scale_idx_0;
      double scale_idx_1;
      if (std::isnan(W)) {
        outputSize[0] = std::ceil(H * static_cast<double>(b_I.size(0)) /
                                  static_cast<double>(b_I.size(1)));
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[1] / static_cast<double>(b_I.size(1));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      } else if (std::isnan(H)) {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(W * static_cast<double>(b_I.size(1)) /
                                  static_cast<double>(b_I.size(0)));
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = scale_idx_0;
      } else {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      }
      if (scale_idx_0 <= scale_idx_1) {
        //  Resize first dimension
        coder::e_contributions(b_I.size(0), outputSize[0], scale_idx_0, 6.0,
                               weights, indices);
        out.set_size(weights.size(1), b_I.size(1));
        coder::resizeAlongDim2D(b_I, weights, indices,
                                static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::e_contributions(b_I.size(1), outputSize[1], scale_idx_1, 6.0,
                               weights, indices);
        img.set_size(out.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(out, weights, indices,
                                  static_cast<double>(weights.size(1)), img);
      } else {
        coder::e_contributions(b_I.size(1), outputSize[1], scale_idx_1, 6.0,
                               weights, indices);
        out.set_size(b_I.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(b_I, weights, indices,
                                  static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::e_contributions(b_I.size(0), outputSize[0], scale_idx_0, 6.0,
                               weights, indices);
        img.set_size(weights.size(1), out.size(1));
        coder::resizeAlongDim2D(out, weights, indices,
                                static_cast<double>(weights.size(1)), img);
      }
    } break;
    default:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::c_imresize(b_I, outputSize, img);
      break;
    }
  } else {
    switch (method) {
    case 0ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::d_imresize(b_I, outputSize, img);
      break;
    case 1ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::e_imresize(b_I, outputSize, img);
      break;
    case 2ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::f_imresize(b_I, outputSize, img);
      break;
    case 3ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::d_imresize(b_I, outputSize, img);
      break;
    case 4ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::e_imresize(b_I, outputSize, img);
      break;
    case 5ULL:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::f_imresize(b_I, outputSize, img);
      break;
    case 6ULL: {
      double scale_idx_0;
      double scale_idx_1;
      if (std::isnan(W)) {
        outputSize[0] = std::ceil(H * static_cast<double>(b_I.size(0)) /
                                  static_cast<double>(b_I.size(1)));
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[1] / static_cast<double>(b_I.size(1));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      } else if (std::isnan(H)) {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(W * static_cast<double>(b_I.size(1)) /
                                  static_cast<double>(b_I.size(0)));
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = scale_idx_0;
      } else {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      }
      if (scale_idx_0 <= scale_idx_1) {
        //  Resize first dimension
        coder::d_contributions(b_I.size(0), outputSize[0], scale_idx_0, weights,
                               indices);
        out.set_size(weights.size(1), b_I.size(1));
        coder::resizeAlongDim2D(b_I, weights, indices,
                                static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::d_contributions(b_I.size(1), outputSize[1], scale_idx_1, weights,
                               indices);
        img.set_size(out.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(out, weights, indices,
                                  static_cast<double>(weights.size(1)), img);
      } else {
        coder::d_contributions(b_I.size(1), outputSize[1], scale_idx_1, weights,
                               indices);
        out.set_size(b_I.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(b_I, weights, indices,
                                  static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::d_contributions(b_I.size(0), outputSize[0], scale_idx_0, weights,
                               indices);
        img.set_size(weights.size(1), out.size(1));
        coder::resizeAlongDim2D(out, weights, indices,
                                static_cast<double>(weights.size(1)), img);
      }
    } break;
    case 7ULL: {
      double scale_idx_0;
      double scale_idx_1;
      if (std::isnan(W)) {
        outputSize[0] = std::ceil(H * static_cast<double>(b_I.size(0)) /
                                  static_cast<double>(b_I.size(1)));
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[1] / static_cast<double>(b_I.size(1));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      } else if (std::isnan(H)) {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(W * static_cast<double>(b_I.size(1)) /
                                  static_cast<double>(b_I.size(0)));
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = scale_idx_0;
      } else {
        outputSize[0] = std::ceil(W);
        outputSize[1] = std::ceil(H);
        scale_idx_0 = outputSize[0] / static_cast<double>(b_I.size(0));
        scale_idx_1 = outputSize[1] / static_cast<double>(b_I.size(1));
      }
      if (scale_idx_0 <= scale_idx_1) {
        //  Resize first dimension
        coder::e_contributions(b_I.size(0), outputSize[0], scale_idx_0, weights,
                               indices);
        out.set_size(weights.size(1), b_I.size(1));
        coder::resizeAlongDim2D(b_I, weights, indices,
                                static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::e_contributions(b_I.size(1), outputSize[1], scale_idx_1, weights,
                               indices);
        img.set_size(out.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(out, weights, indices,
                                  static_cast<double>(weights.size(1)), img);
      } else {
        coder::e_contributions(b_I.size(1), outputSize[1], scale_idx_1, weights,
                               indices);
        out.set_size(b_I.size(0), weights.size(1));
        coder::b_resizeAlongDim2D(b_I, weights, indices,
                                  static_cast<double>(weights.size(1)), out);
        //  Resize second dimension
        coder::e_contributions(b_I.size(0), outputSize[0], scale_idx_0, weights,
                               indices);
        img.set_size(weights.size(1), out.size(1));
        coder::resizeAlongDim2D(out, weights, indices,
                                static_cast<double>(weights.size(1)), img);
      }
    } break;
    default:
      outputSize[0] = W;
      outputSize[1] = H;
      coder::f_imresize(b_I, outputSize, img);
      break;
    }
  }
}

// End of code generation (get_resize.cpp)
