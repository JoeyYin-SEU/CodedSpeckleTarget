//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel.h
//
// Code generation for function 'get_chessborad_pixel'
//

#ifndef GET_CHESSBORAD_PIXEL_H
#define GET_CHESSBORAD_PIXEL_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void get_chessborad_pixel(const coder::array<unsigned char, 2U> &b_I,
                                 double minCornerMetric,
                                 boolean_T highDistortion, boolean_T usePartial,
                                 coder::array<double, 2U> &imagePoints,
                                 double boardSize[2], boolean_T *imagesUsed);

#endif
// End of code generation (get_chessborad_pixel.h)
