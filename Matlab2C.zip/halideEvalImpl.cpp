//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// halideEvalImpl.cpp
//
// Code generation for function 'halideEvalImpl'
//

// Include files
#include "halideEvalImpl.h"
#include "get_chessborad_pixel_data.h"
#include "rt_nonfinite.h"
#include "HalideRuntime.h"

// Function Definitions
namespace coder {
namespace internal {
namespace halide {
void halideCleanup()
{
  halide_shutdown_thread_pool();
}

} // namespace halide
} // namespace internal
} // namespace coder
void halideInit_not_empty_init()
{
  halideInit_not_empty = false;
}

// End of code generation (halideEvalImpl.cpp)
