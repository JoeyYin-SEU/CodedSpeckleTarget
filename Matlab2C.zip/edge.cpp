//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// edge.cpp
//
// Code generation for function 'edge'
//

// Include files
#include "edge.h"
#include "get_chessborad_pixel_data.h"
#include "get_chessborad_pixel_rtwutil.h"
#include "imfilter.h"
#include "rt_nonfinite.h"
#include "sum.h"
#include "coder_array.h"
#include "libmwcannythresholding_tbb.h"
#include "libmwedgesobelprewitt_tbb.h"
#include "libmwedgethinning_tbb.h"
#include "libmwgetnumcores.h"
#include "libmwimfilter.h"
#include "libmwippfilter.h"
#include "libmwippreconstruct.h"
#include "libmwtbbhist.h"
#include "omp.h"
#include <cmath>
#include <cstring>

// Function Definitions
namespace coder {
void b_edge(const ::coder::array<unsigned char, 2U> &varargin_1,
            ::coder::array<boolean_T, 2U> &varargout_1)
{
  static const double b_kernel[13]{0.0020299751839417137,
                                   0.0102182810143517,
                                   0.058116735860084034,
                                   0.19634433732941292,
                                   0.37823877042972087,
                                   0.35505190018248872,
                                   0.0,
                                   -0.35505190018248872,
                                   -0.37823877042972087,
                                   -0.19634433732941292,
                                   -0.058116735860084034,
                                   -0.0102182810143517,
                                   -0.0020299751839417137};
  static const double c_kernel[13]{
      3.4813359214923059E-5, 0.00054457256285105158, 0.0051667606200595222,
      0.029732654490475543,  0.10377716120747747,    0.21969625200024598,
      0.28209557151935094,   0.21969625200024598,    0.10377716120747747,
      0.029732654490475543,  0.0051667606200595222,  0.00054457256285105158,
      3.4813359214923059E-5};
  static const double d_kernel[13]{0.0020299751839417137,
                                   0.0102182810143517,
                                   0.058116735860084034,
                                   0.19634433732941292,
                                   0.37823877042972087,
                                   0.35505190018248872,
                                   0.0,
                                   -0.35505190018248872,
                                   -0.37823877042972087,
                                   -0.19634433732941292,
                                   -0.058116735860084034,
                                   -0.0102182810143517,
                                   -0.0020299751839417137};
  static const double kernel[13]{
      3.4813359214923059E-5, 0.00054457256285105158, 0.0051667606200595222,
      0.029732654490475543,  0.10377716120747747,    0.21969625200024598,
      0.28209557151935094,   0.21969625200024598,    0.10377716120747747,
      0.029732654490475543,  0.0051667606200595222,  0.00054457256285105158,
      3.4813359214923059E-5};
  static const double nonZeroKernel[12]{
      0.0020299751839417137, 0.0102182810143517,   0.058116735860084034,
      0.19634433732941292,   0.37823877042972087,  0.35505190018248872,
      -0.35505190018248872,  -0.37823877042972087, -0.19634433732941292,
      -0.058116735860084034, -0.0102182810143517,  -0.0020299751839417137};
  static const boolean_T b_conn[13]{true, true, true, true, true, true, false,
                                    true, true, true, true, true, true};
  static const boolean_T c_conn[13]{true, true, true, true, true, true, false,
                                    true, true, true, true, true, true};
  array<float, 2U> a;
  array<float, 2U> b_a;
  array<float, 2U> dx;
  array<boolean_T, 2U> marker;
  array<boolean_T, 2U> mask;
  double counts[64];
  double connDimsT[2];
  double outSizeT[2];
  double padSizeT[2];
  double startT[2];
  double lowThresh_data;
  double numCores;
  float magmax;
  float magmaxPrime;
  int b_i;
  int b_m;
  int b_n;
  int b_outSizeT_tmp;
  int exitg1;
  int i;
  int i1;
  int idx;
  int loop_ub_tmp;
  int m;
  int n;
  int outSizeT_tmp;
  signed char b_idx;
  boolean_T conn[13];
  boolean_T rngFlag;
  boolean_T tooBig;
  a.set_size(varargin_1.size(0), varargin_1.size(1));
  loop_ub_tmp = varargin_1.size(0) * varargin_1.size(1);
  i = (loop_ub_tmp < 3200);
  if (i) {
    for (idx = 0; idx < loop_ub_tmp; idx++) {
      a[idx] = static_cast<float>(varargin_1[idx]) / 255.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (idx = 0; idx < loop_ub_tmp; idx++) {
      a[idx] = static_cast<float>(varargin_1[idx]) / 255.0F;
    }
  }
  if ((a.size(0) == 0) || (a.size(1) == 0)) {
    varargout_1.set_size(a.size(0), a.size(1));
    b_i = a.size(0) * a.size(1);
    if (static_cast<int>(b_i < 3200)) {
      for (idx = 0; idx < b_i; idx++) {
        varargout_1[idx] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (idx = 0; idx < b_i; idx++) {
        varargout_1[idx] = false;
      }
    }
  } else {
    n = a.size(1);
    m = a.size(0);
    b_m = a.size(0);
    b_n = a.size(1);
    outSizeT_tmp = a.size(0);
    outSizeT[0] = a.size(0);
    startT[0] = 6.0;
    b_outSizeT_tmp = a.size(1);
    outSizeT[1] = a.size(1);
    startT[1] = 0.0;
    b_padImage(a, startT, b_a);
    tooBig = true;
    i1 = a.size(0);
    if ((i1 <= 65500) || (a.size(1) <= 65500)) {
      tooBig = false;
    }
    dx.set_size(a.size(0), a.size(1));
    if (!tooBig) {
      padSizeT[0] = b_a.size(0);
      startT[0] = 13.0;
      padSizeT[1] = b_a.size(1);
      startT[1] = 1.0;
      ippfilter_real32(&b_a[0], &dx[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &kernel[0], &startT[0], true);
    } else {
      padSizeT[0] = b_a.size(0);
      padSizeT[1] = b_a.size(1);
      for (b_i = 0; b_i < 13; b_i++) {
        conn[b_i] = true;
      }
      connDimsT[0] = 13.0;
      connDimsT[1] = 1.0;
      imfilter_real32(&b_a[0], &dx[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &kernel[0], 13.0, &conn[0], 2.0, &connDimsT[0],
                      &startT[0], 2.0, true, true);
    }
    outSizeT[0] = dx.size(0);
    startT[0] = 0.0;
    outSizeT[1] = dx.size(1);
    startT[1] = 6.0;
    b_padImage(dx, startT, b_a);
    tooBig = true;
    b_i = dx.size(0);
    if ((b_i <= 65500) || (dx.size(1) <= 65500)) {
      tooBig = false;
    }
    dx.set_size(b_i, static_cast<int>(outSizeT[1]));
    if (!tooBig) {
      padSizeT[0] = b_a.size(0);
      startT[0] = 1.0;
      padSizeT[1] = b_a.size(1);
      startT[1] = 13.0;
      ippfilter_real32(&b_a[0], &dx[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &b_kernel[0], &startT[0], true);
    } else {
      padSizeT[0] = b_a.size(0);
      connDimsT[0] = 1.0;
      padSizeT[1] = b_a.size(1);
      connDimsT[1] = 13.0;
      imfilter_real32(&b_a[0], &dx[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &nonZeroKernel[0], 12.0, &b_conn[0], 2.0, &connDimsT[0],
                      &startT[0], 2.0, true, true);
    }
    outSizeT[0] = a.size(0);
    startT[0] = 0.0;
    outSizeT[1] = a.size(1);
    startT[1] = 6.0;
    b_padImage(a, startT, b_a);
    tooBig = true;
    if ((i1 <= 65500) || (a.size(1) <= 65500)) {
      tooBig = false;
    }
    a.set_size(i1, b_outSizeT_tmp);
    if (!tooBig) {
      padSizeT[0] = b_a.size(0);
      startT[0] = 1.0;
      padSizeT[1] = b_a.size(1);
      startT[1] = 13.0;
      ippfilter_real32(&b_a[0], &a[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &c_kernel[0], &startT[0], true);
    } else {
      padSizeT[0] = b_a.size(0);
      padSizeT[1] = b_a.size(1);
      for (b_i = 0; b_i < 13; b_i++) {
        conn[b_i] = true;
      }
      connDimsT[0] = 1.0;
      connDimsT[1] = 13.0;
      imfilter_real32(&b_a[0], &a[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &kernel[0], 13.0, &conn[0], 2.0, &connDimsT[0],
                      &startT[0], 2.0, true, true);
    }
    outSizeT[0] = a.size(0);
    startT[0] = 6.0;
    outSizeT[1] = a.size(1);
    startT[1] = 0.0;
    b_padImage(a, startT, b_a);
    tooBig = true;
    i1 = a.size(0);
    if ((i1 <= 65500) || (a.size(1) <= 65500)) {
      tooBig = false;
    }
    a.set_size(i1, static_cast<int>(outSizeT[1]));
    if (!tooBig) {
      padSizeT[0] = b_a.size(0);
      startT[0] = 13.0;
      padSizeT[1] = b_a.size(1);
      startT[1] = 1.0;
      ippfilter_real32(&b_a[0], &a[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &d_kernel[0], &startT[0], true);
    } else {
      padSizeT[0] = b_a.size(0);
      connDimsT[0] = 13.0;
      padSizeT[1] = b_a.size(1);
      connDimsT[1] = 1.0;
      imfilter_real32(&b_a[0], &a[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &nonZeroKernel[0], 12.0, &c_conn[0], 2.0, &connDimsT[0],
                      &startT[0], 2.0, true, true);
    }
    b_a.set_size(m, n);
    b_a[0] = rt_hypotf_snf(dx[0], a[0]);
    magmax = b_a[0];
    b_i = loop_ub_tmp - 2;
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(magmaxPrime)
    {
      magmaxPrime = rtMinusInfF;
#pragma omp for nowait
      for (idx = 0; idx <= b_i; idx++) {
        b_a[idx + 1] = rt_hypotf_snf(dx[idx + 1], a[idx + 1]);
        magmaxPrime = std::fmax(b_a[idx + 1], magmaxPrime);
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        magmax = std::fmax(magmaxPrime, magmax);
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
    if (magmax > 0.0F) {
      if (i) {
        for (idx = 0; idx < loop_ub_tmp; idx++) {
          b_a[idx] = b_a[idx] / magmax;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (idx = 0; idx < loop_ub_tmp; idx++) {
          b_a[idx] = b_a[idx] / magmax;
        }
      }
    }
    numCores = 1.0;
    getnumcores(&numCores);
    if ((loop_ub_tmp > 500000) && (numCores > 1.0)) {
      tooBig = false;
      rngFlag = false;
      tbbhist_real32_scaled(&b_a[0], static_cast<double>(loop_ub_tmp),
                            static_cast<double>(b_a.size(0)),
                            static_cast<double>(loop_ub_tmp) /
                                static_cast<double>(b_a.size(0)),
                            &counts[0], 64.0, 1.0, 64.0, &rngFlag, &tooBig);
    } else {
      std::memset(&counts[0], 0, 64U * sizeof(double));
      for (b_i = 0; b_i < loop_ub_tmp; b_i++) {
        if (std::isnan(b_a[b_i])) {
          magmax = 0.0F;
        } else {
          magmax = b_a[b_i] * 63.0F + 0.5F;
        }
        if (magmax > 63.0F) {
          counts[63]++;
        } else if (std::isinf(b_a[b_i])) {
          counts[63]++;
        } else {
          counts[static_cast<int>(magmax)]++;
        }
      }
    }
    numCores = 0.0;
    b_idx = 1;
    do {
      exitg1 = 0;
      tooBig = !(numCores > 0.7 * static_cast<double>(b_a.size(0)) *
                                static_cast<double>(b_a.size(1)));
      if (tooBig && (b_idx <= 64)) {
        numCores += counts[b_idx - 1];
        b_idx = static_cast<signed char>(b_idx + 1);
      } else {
        exitg1 = 1;
      }
    } while (exitg1 == 0);
    numCores = (static_cast<double>(b_idx) - 1.0) / 64.0;
    if ((b_idx > 64) && tooBig) {
    } else {
      lowThresh_data = 0.4 * numCores;
    }
    varargout_1.set_size(b_m, b_n);
    if (i) {
      for (idx = 0; idx < loop_ub_tmp; idx++) {
        varargout_1[idx] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (idx = 0; idx < loop_ub_tmp; idx++) {
        varargout_1[idx] = false;
      }
    }
    if ((b_m != 1) && (b_n != 1)) {
      startT[0] = outSizeT_tmp;
      startT[1] = b_outSizeT_tmp;
      cannythresholding_real32_tbb(&dx[0], &a[0], &b_a[0], &startT[0],
                                   lowThresh_data, &varargout_1[0]);
      marker.set_size(b_a.size(0), b_a.size(1));
      if (i) {
        for (idx = 0; idx < loop_ub_tmp; idx++) {
          marker[idx] = (b_a[idx] > numCores);
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (idx = 0; idx < loop_ub_tmp; idx++) {
          marker[idx] = (b_a[idx] > numCores);
        }
      }
      mask.set_size(varargout_1.size(0), varargout_1.size(1));
      b_i = varargout_1.size(0) * varargout_1.size(1);
      if (static_cast<int>(b_i < 3200)) {
        for (idx = 0; idx < b_i; idx++) {
          mask[idx] = varargout_1[idx];
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (idx = 0; idx < b_i; idx++) {
          mask[idx] = varargout_1[idx];
        }
      }
      startT[0] = outSizeT_tmp;
      startT[1] = b_outSizeT_tmp;
      varargout_1.set_size(marker.size(0), marker.size(1));
      if (i) {
        for (idx = 0; idx < loop_ub_tmp; idx++) {
          varargout_1[idx] = marker[idx];
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (idx = 0; idx < loop_ub_tmp; idx++) {
          varargout_1[idx] = marker[idx];
        }
      }
      ippreconstruct_uint8((unsigned char *)&varargout_1[0],
                           (unsigned char *)&mask[0], &startT[0], 2.0);
    }
  }
}

void c_edge(const ::coder::array<unsigned char, 2U> &varargin_1,
            ::coder::array<boolean_T, 2U> &varargout_1)
{
  static const double kernel[169]{
      5.5729956697509775E-5,  0.00010051139498851065, 0.00020089068977814211,
      0.000368574223248252,   0.00057333707934464928, 0.0007445097188372835,
      0.00081115777138118,    0.0007445097188372835,  0.00057333707934464928,
      0.000368574223248252,   0.00020089068977814211, 0.00010051139498851065,
      5.5729956697509775E-5,  0.00010051139498851065, 0.00023808910723660778,
      0.00052502135634706088, 0.00096021852685293692, 0.0014305914525947186,
      0.0017752325483537438,  0.0018973159045981333,  0.0017752325483537438,
      0.0014305914525947186,  0.00096021852685293692, 0.00052502135634706088,
      0.00023808910723660778, 0.00010051139498851065, 0.00020089068977814211,
      0.00052502135634706088, 0.0011314249555443366,  0.0018973159045981333,
      0.0024906169866851643,  0.0027145805665051842,  0.0027339813609643317,
      0.0027145805665051842,  0.0024906169866851643,  0.0018973159045981333,
      0.0011314249555443366,  0.00052502135634706088, 0.00020089068977814211,
      0.000368574223248252,   0.00096021852685293692, 0.0018973159045981333,
      0.0026624887779519136,  0.0024894667083042682,  0.0014639294238749598,
      0.00084504898031200479, 0.0014639294238749598,  0.0024894667083042682,
      0.0026624887779519136,  0.0018973159045981333,  0.00096021852685293692,
      0.000368574223248252,   0.00057333707934464928, 0.0014305914525947186,
      0.0024906169866851643,  0.0024894667083042682,  3.604838529923914E-5,
      -0.0039654010817205812, -0.0060095999794722091, -0.0039654010817205812,
      3.604838529923914E-5,   0.0024894667083042682,  0.0024906169866851643,
      0.0014305914525947186,  0.00057333707934464928, 0.0007445097188372835,
      0.0017752325483537438,  0.0027145805665051842,  0.0014639294238749598,
      -0.0039654010817205812, -0.011608100855785593,  -0.015357592931151054,
      -0.011608100855785593,  -0.0039654010817205812, 0.0014639294238749598,
      0.0027145805665051842,  0.0017752325483537438,  0.0007445097188372835,
      0.00081115777138118,    0.0018973159045981333,  0.0027339813609643317,
      0.00084504898031200479, -0.0060095999794722091, -0.015357592931151054,
      -0.019899129723045025,  -0.015357592931151054,  -0.0060095999794722091,
      0.00084504898031200479, 0.0027339813609643317,  0.0018973159045981333,
      0.00081115777138118,    0.0007445097188372835,  0.0017752325483537438,
      0.0027145805665051842,  0.0014639294238749598,  -0.0039654010817205812,
      -0.011608100855785593,  -0.015357592931151054,  -0.011608100855785593,
      -0.0039654010817205812, 0.0014639294238749598,  0.0027145805665051842,
      0.0017752325483537438,  0.0007445097188372835,  0.00057333707934464928,
      0.0014305914525947186,  0.0024906169866851643,  0.0024894667083042682,
      3.604838529923914E-5,   -0.0039654010817205812, -0.0060095999794722091,
      -0.0039654010817205812, 3.604838529923914E-5,   0.0024894667083042682,
      0.0024906169866851643,  0.0014305914525947186,  0.00057333707934464928,
      0.000368574223248252,   0.00096021852685293692, 0.0018973159045981333,
      0.0026624887779519136,  0.0024894667083042682,  0.0014639294238749598,
      0.00084504898031200479, 0.0014639294238749598,  0.0024894667083042682,
      0.0026624887779519136,  0.0018973159045981333,  0.00096021852685293692,
      0.000368574223248252,   0.00020089068977814211, 0.00052502135634706088,
      0.0011314249555443366,  0.0018973159045981333,  0.0024906169866851643,
      0.0027145805665051842,  0.0027339813609643317,  0.0027145805665051842,
      0.0024906169866851643,  0.0018973159045981333,  0.0011314249555443366,
      0.00052502135634706088, 0.00020089068977814211, 0.00010051139498851065,
      0.00023808910723660778, 0.00052502135634706088, 0.00096021852685293692,
      0.0014305914525947186,  0.0017752325483537438,  0.0018973159045981333,
      0.0017752325483537438,  0.0014305914525947186,  0.00096021852685293692,
      0.00052502135634706088, 0.00023808910723660778, 0.00010051139498851065,
      5.5729956697509775E-5,  0.00010051139498851065, 0.00020089068977814211,
      0.000368574223248252,   0.00057333707934464928, 0.0007445097188372835,
      0.00081115777138118,    0.0007445097188372835,  0.00057333707934464928,
      0.000368574223248252,   0.00020089068977814211, 0.00010051139498851065,
      5.5729956697509775E-5};
  static const double nonZeroKernel[169]{
      5.5729956697509775E-5,  0.00010051139498851065, 0.00020089068977814211,
      0.000368574223248252,   0.00057333707934464928, 0.0007445097188372835,
      0.00081115777138118,    0.0007445097188372835,  0.00057333707934464928,
      0.000368574223248252,   0.00020089068977814211, 0.00010051139498851065,
      5.5729956697509775E-5,  0.00010051139498851065, 0.00023808910723660778,
      0.00052502135634706088, 0.00096021852685293692, 0.0014305914525947186,
      0.0017752325483537438,  0.0018973159045981333,  0.0017752325483537438,
      0.0014305914525947186,  0.00096021852685293692, 0.00052502135634706088,
      0.00023808910723660778, 0.00010051139498851065, 0.00020089068977814211,
      0.00052502135634706088, 0.0011314249555443366,  0.0018973159045981333,
      0.0024906169866851643,  0.0027145805665051842,  0.0027339813609643317,
      0.0027145805665051842,  0.0024906169866851643,  0.0018973159045981333,
      0.0011314249555443366,  0.00052502135634706088, 0.00020089068977814211,
      0.000368574223248252,   0.00096021852685293692, 0.0018973159045981333,
      0.0026624887779519136,  0.0024894667083042682,  0.0014639294238749598,
      0.00084504898031200479, 0.0014639294238749598,  0.0024894667083042682,
      0.0026624887779519136,  0.0018973159045981333,  0.00096021852685293692,
      0.000368574223248252,   0.00057333707934464928, 0.0014305914525947186,
      0.0024906169866851643,  0.0024894667083042682,  3.604838529923914E-5,
      -0.0039654010817205812, -0.0060095999794722091, -0.0039654010817205812,
      3.604838529923914E-5,   0.0024894667083042682,  0.0024906169866851643,
      0.0014305914525947186,  0.00057333707934464928, 0.0007445097188372835,
      0.0017752325483537438,  0.0027145805665051842,  0.0014639294238749598,
      -0.0039654010817205812, -0.011608100855785593,  -0.015357592931151054,
      -0.011608100855785593,  -0.0039654010817205812, 0.0014639294238749598,
      0.0027145805665051842,  0.0017752325483537438,  0.0007445097188372835,
      0.00081115777138118,    0.0018973159045981333,  0.0027339813609643317,
      0.00084504898031200479, -0.0060095999794722091, -0.015357592931151054,
      -0.019899129723045025,  -0.015357592931151054,  -0.0060095999794722091,
      0.00084504898031200479, 0.0027339813609643317,  0.0018973159045981333,
      0.00081115777138118,    0.0007445097188372835,  0.0017752325483537438,
      0.0027145805665051842,  0.0014639294238749598,  -0.0039654010817205812,
      -0.011608100855785593,  -0.015357592931151054,  -0.011608100855785593,
      -0.0039654010817205812, 0.0014639294238749598,  0.0027145805665051842,
      0.0017752325483537438,  0.0007445097188372835,  0.00057333707934464928,
      0.0014305914525947186,  0.0024906169866851643,  0.0024894667083042682,
      3.604838529923914E-5,   -0.0039654010817205812, -0.0060095999794722091,
      -0.0039654010817205812, 3.604838529923914E-5,   0.0024894667083042682,
      0.0024906169866851643,  0.0014305914525947186,  0.00057333707934464928,
      0.000368574223248252,   0.00096021852685293692, 0.0018973159045981333,
      0.0026624887779519136,  0.0024894667083042682,  0.0014639294238749598,
      0.00084504898031200479, 0.0014639294238749598,  0.0024894667083042682,
      0.0026624887779519136,  0.0018973159045981333,  0.00096021852685293692,
      0.000368574223248252,   0.00020089068977814211, 0.00052502135634706088,
      0.0011314249555443366,  0.0018973159045981333,  0.0024906169866851643,
      0.0027145805665051842,  0.0027339813609643317,  0.0027145805665051842,
      0.0024906169866851643,  0.0018973159045981333,  0.0011314249555443366,
      0.00052502135634706088, 0.00020089068977814211, 0.00010051139498851065,
      0.00023808910723660778, 0.00052502135634706088, 0.00096021852685293692,
      0.0014305914525947186,  0.0017752325483537438,  0.0018973159045981333,
      0.0017752325483537438,  0.0014305914525947186,  0.00096021852685293692,
      0.00052502135634706088, 0.00023808910723660778, 0.00010051139498851065,
      5.5729956697509775E-5,  0.00010051139498851065, 0.00020089068977814211,
      0.000368574223248252,   0.00057333707934464928, 0.0007445097188372835,
      0.00081115777138118,    0.0007445097188372835,  0.00057333707934464928,
      0.000368574223248252,   0.00020089068977814211, 0.00010051139498851065,
      5.5729956697509775E-5};
  array<float, 2U> a;
  array<float, 2U> b_a;
  array<float, 1U> y;
  float b_center;
  float b_down;
  float b_left;
  float b_right;
  float b_up;
  int i;
  int loop_ub_tmp;
  int rr;
  boolean_T zc1;
  boolean_T zc2;
  boolean_T zc3;
  boolean_T zc4;
  a.set_size(varargin_1.size(0), varargin_1.size(1));
  loop_ub_tmp = varargin_1.size(0) * varargin_1.size(1);
  i = (loop_ub_tmp < 3200);
  if (i) {
    for (int k{0}; k < loop_ub_tmp; k++) {
      a[k] = static_cast<float>(varargin_1[k]) / 255.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < loop_ub_tmp; k++) {
      a[k] = static_cast<float>(varargin_1[k]) / 255.0F;
    }
  }
  if ((a.size(0) == 0) || (a.size(1) == 0)) {
    int nx;
    varargout_1.set_size(a.size(0), a.size(1));
    nx = a.size(0) * a.size(1);
    if (static_cast<int>(nx < 3200)) {
      for (int k{0}; k < nx; k++) {
        varargout_1[k] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < nx; k++) {
        varargout_1[k] = false;
      }
    }
  } else {
    double outSizeT[2];
    double startT[2];
    int m;
    int n;
    int nx;
    int rrmax;
    boolean_T tooBig;
    n = a.size(1);
    m = a.size(0);
    outSizeT[0] = a.size(0);
    startT[0] = 6.0;
    outSizeT[1] = a.size(1);
    startT[1] = 6.0;
    b_padImage(a, startT, b_a);
    tooBig = true;
    rrmax = a.size(0);
    if ((rrmax <= 65500) || (a.size(1) <= 65500)) {
      tooBig = false;
    }
    a.set_size(rrmax, static_cast<int>(outSizeT[1]));
    if (!tooBig) {
      double padSizeT[2];
      padSizeT[0] = b_a.size(0);
      startT[0] = 13.0;
      padSizeT[1] = b_a.size(1);
      startT[1] = 13.0;
      ippfilter_real32(&b_a[0], &a[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &kernel[0], &startT[0], false);
    } else {
      double padSizeT[2];
      boolean_T conn[169];
      padSizeT[0] = b_a.size(0);
      padSizeT[1] = b_a.size(1);
      for (rrmax = 0; rrmax < 169; rrmax++) {
        conn[rrmax] = true;
      }
      double connDimsT[2];
      connDimsT[0] = 13.0;
      connDimsT[1] = 13.0;
      imfilter_real32(&b_a[0], &a[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &nonZeroKernel[0], 169.0, &conn[0], 2.0, &connDimsT[0],
                      &startT[0], 2.0, true, false);
    }
    nx = a.size(0) * a.size(1);
    y.set_size(nx);
    if (static_cast<int>(nx < 3200)) {
      for (int k{0}; k < nx; k++) {
        y[k] = std::abs(a[k]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < nx; k++) {
        y[k] = std::abs(a[k]);
      }
    }
    startT[0] = 0.75 * sum(y) / static_cast<double>(nx);
    varargout_1.set_size(m, n);
    if (i) {
      for (int k{0}; k < loop_ub_tmp; k++) {
        varargout_1[k] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < loop_ub_tmp; k++) {
        varargout_1[k] = false;
      }
    }
    rrmax = m - 1;
    nx = n - 3;
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads()                         \
                               : 32) private(zc4, zc3, zc2, zc1, b_center,     \
                                             b_right, b_left, b_down, b_up,    \
                                             rr)

    for (int k = 0; k <= nx; k++) {
      for (rr = 0; rr <= rrmax - 2; rr++) {
        b_up = a[rr + a.size(0) * (k + 1)];
        b_down = a[(rr + a.size(0) * (k + 1)) + 2];
        b_left = a[(rr + a.size(0) * k) + 1];
        b_right = a[(rr + a.size(0) * (k + 2)) + 1];
        b_center = a[(rr + a.size(0) * (k + 1)) + 1];
        if (b_center != 0.0F) {
          if ((b_center < 0.0F) && (b_right > 0.0F) &&
              (std::abs(b_center - b_right) > startT[0])) {
            zc1 = true;
          } else {
            zc1 = false;
          }
          if ((b_left > 0.0F) && (b_center < 0.0F) &&
              (b_left - b_center > startT[0])) {
            zc2 = true;
          } else {
            zc2 = false;
          }
          if ((b_center < 0.0F) && (b_down > 0.0F) &&
              (std::abs(b_center - b_down) > startT[0])) {
            zc3 = true;
          } else {
            zc3 = false;
          }
          if ((b_up > 0.0F) && (b_center < 0.0F) &&
              (b_up - b_center > startT[0])) {
            zc4 = true;
          } else {
            zc4 = false;
          }
        } else {
          if ((b_up < 0.0F) && (b_down > 0.0F) &&
              (std::abs(b_up - b_down) > 2.0 * startT[0])) {
            zc1 = true;
          } else {
            zc1 = false;
          }
          if ((b_up > 0.0F) && (b_down < 0.0F) &&
              (b_up - b_down > 2.0 * startT[0])) {
            zc2 = true;
          } else {
            zc2 = false;
          }
          if ((b_left < 0.0F) && (b_right > 0.0F) &&
              (std::abs(b_left - b_right) > 2.0 * startT[0])) {
            zc3 = true;
          } else {
            zc3 = false;
          }
          if ((b_left > 0.0F) && (b_right < 0.0F) &&
              (b_left - b_right > 2.0 * startT[0])) {
            zc4 = true;
          } else {
            zc4 = false;
          }
        }
        if (zc1 || zc2 || zc3 || zc4) {
          zc4 = true;
        } else {
          zc4 = false;
        }
        varargout_1[(rr + varargout_1.size(0) * (k + 1)) + 1] = zc4;
      }
    }
  }
}

void edge(const ::coder::array<unsigned char, 2U> &varargin_1,
          ::coder::array<boolean_T, 2U> &varargout_1)
{
  array<float, 2U> b;
  array<float, 2U> pGradient1;
  array<float, 2U> pGradient2;
  array<float, 1U> b_b;
  if ((varargin_1.size(0) == 0) || (varargin_1.size(1) == 0)) {
    int b_tmp;
    varargout_1.set_size(varargin_1.size(0), varargin_1.size(1));
    b_tmp = varargin_1.size(0) * varargin_1.size(1);
    if (static_cast<int>(b_tmp < 3200)) {
      for (int i{0}; i < b_tmp; i++) {
        varargout_1[i] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i < b_tmp; i++) {
        varargout_1[i] = false;
      }
    }
  } else {
    double sz[2];
    int b_tmp;
    signed char offset[4];
    sz[0] = varargin_1.size(0);
    sz[1] = varargin_1.size(1);
    pGradient1.set_size(varargin_1.size(0), varargin_1.size(1));
    pGradient2.set_size(varargin_1.size(0), varargin_1.size(1));
    b.set_size(varargin_1.size(0), varargin_1.size(1));
    edgesobelprewitt_uint8_tbb(&varargin_1[0], &sz[0], true, 1.0, 1.0,
                               &pGradient1[0], &pGradient2[0], &b[0]);
    varargout_1.set_size(varargin_1.size(0), varargin_1.size(1));
    sz[0] = b.size(0);
    sz[1] = b.size(1);
    offset[0] = 0;
    offset[1] = 0;
    offset[2] = 0;
    offset[3] = 0;
    b_tmp = b.size(0) * b.size(1);
    b_b = b.reshape(b_tmp);
    edgethinning_real32_tbb(&b[0], &pGradient1[0], &pGradient2[0], 1.0, 1.0,
                            &offset[0], 2.2204460492503131E-14,
                            4.0 * sum(b_b) / static_cast<double>(b_tmp),
                            &varargout_1[0], &sz[0]);
  }
}

} // namespace coder
void f_binary_expand_op(coder::array<float, 2U> &in1,
                        const coder::array<float, 2U> &in2,
                        const coder::array<float, 2U> &in3)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      float f;
      float f1;
      f = in2[i1 * stride_0_0 + in2.size(0) * aux_0_1];
      f1 = in3[i1 * stride_1_0 + in3.size(0) * aux_1_1];
      in1[i1 + in1.size(0) * i] = f * f + f1 * f1;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

// End of code generation (edge.cpp)
