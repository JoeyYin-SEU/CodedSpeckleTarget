//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel_types.h
//
// Code generation for function 'get_chessborad_pixel'
//

#ifndef GET_CHESSBORAD_PIXEL_TYPES_H
#define GET_CHESSBORAD_PIXEL_TYPES_H

// Include files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

#endif
// End of code generation (get_chessborad_pixel_types.h)
