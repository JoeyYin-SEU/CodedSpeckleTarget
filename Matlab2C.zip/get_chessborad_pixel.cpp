//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel.cpp
//
// Code generation for function 'get_chessborad_pixel'
//

// Include files
#include "get_chessborad_pixel.h"
#include "detectCheckerboard.h"
#include "get_chessborad_pixel_data.h"
#include "get_chessborad_pixel_initialize.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"

// Function Definitions
void get_chessborad_pixel(const coder::array<unsigned char, 2U> &b_I,
                          double minCornerMetric, boolean_T highDistortion,
                          boolean_T usePartial,
                          coder::array<double, 2U> &imagePoints,
                          double boardSize[2], boolean_T *imagesUsed)
{
  coder::array<float, 2U> c_I;
  coder::array<int, 1U> r1;
  coder::array<boolean_T, 1U> r;
  double d;
  int b_i;
  int c_i;
  int i;
  int loop_ub;
  int trueCount;
  int trueCountPrime;
  if (!isInitialized_get_chessborad_pixel) {
    get_chessborad_pixel_initialize();
  }
  c_I.set_size(b_I.size(0), b_I.size(1));
  loop_ub = b_I.size(0) * b_I.size(1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (i = 0; i < loop_ub; i++) {
      c_I[i] = static_cast<float>(b_I[i]) / 255.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < loop_ub; i++) {
      c_I[i] = static_cast<float>(b_I[i]) / 255.0F;
    }
  }
  if (highDistortion) {
    d = 1.5;
  } else {
    d = 2.0;
  }
  coder::vision::internal::calibration::checkerboard::detectCheckerboard(
      c_I, d, minCornerMetric, highDistortion, usePartial, imagePoints,
      boardSize);
  if ((imagePoints.size(0) == 0) || (imagePoints.size(1) == 0)) {
    coder::vision::internal::calibration::checkerboard::b_detectCheckerboard(
        c_I, minCornerMetric, highDistortion, usePartial, imagePoints,
        boardSize);
  }
  *imagesUsed = ((imagePoints.size(0) != 0) && (imagePoints.size(1) != 0));
  if ((*imagesUsed) && usePartial) {
    r.set_size(imagePoints.size(0));
    loop_ub = imagePoints.size(0);
    b_i = (imagePoints.size(0) < 3200);
    if (b_i) {
      for (i = 0; i < loop_ub; i++) {
        r[i] = (imagePoints[i] == 0.0);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (i = 0; i < loop_ub; i++) {
        r[i] = (imagePoints[i] == 0.0);
      }
    }
    loop_ub = r.size(0) - 1;
    trueCount = 0;
    if (b_i) {
      for (i = 0; i <= loop_ub; i++) {
        if (r[i]) {
          trueCount++;
        }
      }
    } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
      {
        trueCountPrime = 0;
#pragma omp for nowait
        for (i = 0; i <= loop_ub; i++) {
          if (r[i]) {
            trueCountPrime++;
          }
        }
        omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
        {

          trueCount += trueCountPrime;
        }
        omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      }
    }
    r1.set_size(trueCount);
    trueCount = 0;
    for (c_i = 0; c_i <= loop_ub; c_i++) {
      if (r[c_i]) {
        r1[trueCount] = c_i;
        trueCount++;
      }
    }
    loop_ub = imagePoints.size(1);
    trueCount = r1.size(0);
    for (b_i = 0; b_i < loop_ub; b_i++) {
      for (c_i = 0; c_i < trueCount; c_i++) {
        imagePoints[r1[c_i] + imagePoints.size(0) * b_i] = rtNaN;
      }
    }
  }
}

// End of code generation (get_chessborad_pixel.cpp)
