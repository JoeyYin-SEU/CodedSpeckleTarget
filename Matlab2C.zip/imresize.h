//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// imresize.h
//
// Code generation for function 'imresize'
//

#ifndef IMRESIZE_H
#define IMRESIZE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void b_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout);

void b_resizeAlongDim2D(const ::coder::array<double, 2U> &in,
                        const ::coder::array<double, 2U> &weights,
                        const ::coder::array<int, 2U> &indices,
                        double out_length, ::coder::array<double, 2U> &out);

void c_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout);

void d_contributions(int in_length, double out_length, double scale,
                     ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices);

void d_contributions(int in_length, double out_length, double scale,
                     double kernel_width, ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices);

void d_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout);

void e_contributions(int in_length, double out_length, double scale,
                     ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices);

void e_contributions(int in_length, double out_length, double scale,
                     double kernel_width, ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices);

void e_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout);

void f_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout);

void imresize(const ::coder::array<double, 2U> &Ain, const double varargin_1[2],
              ::coder::array<double, 2U> &Bout);

void resizeAlongDim2D(const ::coder::array<double, 2U> &in,
                      const ::coder::array<double, 2U> &weights,
                      const ::coder::array<int, 2U> &indices, double out_length,
                      ::coder::array<double, 2U> &out);

} // namespace coder

#endif
// End of code generation (imresize.h)
