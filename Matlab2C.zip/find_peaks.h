//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// find_peaks.h
//
// Code generation for function 'find_peaks'
//

#ifndef FIND_PEAKS_H
#define FIND_PEAKS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
void find_peaks(const ::coder::array<float, 2U> &metric, double quality,
                ::coder::array<float, 2U> &loc);

}
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder

#endif
// End of code generation (find_peaks.h)
