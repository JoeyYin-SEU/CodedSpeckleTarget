//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// rot90.h
//
// Code generation for function 'rot90'
//

#ifndef ROT90_H
#define ROT90_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void b_rot90(const ::coder::array<double, 2U> &A,
             ::coder::array<double, 2U> &B);

void rot90(const ::coder::array<double, 2U> &A, ::coder::array<double, 2U> &B);

} // namespace coder

#endif
// End of code generation (rot90.h)
