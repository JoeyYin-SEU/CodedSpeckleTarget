//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// algbwmorph.cpp
//
// Code generation for function 'algbwmorph'
//

// Include files
#include "algbwmorph.h"
#include "get_chessborad_pixel_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "libmwbwlookup_tbb.h"
#include "omp.h"

// Function Declarations
static void g_binary_expand_op(coder::array<boolean_T, 2U> &in1,
                               const coder::array<boolean_T, 2U> &in2);

// Function Definitions
static void g_binary_expand_op(coder::array<boolean_T, 2U> &in1,
                               const coder::array<boolean_T, 2U> &in2)
{
  coder::array<boolean_T, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          (in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] &&
           (!in1[i1 * stride_1_0 + in1.size(0) * aux_1_1]));
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

namespace coder {
namespace images {
namespace internal {
void bwmorphApplyOnce(::coder::array<boolean_T, 2U> &bw)
{
  static const boolean_T lut[512]{
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, true,  true,  true,
      true,  false, true,  true,  true,  true,  true,  true,  false, false,
      true,  true,  false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, true,  false,
      true,  true,  true,  false, true,  true,  false, false, true,  true,
      false, false, true,  true,  false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      true,  false, false, false, false, false, false, false, true,  true,
      true,  true,  false, false, true,  true,  false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, true,  true,  false, false, true,  true,  false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, true,  false, false, false, false, false,
      false, false, true,  true,  true,  true,  false, false, true,  true,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, true,  false, true,  true,
      true,  false, true,  true,  true,  true,  false, false, true,  true,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, true,  false,
      false, false, false, false, false, false, true,  true,  true,  true,
      false, false, true,  true,  false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      true,  false, true,  true,  true,  false, true,  true,  true,  true,
      false, false, true,  true,  false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, true,  false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, true,  false, true,  true,  true,  false,
      true,  true,  false, false, true,  true,  false, false, true,  true,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, true,  true,
      false, false, true,  true,  false, false, false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      true,  false, false, false, false, false, false, false, true,  true,
      true,  true,  false, false, true,  true,  false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, true,  false, true,  true,  true,  false, true,  true,
      true,  true,  false, false, true,  true,  false, false, false, false,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, true,  false, false, false, false, false,
      false, false, true,  true,  true,  true,  false, false, true,  true,
      false, false, false, false, false, false, false, false, false, false,
      false, false, false, false, false, false, true,  false, true,  true,
      true,  false, true,  true,  true,  true,  false, false, true,  true,
      false, false};
  array<boolean_T, 2U> m;
  double sizeIn[2];
  int b_loop_ub;
  int b_sizeIn_tmp;
  int i1;
  int i2;
  int i3;
  int i4;
  int i5;
  int i6;
  int i7;
  int i8;
  int loop_ub;
  int sizeIn_tmp;
  sizeIn_tmp = bw.size(0);
  b_sizeIn_tmp = bw.size(1);
  m.set_size(sizeIn_tmp, b_sizeIn_tmp);
  if ((bw.size(0) != 0) && (bw.size(1) != 0)) {
    sizeIn[0] = sizeIn_tmp;
    sizeIn[1] = b_sizeIn_tmp;
    bwlookup_tbb_boolean(&bw[0], &sizeIn[0], 2.0, &lut[0], 512.0, &m[0]);
  }
  if ((bw.size(0) == m.size(0)) && (bw.size(1) == m.size(1))) {
    loop_ub = bw.size(0) * bw.size(1);
    m.set_size(bw.size(0), bw.size(1));
    if (static_cast<int>(loop_ub < 3200)) {
      for (int i{0}; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    }
  } else {
    g_binary_expand_op(m, bw);
  }
  if (m.size(0) < 1) {
    sizeIn_tmp = 1;
    b_sizeIn_tmp = 0;
  } else {
    sizeIn_tmp = 2;
    b_sizeIn_tmp = m.size(0);
  }
  if (m.size(1) < 1) {
    i1 = 1;
    i2 = 0;
  } else {
    i1 = 2;
    i2 = m.size(1);
  }
  if (bw.size(0) < 1) {
    i3 = 1;
  } else {
    i3 = 2;
  }
  if (bw.size(1) < 1) {
    i4 = 1;
  } else {
    i4 = 2;
  }
  loop_ub = div_s32(i2 - 1, i1);
  for (i2 = 0; i2 <= loop_ub; i2++) {
    b_loop_ub = div_s32(b_sizeIn_tmp - 1, sizeIn_tmp);
    for (i5 = 0; i5 <= b_loop_ub; i5++) {
      bw[i3 * i5 + bw.size(0) * (i4 * i2)] =
          m[sizeIn_tmp * i5 + m.size(0) * (i1 * i2)];
    }
  }
  sizeIn_tmp = bw.size(0);
  b_sizeIn_tmp = bw.size(1);
  m.set_size(sizeIn_tmp, b_sizeIn_tmp);
  if ((bw.size(0) != 0) && (bw.size(1) != 0)) {
    sizeIn[0] = sizeIn_tmp;
    sizeIn[1] = b_sizeIn_tmp;
    bwlookup_tbb_boolean(&bw[0], &sizeIn[0], 2.0, &lut[0], 512.0, &m[0]);
  }
  if ((bw.size(0) == m.size(0)) && (bw.size(1) == m.size(1))) {
    loop_ub = bw.size(0) * bw.size(1);
    m.set_size(bw.size(0), bw.size(1));
    if (static_cast<int>(loop_ub < 3200)) {
      for (int i{0}; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    }
  } else {
    g_binary_expand_op(m, bw);
  }
  if (m.size(0) < 2) {
    sizeIn_tmp = 0;
    b_sizeIn_tmp = 1;
    i1 = 0;
  } else {
    sizeIn_tmp = 1;
    b_sizeIn_tmp = 2;
    i1 = m.size(0);
  }
  if (m.size(1) < 2) {
    i2 = 0;
    i3 = 1;
    i4 = 0;
  } else {
    i2 = 1;
    i3 = 2;
    i4 = m.size(1);
  }
  if (bw.size(0) < 2) {
    i5 = 0;
    i6 = 1;
  } else {
    i5 = 1;
    i6 = 2;
  }
  if (bw.size(1) < 2) {
    i7 = 0;
    i8 = 1;
  } else {
    i7 = 1;
    i8 = 2;
  }
  loop_ub = div_s32((i4 - i2) - 1, i3);
  for (i4 = 0; i4 <= loop_ub; i4++) {
    b_loop_ub = div_s32((i1 - sizeIn_tmp) - 1, b_sizeIn_tmp);
    for (int i9{0}; i9 <= b_loop_ub; i9++) {
      bw[(i5 + i6 * i9) + bw.size(0) * (i7 + i8 * i4)] =
          m[(sizeIn_tmp + b_sizeIn_tmp * i9) + m.size(0) * (i2 + i3 * i4)];
    }
  }
  sizeIn_tmp = bw.size(0);
  b_sizeIn_tmp = bw.size(1);
  m.set_size(sizeIn_tmp, b_sizeIn_tmp);
  if ((bw.size(0) != 0) && (bw.size(1) != 0)) {
    sizeIn[0] = sizeIn_tmp;
    sizeIn[1] = b_sizeIn_tmp;
    bwlookup_tbb_boolean(&bw[0], &sizeIn[0], 2.0, &lut[0], 512.0, &m[0]);
  }
  if ((bw.size(0) == m.size(0)) && (bw.size(1) == m.size(1))) {
    loop_ub = bw.size(0) * bw.size(1);
    m.set_size(bw.size(0), bw.size(1));
    if (static_cast<int>(loop_ub < 3200)) {
      for (int i{0}; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    }
  } else {
    g_binary_expand_op(m, bw);
  }
  if (m.size(0) < 1) {
    sizeIn_tmp = 1;
    b_sizeIn_tmp = 0;
  } else {
    sizeIn_tmp = 2;
    b_sizeIn_tmp = m.size(0);
  }
  if (m.size(1) < 2) {
    i1 = 0;
    i2 = 1;
    i3 = 0;
  } else {
    i1 = 1;
    i2 = 2;
    i3 = m.size(1);
  }
  if (bw.size(0) < 1) {
    i4 = 1;
  } else {
    i4 = 2;
  }
  if (bw.size(1) < 2) {
    i5 = 0;
    i6 = 1;
  } else {
    i5 = 1;
    i6 = 2;
  }
  loop_ub = div_s32((i3 - i1) - 1, i2);
  for (i3 = 0; i3 <= loop_ub; i3++) {
    b_loop_ub = div_s32(b_sizeIn_tmp - 1, sizeIn_tmp);
    for (i7 = 0; i7 <= b_loop_ub; i7++) {
      bw[i4 * i7 + bw.size(0) * (i5 + i6 * i3)] =
          m[sizeIn_tmp * i7 + m.size(0) * (i1 + i2 * i3)];
    }
  }
  sizeIn_tmp = bw.size(0);
  b_sizeIn_tmp = bw.size(1);
  m.set_size(sizeIn_tmp, b_sizeIn_tmp);
  if ((bw.size(0) != 0) && (bw.size(1) != 0)) {
    sizeIn[0] = sizeIn_tmp;
    sizeIn[1] = b_sizeIn_tmp;
    bwlookup_tbb_boolean(&bw[0], &sizeIn[0], 2.0, &lut[0], 512.0, &m[0]);
  }
  if ((bw.size(0) == m.size(0)) && (bw.size(1) == m.size(1))) {
    loop_ub = bw.size(0) * bw.size(1);
    m.set_size(bw.size(0), bw.size(1));
    if (static_cast<int>(loop_ub < 3200)) {
      for (int i{0}; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i < loop_ub; i++) {
        m[i] = (bw[i] && (!m[i]));
      }
    }
  } else {
    g_binary_expand_op(m, bw);
  }
  if (m.size(0) < 2) {
    sizeIn_tmp = 0;
    b_sizeIn_tmp = 1;
    i1 = 0;
  } else {
    sizeIn_tmp = 1;
    b_sizeIn_tmp = 2;
    i1 = m.size(0);
  }
  if (m.size(1) < 1) {
    i2 = 1;
    i3 = 0;
  } else {
    i2 = 2;
    i3 = m.size(1);
  }
  if (bw.size(0) < 2) {
    i4 = 0;
    i5 = 1;
  } else {
    i4 = 1;
    i5 = 2;
  }
  if (bw.size(1) < 1) {
    i6 = 1;
  } else {
    i6 = 2;
  }
  loop_ub = div_s32(i3 - 1, i2);
  for (i3 = 0; i3 <= loop_ub; i3++) {
    b_loop_ub = div_s32((i1 - sizeIn_tmp) - 1, b_sizeIn_tmp);
    for (i7 = 0; i7 <= b_loop_ub; i7++) {
      bw[(i4 + i5 * i7) + bw.size(0) * (i6 * i3)] =
          m[(sizeIn_tmp + b_sizeIn_tmp * i7) + m.size(0) * (i2 * i3)];
    }
  }
}

} // namespace internal
} // namespace images
} // namespace coder

// End of code generation (algbwmorph.cpp)
