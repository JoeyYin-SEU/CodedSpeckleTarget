//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// bsxfun.h
//
// Code generation for function 'bsxfun'
//

#ifndef BSXFUN_H
#define BSXFUN_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void bsxfun(const ::coder::array<float, 3U> &a,
            const ::coder::array<float, 2U> &b, ::coder::array<float, 3U> &c);

void bsxfun(const ::coder::array<float, 2U> &a,
            const ::coder::array<double, 2U> &b, ::coder::array<float, 2U> &c);

void bsxfun(const ::coder::array<double, 1U> &a,
            const ::coder::array<double, 2U> &b, ::coder::array<double, 2U> &c);

void bsxfun(const ::coder::array<double, 2U> &a,
            const ::coder::array<double, 1U> &b, ::coder::array<double, 2U> &c);

} // namespace coder

#endif
// End of code generation (bsxfun.h)
