//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// halideEvalImpl.h
//
// Code generation for function 'halideEvalImpl'
//

#ifndef HALIDEEVALIMPL_H
#define HALIDEEVALIMPL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace halide {
void halideCleanup();

}
} // namespace internal
} // namespace coder
void halideInit_not_empty_init();

#endif
// End of code generation (halideEvalImpl.h)
