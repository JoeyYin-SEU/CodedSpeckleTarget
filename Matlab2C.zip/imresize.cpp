//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// imresize.cpp
//
// Code generation for function 'imresize'
//

// Include files
#include "imresize.h"
#include "any1.h"
#include "bsxfun.h"
#include "get_chessborad_pixel_data.h"
#include "mod.h"
#include "rt_nonfinite.h"
#include "sum.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>

// Function Declarations
namespace coder {
static void b_contributions(int in_length, double out_length, double scale,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices);

static void b_contributions(int in_length, double out_length, double scale,
                            double kernel_width,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices);

static void c_contributions(int in_length, double out_length, double scale,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices);

static void c_contributions(int in_length, double out_length, double scale,
                            double kernel_width,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices);

static void contributions(int in_length, double out_length, double scale,
                          ::coder::array<double, 2U> &weights,
                          ::coder::array<int, 2U> &indices);

static void contributions(int in_length, double out_length, double scale,
                          double kernel_width,
                          ::coder::array<double, 2U> &weights,
                          ::coder::array<int, 2U> &indices);

} // namespace coder
static double rt_powd_snf(double u0, double u1);

// Function Definitions
namespace coder {
static void b_contributions(int in_length, double out_length, double scale,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b;
  array<double, 2U> f;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b_indices;
  array<int, 1U> left;
  double d;
  double d1;
  int bcoef;
  int i;
  int loop_ub_tmp;
  int nx;
  int vstride;
  signed char tmp_data[4];
  boolean_T copyCols_idx_0;
  boolean_T copyCols_idx_1;
  boolean_T copyCols_idx_2;
  boolean_T copyCols_idx_3;
  boolean_T exitg1;
  //  Contributions, using pixel indices
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (int k{0}; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  d = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  }
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = u[k] - 1.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = u[k] - 1.0;
    }
  }
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  left.set_size(x.size(0));
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      left[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      left[k] = static_cast<int>(x[k]);
    }
  }
  b_indices.set_size(left.size(0), 4);
  if (left.size(0) != 0) {
    nx = (left.size(0) != 1);
    for (int b_k{0}; b_k < 4; b_k++) {
      i = b_indices.size(0) - 1;
      for (vstride = 0; vstride <= i; vstride++) {
        b_indices[vstride + b_indices.size(0) * b_k] = left[nx * vstride] + b_k;
      }
    }
  }
  b.set_size(b_indices.size(0), 4);
  loop_ub_tmp = b_indices.size(0) << 2;
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (int k{0}; k < loop_ub_tmp; k++) {
      b[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < loop_ub_tmp; k++) {
      b[k] = b_indices[k];
    }
  }
  nx = b.size(0);
  bcoef = u.size(0);
  if (nx <= bcoef) {
    bcoef = nx;
  }
  if (b.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = b.size(0);
  } else if (u.size(0) == b.size(0)) {
    i = u.size(0);
  } else {
    i = bcoef;
  }
  f.set_size(i, 4);
  if (i != 0) {
    nx = (u.size(0) != 1);
    for (int b_k{0}; b_k < 4; b_k++) {
      i = f.size(0) - 1;
      for (vstride = 0; vstride <= i; vstride++) {
        bcoef = nx * vstride;
        f[vstride + f.size(0) * b_k] = u[bcoef] - b[bcoef + b.size(0) * b_k];
      }
    }
  }
  bcoef = f.size(0) << 2;
  f.set_size(f.size(0), 4);
  i = (bcoef < 3200);
  if (i) {
    for (int k{0}; k < bcoef; k++) {
      f[k] =
          (f[k] + 1.0) * static_cast<double>((f[k] >= -1.0) && (f[k] < 0.0)) +
          (1.0 - f[k]) * static_cast<double>((f[k] >= 0.0) && (f[k] <= 1.0));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(d1)

    for (int k = 0; k < bcoef; k++) {
      d1 = (f[k] + 1.0) * static_cast<double>((f[k] >= -1.0) && (f[k] < 0.0)) +
           (1.0 - f[k]) * static_cast<double>((f[k] >= 0.0) && (f[k] <= 1.0));
      f[k] = d1;
    }
  }
  if (f.size(0) == 0) {
    u.set_size(0);
  } else {
    vstride = f.size(0);
    u.set_size(f.size(0));
    if (static_cast<int>(f.size(0) < 3200)) {
      for (int k{0}; k < vstride; k++) {
        u[k] = f[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < vstride; k++) {
        u[k] = f[k];
      }
    }
    for (int b_k{0}; b_k < 3; b_k++) {
      nx = (b_k + 1) * vstride;
      for (int xj{0}; xj < vstride; xj++) {
        u[xj] = u[xj] + f[nx + xj];
      }
    }
  }
  b.set_size(f.size(0), 4);
  if (i) {
    for (int k{0}; k < bcoef; k++) {
      b[k] = f[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < bcoef; k++) {
      b[k] = f[k];
    }
  }
  nx = u.size(0);
  bcoef = f.size(0);
  if (nx <= bcoef) {
    bcoef = nx;
  }
  if (u.size(0) == 1) {
    nx = f.size(0);
  } else if (f.size(0) == 1) {
    nx = u.size(0);
  } else if (f.size(0) == u.size(0)) {
    nx = f.size(0);
  } else {
    nx = bcoef;
  }
  f.set_size(nx, 4);
  if (nx != 0) {
    nx = (b.size(0) != 1);
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 4; b_k++) {
      i = f.size(0) - 1;
      for (vstride = 0; vstride <= i; vstride++) {
        f[vstride + f.size(0) * b_k] =
            b[nx * vstride + b.size(0) * b_k] / u[bcoef * vstride];
      }
    }
  }
  //  Create the auxiliary matrix:
  nx = in_length << 1;
  aux.set_size(1, nx);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (vstride = 2; vstride <= in_length; vstride++) {
    aux[vstride - 1] = aux[vstride - 2] + 1;
    bcoef = in_length + vstride;
    aux[bcoef - 1] = aux[bcoef - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (vstride = 0; vstride < loop_ub_tmp; vstride++) {
    b_indices[vstride] = aux[static_cast<int>(
        b_mod(static_cast<double>(b_indices[vstride]) - 1.0,
              static_cast<double>(nx)))];
  }
  copyCols_idx_0 = false;
  copyCols_idx_1 = false;
  copyCols_idx_2 = false;
  copyCols_idx_3 = false;
  nx = f.size(0);
  bcoef = 0;
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_0 = true;
      exitg1 = true;
    }
  }
  nx = f.size(0) + f.size(0);
  bcoef = f.size(0);
  vstride = f.size(0) + f.size(0);
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_1 = true;
      exitg1 = true;
    }
  }
  nx = vstride + f.size(0);
  bcoef = vstride;
  vstride += f.size(0);
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_2 = true;
      exitg1 = true;
    }
  }
  nx = vstride + f.size(0);
  bcoef = vstride;
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_3 = true;
      exitg1 = true;
    }
  }
  bcoef = 0;
  if (copyCols_idx_0) {
    bcoef = 1;
  }
  if (copyCols_idx_1) {
    bcoef++;
  }
  if (copyCols_idx_2) {
    bcoef++;
  }
  if (copyCols_idx_3) {
    bcoef++;
  }
  nx = 0;
  if (copyCols_idx_0) {
    tmp_data[0] = 0;
    nx = 1;
  }
  if (copyCols_idx_1) {
    tmp_data[nx] = 1;
    nx++;
  }
  if (copyCols_idx_2) {
    tmp_data[nx] = 2;
    nx++;
  }
  if (copyCols_idx_3) {
    tmp_data[nx] = 3;
  }
  weights.set_size(bcoef, f.size(0));
  nx = f.size(0);
  for (i = 0; i < nx; i++) {
    for (vstride = 0; vstride < bcoef; vstride++) {
      weights[vstride + weights.size(0) * i] =
          f[i + f.size(0) * tmp_data[vstride]];
    }
  }
  indices.set_size(bcoef, b_indices.size(0));
  nx = b_indices.size(0);
  for (i = 0; i < nx; i++) {
    for (vstride = 0; vstride < bcoef; vstride++) {
      indices[vstride + indices.size(0) * i] =
          b_indices[i + b_indices.size(0) * tmp_data[vstride]];
    }
  }
}

static void b_contributions(int in_length, double out_length, double scale,
                            double kernel_width,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b_indices;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> c_indices;
  array<int, 2U> r1;
  array<int, 1U> a;
  array<boolean_T, 2U> r;
  double b_kernel_width;
  double d;
  int b_k;
  int c_k;
  int i;
  int i1;
  int k;
  int nx;
  int trueCountPrime;
  int varargin_3;
  int yk;
  //  Contributions, using pixel indices
  if (scale < 1.0) {
    kernel_width = 2.0 / scale;
  }
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    yk = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (k = 0; k <= yk; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k <= yk; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  b_kernel_width = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  yk = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (k = 0; k < yk; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  }
  b_kernel_width = kernel_width / 2.0;
  x.set_size(u.size(0));
  yk = u.size(0);
  if (i) {
    for (k = 0; k < yk; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  }
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  nx = static_cast<int>(std::ceil(kernel_width) + 2.0);
  if (nx - 1 < 0) {
    nx = 0;
  }
  aux.set_size(1, nx);
  if (nx > 0) {
    aux[0] = 0;
    yk = 0;
    for (b_k = 2; b_k <= nx; b_k++) {
      yk++;
      aux[b_k - 1] = yk;
    }
  }
  a.set_size(x.size(0));
  yk = x.size(0);
  if (i) {
    for (k = 0; k < yk; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  indices.set_size(a.size(0), aux.size(1));
  if ((a.size(0) != 0) && (aux.size(1) != 0)) {
    nx = (aux.size(1) != 1);
    i = aux.size(1) - 1;
    yk = (a.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = nx * b_k;
      i1 = indices.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        indices[c_k + indices.size(0) * b_k] = a[yk * c_k] + aux[varargin_3];
      }
    }
  }
  b_indices.set_size(indices.size(0), indices.size(1));
  varargin_3 = indices.size(0) * indices.size(1);
  if (static_cast<int>(varargin_3 < 3200)) {
    for (k = 0; k < varargin_3; k++) {
      b_indices[k] = indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < varargin_3; k++) {
      b_indices[k] = indices[k];
    }
  }
  bsxfun(u, b_indices, weights);
  if (scale < 1.0) {
    yk = weights.size(0) * weights.size(1);
    if (static_cast<int>(yk < 3200)) {
      for (k = 0; k < yk; k++) {
        weights[k] = scale * weights[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < yk; k++) {
        weights[k] = scale * weights[k];
      }
    }
  }
  nx = weights.size(0) * weights.size(1);
  i = (nx < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] =
          (weights[k] + 1.0) *
              static_cast<double>((weights[k] >= -1.0) && (weights[k] < 0.0)) +
          (1.0 - weights[k]) *
              static_cast<double>((weights[k] >= 0.0) && (weights[k] <= 1.0));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(d)

    for (k = 0; k < nx; k++) {
      d = (weights[k] + 1.0) *
              static_cast<double>((weights[k] >= -1.0) && (weights[k] < 0.0)) +
          (1.0 - weights[k]) *
              static_cast<double>((weights[k] >= 0.0) && (weights[k] <= 1.0));
      weights[k] = d;
    }
  }
  if (scale < 1.0) {
    if (i) {
      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    }
  }
  sum(weights, u);
  b_indices.set_size(weights.size(0), weights.size(1));
  yk = weights.size(0) * weights.size(1) - 1;
  for (i = 0; i <= yk; i++) {
    b_indices[i] = weights[i];
  }
  bsxfun(b_indices, u, weights);
  //  Create the auxiliary matrix:
  nx = in_length << 1;
  aux.set_size(1, nx);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (c_k = 2; c_k <= in_length; c_k++) {
    aux[c_k - 1] = aux[c_k - 2] + 1;
    yk = in_length + c_k;
    aux[yk - 1] = aux[yk - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (c_k = 0; c_k < varargin_3; c_k++) {
    indices[c_k] = aux[static_cast<int>(b_mod(
        static_cast<double>(indices[c_k]) - 1.0, static_cast<double>(nx)))];
  }
  any(weights, r);
  yk = r.size(1) - 1;
  nx = 0;
  if (static_cast<int>(r.size(1) < 3200)) {
    for (k = 0; k <= yk; k++) {
      if (r[k]) {
        nx++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= yk; k++) {
        if (r[k]) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        nx += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, nx);
  nx = 0;
  for (c_k = 0; c_k <= yk; c_k++) {
    if (r[c_k]) {
      r1[nx] = c_k;
      nx++;
    }
  }
  nx = weights.size(0);
  b_indices.set_size(r1.size(1), weights.size(0));
  for (i = 0; i < nx; i++) {
    yk = r1.size(1);
    for (i1 = 0; i1 < yk; i1++) {
      b_indices[i1 + b_indices.size(0) * i] =
          weights[i + weights.size(0) * r1[i1]];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  yk = b_indices.size(0) * b_indices.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (k = 0; k < yk; k++) {
      weights[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      weights[k] = b_indices[k];
    }
  }
  nx = indices.size(0);
  c_indices.set_size(r1.size(1), indices.size(0));
  for (i = 0; i < nx; i++) {
    yk = r1.size(1);
    for (i1 = 0; i1 < yk; i1++) {
      c_indices[i1 + c_indices.size(0) * i] =
          indices[i + indices.size(0) * r1[i1]];
    }
  }
  indices.set_size(c_indices.size(0), c_indices.size(1));
  yk = c_indices.size(0) * c_indices.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (k = 0; k < yk; k++) {
      indices[k] = c_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      indices[k] = c_indices[k];
    }
  }
}

static void c_contributions(int in_length, double out_length, double scale,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices)
{
  array<double, 2U> absx;
  array<double, 2U> absx2;
  array<double, 2U> absx3;
  array<double, 2U> xin;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b_indices;
  array<int, 1U> a;
  double d;
  double d1;
  int bcoef;
  int c_k;
  int i;
  int loop_ub_tmp;
  int nx;
  signed char tmp_data[6];
  boolean_T b_bv[6];
  //  Contributions, using pixel indices
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (int k{0}; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  d = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  }
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = u[k] - 2.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = u[k] - 2.0;
    }
  }
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  a.set_size(x.size(0));
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  b_indices.set_size(a.size(0), 6);
  if (a.size(0) != 0) {
    nx = (a.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = b_indices.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        b_indices[c_k + b_indices.size(0) * b_k] = a[nx * c_k] + b_k;
      }
    }
  }
  absx.set_size(b_indices.size(0), 6);
  loop_ub_tmp = b_indices.size(0) * 6;
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (int k{0}; k < loop_ub_tmp; k++) {
      absx[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < loop_ub_tmp; k++) {
      absx[k] = b_indices[k];
    }
  }
  bcoef = absx.size(0);
  nx = u.size(0);
  if (bcoef <= nx) {
    nx = bcoef;
  }
  if (absx.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = absx.size(0);
  } else if (u.size(0) == absx.size(0)) {
    i = u.size(0);
  } else {
    i = nx;
  }
  xin.set_size(i, 6);
  if (i != 0) {
    nx = (u.size(0) != 1);
    bcoef = (absx.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = xin.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        xin[c_k + xin.size(0) * b_k] =
            u[nx * c_k] - absx[bcoef * c_k + absx.size(0) * b_k];
      }
    }
  }
  nx = xin.size(0) * 6;
  absx.set_size(xin.size(0), 6);
  i = (nx < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      absx[k] = std::abs(xin[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      absx[k] = std::abs(xin[k]);
    }
  }
  absx2.set_size(absx.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      absx2[k] = absx[k] * absx[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      absx2[k] = absx[k] * absx[k];
    }
  }
  absx3.set_size(absx.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      absx3[k] = rt_powd_snf(absx[k], 3.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      absx3[k] = rt_powd_snf(absx[k], 3.0);
    }
  }
  absx2.set_size(absx2.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      absx2[k] = 2.5 * absx2[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      absx2[k] = 2.5 * absx2[k];
    }
  }
  absx3.set_size(absx3.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      absx3[k] = ((1.5 * absx3[k] - absx2[k]) + 1.0) *
                     static_cast<double>(absx[k] <= 1.0) +
                 (((-0.5 * absx3[k] + absx2[k]) - 4.0 * absx[k]) + 2.0) *
                     static_cast<double>((absx[k] > 1.0) && (absx[k] <= 2.0));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(d1)

    for (int k = 0; k < nx; k++) {
      d1 = ((1.5 * absx3[k] - absx2[k]) + 1.0) *
               static_cast<double>(absx[k] <= 1.0) +
           (((-0.5 * absx3[k] + absx2[k]) - 4.0 * absx[k]) + 2.0) *
               static_cast<double>((absx[k] > 1.0) && (absx[k] <= 2.0));
      absx3[k] = d1;
    }
  }
  if (absx3.size(0) == 0) {
    u.set_size(0);
  } else {
    nx = absx3.size(0);
    u.set_size(absx3.size(0));
    if (static_cast<int>(absx3.size(0) < 3200)) {
      for (int k{0}; k < nx; k++) {
        u[k] = absx3[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < nx; k++) {
        u[k] = absx3[k];
      }
    }
    for (int b_k{0}; b_k < 5; b_k++) {
      bcoef = (b_k + 1) * nx;
      for (c_k = 0; c_k < nx; c_k++) {
        u[c_k] = u[c_k] + absx3[bcoef + c_k];
      }
    }
  }
  absx.set_size(absx3.size(0), 6);
  nx = absx3.size(0) * absx3.size(1) - 1;
  for (i = 0; i <= nx; i++) {
    absx[i] = absx3[i];
  }
  bcoef = u.size(0);
  nx = absx.size(0);
  if (bcoef <= nx) {
    nx = bcoef;
  }
  if (u.size(0) == 1) {
    i = absx.size(0);
  } else if (absx.size(0) == 1) {
    i = u.size(0);
  } else if (absx.size(0) == u.size(0)) {
    i = absx.size(0);
  } else {
    i = nx;
  }
  absx3.set_size(i, 6);
  if (i != 0) {
    nx = (absx.size(0) != 1);
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = absx3.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        absx3[c_k + absx3.size(0) * b_k] =
            absx[nx * c_k + absx.size(0) * b_k] / u[bcoef * c_k];
      }
    }
  }
  //  Create the auxiliary matrix:
  bcoef = in_length << 1;
  aux.set_size(1, bcoef);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (int b_k{2}; b_k <= in_length; b_k++) {
    aux[b_k - 1] = aux[b_k - 2] + 1;
    nx = in_length + b_k;
    aux[nx - 1] = aux[nx - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (int b_k{0}; b_k < loop_ub_tmp; b_k++) {
    b_indices[b_k] =
        aux[static_cast<int>(b_mod(static_cast<double>(b_indices[b_k]) - 1.0,
                                   static_cast<double>(bcoef)))];
  }
  b_any(absx3, b_bv);
  c_k = 0;
  bcoef = 0;
  for (int b_k{0}; b_k < 6; b_k++) {
    if (b_bv[b_k]) {
      c_k++;
      tmp_data[bcoef] = static_cast<signed char>(b_k);
      bcoef++;
    }
  }
  weights.set_size(c_k, absx3.size(0));
  nx = absx3.size(0);
  for (i = 0; i < nx; i++) {
    for (bcoef = 0; bcoef < c_k; bcoef++) {
      weights[bcoef + weights.size(0) * i] =
          absx3[i + absx3.size(0) * tmp_data[bcoef]];
    }
  }
  indices.set_size(c_k, b_indices.size(0));
  nx = b_indices.size(0);
  for (i = 0; i < nx; i++) {
    for (bcoef = 0; bcoef < c_k; bcoef++) {
      indices[bcoef + indices.size(0) * i] =
          b_indices[i + b_indices.size(0) * tmp_data[bcoef]];
    }
  }
}

static void c_contributions(int in_length, double out_length, double scale,
                            double kernel_width,
                            ::coder::array<double, 2U> &weights,
                            ::coder::array<int, 2U> &indices)
{
  array<double, 2U> absx;
  array<double, 2U> b_x;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b_indices;
  array<int, 2U> r1;
  array<int, 1U> a;
  array<boolean_T, 2U> r;
  double b_kernel_width;
  double d;
  int b_k;
  int bcoef;
  int c_k;
  int i;
  int i1;
  int k;
  int loop_ub_tmp;
  int nx;
  int trueCountPrime;
  unsigned int unnamed_idx_0_tmp;
  unsigned int unnamed_idx_1_tmp;
  int varargin_3;
  int yk;
  //  Contributions, using pixel indices
  if (scale < 1.0) {
    kernel_width = 4.0 / scale;
  }
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    yk = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (k = 0; k <= yk; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k <= yk; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  b_kernel_width = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  yk = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (k = 0; k < yk; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  }
  b_kernel_width = kernel_width / 2.0;
  x.set_size(u.size(0));
  yk = u.size(0);
  if (i) {
    for (k = 0; k < yk; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  }
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  nx = static_cast<int>(std::ceil(kernel_width) + 2.0);
  if (nx - 1 < 0) {
    nx = 0;
  }
  aux.set_size(1, nx);
  if (nx > 0) {
    aux[0] = 0;
    yk = 0;
    for (b_k = 2; b_k <= nx; b_k++) {
      yk++;
      aux[b_k - 1] = yk;
    }
  }
  a.set_size(x.size(0));
  yk = x.size(0);
  if (i) {
    for (k = 0; k < yk; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  indices.set_size(a.size(0), aux.size(1));
  if ((a.size(0) != 0) && (aux.size(1) != 0)) {
    yk = (aux.size(1) != 1);
    i = aux.size(1) - 1;
    nx = (a.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = yk * b_k;
      i1 = indices.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        indices[c_k + indices.size(0) * b_k] = a[nx * c_k] + aux[varargin_3];
      }
    }
  }
  absx.set_size(indices.size(0), indices.size(1));
  loop_ub_tmp = indices.size(0) * indices.size(1);
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (k = 0; k < loop_ub_tmp; k++) {
      absx[k] = indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub_tmp; k++) {
      absx[k] = indices[k];
    }
  }
  nx = absx.size(0);
  yk = u.size(0);
  if (nx <= yk) {
    yk = nx;
  }
  if (absx.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = absx.size(0);
  } else if (u.size(0) == absx.size(0)) {
    i = u.size(0);
  } else {
    i = yk;
  }
  b_x.set_size(i, absx.size(1));
  if ((i != 0) && (absx.size(1) != 0)) {
    yk = (absx.size(1) != 1);
    i = absx.size(1) - 1;
    nx = (u.size(0) != 1);
    bcoef = (absx.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = yk * b_k;
      i1 = b_x.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        b_x[c_k + b_x.size(0) * b_k] =
            u[nx * c_k] - absx[bcoef * c_k + absx.size(0) * varargin_3];
      }
    }
  }
  if (scale < 1.0) {
    yk = b_x.size(0) * b_x.size(1);
    if (static_cast<int>(yk < 3200)) {
      for (k = 0; k < yk; k++) {
        b_x[k] = scale * b_x[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < yk; k++) {
        b_x[k] = scale * b_x[k];
      }
    }
  }
  nx = b_x.size(0) * b_x.size(1);
  absx.set_size(b_x.size(0), b_x.size(1));
  if (static_cast<int>(nx < 3200)) {
    for (k = 0; k < nx; k++) {
      absx[k] = std::abs(b_x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      absx[k] = std::abs(b_x[k]);
    }
  }
  unnamed_idx_0_tmp = static_cast<unsigned int>(absx.size(0));
  unnamed_idx_1_tmp = static_cast<unsigned int>(absx.size(1));
  weights.set_size(absx.size(0), absx.size(1));
  nx = absx.size(0) * absx.size(1);
  i = (nx < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] = rt_powd_snf(absx[k], 3.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = rt_powd_snf(absx[k], 3.0);
    }
  }
  b_x.set_size(static_cast<int>(unnamed_idx_0_tmp),
               static_cast<int>(unnamed_idx_1_tmp));
  if (i) {
    for (k = 0; k < nx; k++) {
      b_x[k] = absx[k] * absx[k];
    }
    for (k = 0; k < nx; k++) {
      b_x[k] = 2.5 * b_x[k];
    }
    for (k = 0; k < nx; k++) {
      weights[k] = ((1.5 * weights[k] - b_x[k]) + 1.0) *
                       static_cast<double>(absx[k] <= 1.0) +
                   (((-0.5 * weights[k] + b_x[k]) - 4.0 * absx[k]) + 2.0) *
                       static_cast<double>((absx[k] > 1.0) && (absx[k] <= 2.0));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_x[k] = absx[k] * absx[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_x[k] = 2.5 * b_x[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(d)

    for (k = 0; k < nx; k++) {
      d = ((1.5 * weights[k] - b_x[k]) + 1.0) *
              static_cast<double>(absx[k] <= 1.0) +
          (((-0.5 * weights[k] + b_x[k]) - 4.0 * absx[k]) + 2.0) *
              static_cast<double>((absx[k] > 1.0) && (absx[k] <= 2.0));
      weights[k] = d;
    }
  }
  if (scale < 1.0) {
    if (i) {
      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    }
  }
  sum(weights, u);
  absx.set_size(weights.size(0), weights.size(1));
  yk = weights.size(0) * weights.size(1) - 1;
  for (i = 0; i <= yk; i++) {
    absx[i] = weights[i];
  }
  bsxfun(absx, u, weights);
  //  Create the auxiliary matrix:
  nx = in_length << 1;
  aux.set_size(1, nx);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (varargin_3 = 2; varargin_3 <= in_length; varargin_3++) {
    aux[varargin_3 - 1] = aux[varargin_3 - 2] + 1;
    yk = in_length + varargin_3;
    aux[yk - 1] = aux[yk - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (varargin_3 = 0; varargin_3 < loop_ub_tmp; varargin_3++) {
    indices[varargin_3] = aux[static_cast<int>(
        b_mod(static_cast<double>(indices[varargin_3]) - 1.0,
              static_cast<double>(nx)))];
  }
  any(weights, r);
  yk = r.size(1) - 1;
  nx = 0;
  if (static_cast<int>(r.size(1) < 3200)) {
    for (k = 0; k <= yk; k++) {
      if (r[k]) {
        nx++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= yk; k++) {
        if (r[k]) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        nx += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, nx);
  nx = 0;
  for (varargin_3 = 0; varargin_3 <= yk; varargin_3++) {
    if (r[varargin_3]) {
      r1[nx] = varargin_3;
      nx++;
    }
  }
  nx = weights.size(0);
  absx.set_size(r1.size(1), weights.size(0));
  for (i = 0; i < nx; i++) {
    yk = r1.size(1);
    for (i1 = 0; i1 < yk; i1++) {
      absx[i1 + absx.size(0) * i] = weights[i + weights.size(0) * r1[i1]];
    }
  }
  weights.set_size(absx.size(0), absx.size(1));
  yk = absx.size(0) * absx.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (k = 0; k < yk; k++) {
      weights[k] = absx[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      weights[k] = absx[k];
    }
  }
  nx = indices.size(0);
  b_indices.set_size(r1.size(1), indices.size(0));
  for (i = 0; i < nx; i++) {
    yk = r1.size(1);
    for (i1 = 0; i1 < yk; i1++) {
      b_indices[i1 + b_indices.size(0) * i] =
          indices[i + indices.size(0) * r1[i1]];
    }
  }
  indices.set_size(b_indices.size(0), b_indices.size(1));
  yk = b_indices.size(0) * b_indices.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (k = 0; k < yk; k++) {
      indices[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < yk; k++) {
      indices[k] = b_indices[k];
    }
  }
}

static void contributions(int in_length, double out_length, double scale,
                          ::coder::array<double, 2U> &weights,
                          ::coder::array<int, 2U> &indices)
{
  array<double, 2U> f;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b;
  array<int, 2U> b_indices;
  array<int, 1U> left;
  double d;
  int b_loop_ub_tmp;
  int bcoef;
  int i1;
  int k;
  int loop_ub_tmp;
  int nx;
  int vstride;
  signed char tmp_data[3];
  boolean_T copyCols_idx_0;
  boolean_T copyCols_idx_1;
  boolean_T copyCols_idx_2;
  boolean_T exitg1;
  //  Contributions, using pixel indices
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (int i{0}; i <= nx; i++) {
        y[i] = static_cast<double>(i) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int i = 0; i <= nx; i++) {
        y[i] = static_cast<double>(i) + 1.0;
      }
    }
  }
  d = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i1 = (y.size(1) < 3200);
  if (i1) {
    for (int i{0}; i < nx; i++) {
      u[i] = y[i] / scale + d;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < nx; i++) {
      u[i] = y[i] / scale + d;
    }
  }
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i1) {
    for (int i{0}; i < nx; i++) {
      x[i] = u[i] - 0.5;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < nx; i++) {
      x[i] = u[i] - 0.5;
    }
  }
  nx = x.size(0);
  if (i1) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  left.set_size(x.size(0));
  nx = x.size(0);
  if (i1) {
    for (int i{0}; i < nx; i++) {
      left[i] = static_cast<int>(x[i]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < nx; i++) {
      left[i] = static_cast<int>(x[i]);
    }
  }
  b_indices.set_size(left.size(0), 3);
  if (left.size(0) != 0) {
    nx = (left.size(0) != 1);
    for (int b_k{0}; b_k < 3; b_k++) {
      i1 = b_indices.size(0) - 1;
      for (vstride = 0; vstride <= i1; vstride++) {
        b_indices[vstride + b_indices.size(0) * b_k] = left[nx * vstride] + b_k;
      }
    }
  }
  b.set_size(b_indices.size(0), 3);
  loop_ub_tmp = b_indices.size(0) * 3;
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (int i{0}; i < loop_ub_tmp; i++) {
      b[i] = b_indices[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < loop_ub_tmp; i++) {
      b[i] = b_indices[i];
    }
  }
  nx = b.size(0);
  bcoef = u.size(0);
  if (nx <= bcoef) {
    bcoef = nx;
  }
  if (b.size(0) == 1) {
    i1 = u.size(0);
  } else if (u.size(0) == 1) {
    i1 = b.size(0);
  } else if (u.size(0) == b.size(0)) {
    i1 = u.size(0);
  } else {
    i1 = bcoef;
  }
  f.set_size(i1, 3);
  if (i1 != 0) {
    nx = (u.size(0) != 1);
    for (int b_k{0}; b_k < 3; b_k++) {
      i1 = f.size(0) - 1;
      for (vstride = 0; vstride <= i1; vstride++) {
        bcoef = nx * vstride;
        f[vstride + f.size(0) * b_k] =
            u[bcoef] - static_cast<double>(b[bcoef + b.size(0) * b_k]);
      }
    }
  }
  b_loop_ub_tmp = f.size(0) * 3;
  f.set_size(f.size(0), 3);
  i1 = (b_loop_ub_tmp < 3200);
  if (i1) {
    for (int i{0}; i < b_loop_ub_tmp; i++) {
      f[i] = ((f[i] >= -0.5) && (f[i] < 0.5));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(k)

    for (int i = 0; i < b_loop_ub_tmp; i++) {
      k = ((f[i] >= -0.5) && (f[i] < 0.5));
      f[i] = k;
    }
  }
  if (f.size(0) == 0) {
    u.set_size(0);
  } else {
    vstride = f.size(0);
    u.set_size(f.size(0));
    if (static_cast<int>(f.size(0) < 3200)) {
      for (k = 0; k < vstride; k++) {
        u[k] = static_cast<signed char>(f[k]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < vstride; k++) {
        u[k] = static_cast<signed char>(f[k]);
      }
    }
    for (int b_k{0}; b_k < 2; b_k++) {
      nx = (b_k + 1) * vstride;
      for (bcoef = 0; bcoef < vstride; bcoef++) {
        u[bcoef] = u[bcoef] +
                   static_cast<double>(static_cast<signed char>(f[nx + bcoef]));
      }
    }
  }
  b.set_size(f.size(0), 3);
  if (i1) {
    for (int i{0}; i < b_loop_ub_tmp; i++) {
      b[i] = static_cast<int>(f[i]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < b_loop_ub_tmp; i++) {
      b[i] = static_cast<int>(f[i]);
    }
  }
  nx = u.size(0);
  bcoef = f.size(0);
  if (nx <= bcoef) {
    bcoef = nx;
  }
  if (u.size(0) == 1) {
    nx = f.size(0);
  } else if (f.size(0) == 1) {
    nx = u.size(0);
  } else if (f.size(0) == u.size(0)) {
    nx = f.size(0);
  } else {
    nx = bcoef;
  }
  f.set_size(nx, 3);
  if (nx != 0) {
    nx = (b.size(0) != 1);
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 3; b_k++) {
      i1 = f.size(0) - 1;
      for (vstride = 0; vstride <= i1; vstride++) {
        f[vstride + f.size(0) * b_k] =
            static_cast<double>(b[nx * vstride + b.size(0) * b_k]) /
            u[bcoef * vstride];
      }
    }
  }
  //  Create the auxiliary matrix:
  nx = in_length << 1;
  aux.set_size(1, nx);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (vstride = 2; vstride <= in_length; vstride++) {
    aux[vstride - 1] = aux[vstride - 2] + 1;
    bcoef = in_length + vstride;
    aux[bcoef - 1] = aux[bcoef - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (vstride = 0; vstride < loop_ub_tmp; vstride++) {
    b_indices[vstride] = aux[static_cast<int>(
        b_mod(static_cast<double>(b_indices[vstride]) - 1.0,
              static_cast<double>(nx)))];
  }
  copyCols_idx_0 = false;
  copyCols_idx_1 = false;
  copyCols_idx_2 = false;
  nx = f.size(0);
  bcoef = 0;
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_0 = true;
      exitg1 = true;
    }
  }
  nx = f.size(0) + f.size(0);
  bcoef = f.size(0);
  vstride = f.size(0) + f.size(0);
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_1 = true;
      exitg1 = true;
    }
  }
  nx = vstride + f.size(0);
  bcoef = vstride;
  exitg1 = false;
  while ((!exitg1) && (bcoef + 1 <= nx)) {
    if ((f[bcoef] == 0.0) || std::isnan(f[bcoef])) {
      bcoef++;
    } else {
      copyCols_idx_2 = true;
      exitg1 = true;
    }
  }
  bcoef = 0;
  if (copyCols_idx_0) {
    bcoef = 1;
  }
  if (copyCols_idx_1) {
    bcoef++;
  }
  if (copyCols_idx_2) {
    bcoef++;
  }
  nx = 0;
  if (copyCols_idx_0) {
    tmp_data[0] = 0;
    nx = 1;
  }
  if (copyCols_idx_1) {
    tmp_data[nx] = 1;
    nx++;
  }
  if (copyCols_idx_2) {
    tmp_data[nx] = 2;
  }
  weights.set_size(bcoef, f.size(0));
  nx = f.size(0);
  for (i1 = 0; i1 < nx; i1++) {
    for (vstride = 0; vstride < bcoef; vstride++) {
      weights[vstride + weights.size(0) * i1] =
          f[i1 + f.size(0) * tmp_data[vstride]];
    }
  }
  indices.set_size(bcoef, b_indices.size(0));
  nx = b_indices.size(0);
  for (i1 = 0; i1 < nx; i1++) {
    for (vstride = 0; vstride < bcoef; vstride++) {
      indices[vstride + indices.size(0) * i1] =
          b_indices[i1 + b_indices.size(0) * tmp_data[vstride]];
    }
  }
}

static void contributions(int in_length, double out_length, double scale,
                          double kernel_width,
                          ::coder::array<double, 2U> &weights,
                          ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b_indices;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> c_indices;
  array<int, 2U> r1;
  array<int, 1U> a;
  array<boolean_T, 2U> r;
  double b_kernel_width;
  int b_k;
  int c_k;
  int i;
  int i1;
  int i2;
  int k;
  int nx;
  int trueCountPrime;
  int varargin_3;
  int yk;
  //  Contributions, using pixel indices
  if (scale < 1.0) {
    kernel_width = 1.0 / scale;
  }
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    yk = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (i = 0; i <= yk; i++) {
        y[i] = static_cast<double>(i) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (i = 0; i <= yk; i++) {
        y[i] = static_cast<double>(i) + 1.0;
      }
    }
  }
  b_kernel_width = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  yk = y.size(1);
  i1 = (y.size(1) < 3200);
  if (i1) {
    for (i = 0; i < yk; i++) {
      u[i] = y[i] / scale + b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < yk; i++) {
      u[i] = y[i] / scale + b_kernel_width;
    }
  }
  b_kernel_width = kernel_width / 2.0;
  x.set_size(u.size(0));
  yk = u.size(0);
  if (i1) {
    for (i = 0; i < yk; i++) {
      x[i] = u[i] - b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < yk; i++) {
      x[i] = u[i] - b_kernel_width;
    }
  }
  nx = x.size(0);
  if (i1) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  nx = static_cast<int>(std::ceil(kernel_width) + 2.0);
  if (nx - 1 < 0) {
    nx = 0;
  }
  aux.set_size(1, nx);
  if (nx > 0) {
    aux[0] = 0;
    yk = 0;
    for (b_k = 2; b_k <= nx; b_k++) {
      yk++;
      aux[b_k - 1] = yk;
    }
  }
  a.set_size(x.size(0));
  yk = x.size(0);
  if (i1) {
    for (i = 0; i < yk; i++) {
      a[i] = static_cast<int>(x[i]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < yk; i++) {
      a[i] = static_cast<int>(x[i]);
    }
  }
  indices.set_size(a.size(0), aux.size(1));
  if ((a.size(0) != 0) && (aux.size(1) != 0)) {
    nx = (aux.size(1) != 1);
    i1 = aux.size(1) - 1;
    yk = (a.size(0) != 1);
    for (b_k = 0; b_k <= i1; b_k++) {
      varargin_3 = nx * b_k;
      i2 = indices.size(0) - 1;
      for (c_k = 0; c_k <= i2; c_k++) {
        indices[c_k + indices.size(0) * b_k] = a[yk * c_k] + aux[varargin_3];
      }
    }
  }
  b_indices.set_size(indices.size(0), indices.size(1));
  c_k = indices.size(0) * indices.size(1);
  if (static_cast<int>(c_k < 3200)) {
    for (i = 0; i < c_k; i++) {
      b_indices[i] = indices[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < c_k; i++) {
      b_indices[i] = indices[i];
    }
  }
  bsxfun(u, b_indices, weights);
  if (scale < 1.0) {
    yk = weights.size(0) * weights.size(1);
    if (static_cast<int>(yk < 3200)) {
      for (i = 0; i < yk; i++) {
        weights[i] = scale * weights[i];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (i = 0; i < yk; i++) {
        weights[i] = scale * weights[i];
      }
    }
  }
  nx = weights.size(0) * weights.size(1);
  i1 = (nx < 3200);
  if (i1) {
    for (i = 0; i < nx; i++) {
      weights[i] = ((weights[i] >= -0.5) && (weights[i] < 0.5));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(k)

    for (i = 0; i < nx; i++) {
      k = ((weights[i] >= -0.5) && (weights[i] < 0.5));
      weights[i] = k;
    }
  }
  if (scale < 1.0) {
    if (i1) {
      for (i = 0; i < nx; i++) {
        weights[i] = scale * weights[i];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (i = 0; i < nx; i++) {
        weights[i] = scale * weights[i];
      }
    }
  }
  sum(weights, u);
  b_indices.set_size(weights.size(0), weights.size(1));
  yk = weights.size(0) * weights.size(1) - 1;
  for (i1 = 0; i1 <= yk; i1++) {
    b_indices[i1] = weights[i1];
  }
  bsxfun(b_indices, u, weights);
  //  Create the auxiliary matrix:
  nx = in_length << 1;
  aux.set_size(1, nx);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (varargin_3 = 2; varargin_3 <= in_length; varargin_3++) {
    aux[varargin_3 - 1] = aux[varargin_3 - 2] + 1;
    yk = in_length + varargin_3;
    aux[yk - 1] = aux[yk - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (varargin_3 = 0; varargin_3 < c_k; varargin_3++) {
    indices[varargin_3] = aux[static_cast<int>(
        b_mod(static_cast<double>(indices[varargin_3]) - 1.0,
              static_cast<double>(nx)))];
  }
  any(weights, r);
  yk = r.size(1) - 1;
  nx = 0;
  if (static_cast<int>(r.size(1) < 3200)) {
    for (k = 0; k <= yk; k++) {
      if (r[k]) {
        nx++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= yk; k++) {
        if (r[k]) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        nx += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, nx);
  nx = 0;
  for (varargin_3 = 0; varargin_3 <= yk; varargin_3++) {
    if (r[varargin_3]) {
      r1[nx] = varargin_3;
      nx++;
    }
  }
  nx = weights.size(0);
  b_indices.set_size(r1.size(1), weights.size(0));
  for (i1 = 0; i1 < nx; i1++) {
    yk = r1.size(1);
    for (i2 = 0; i2 < yk; i2++) {
      b_indices[i2 + b_indices.size(0) * i1] =
          weights[i1 + weights.size(0) * r1[i2]];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  yk = b_indices.size(0) * b_indices.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (i = 0; i < yk; i++) {
      weights[i] = b_indices[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < yk; i++) {
      weights[i] = b_indices[i];
    }
  }
  nx = indices.size(0);
  c_indices.set_size(r1.size(1), indices.size(0));
  for (i1 = 0; i1 < nx; i1++) {
    yk = r1.size(1);
    for (i2 = 0; i2 < yk; i2++) {
      c_indices[i2 + c_indices.size(0) * i1] =
          indices[i1 + indices.size(0) * r1[i2]];
    }
  }
  indices.set_size(c_indices.size(0), c_indices.size(1));
  yk = c_indices.size(0) * c_indices.size(1);
  if (static_cast<int>(yk < 3200)) {
    for (i = 0; i < yk; i++) {
      indices[i] = c_indices[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (i = 0; i < yk; i++) {
      indices[i] = c_indices[i];
    }
  }
}

} // namespace coder
static double rt_powd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = rtNaN;
  } else {
    double d;
    double d1;
    d = std::abs(u0);
    d1 = std::abs(u1);
    if (std::isinf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = rtNaN;
    } else {
      y = std::pow(u0, u1);
    }
  }
  return y;
}

namespace coder {
void b_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    b_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 2.0, weights,
                    indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    b_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 2.0, weights,
                    indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    b_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 2.0, weights,
                    indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    b_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 2.0, weights,
                    indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void b_resizeAlongDim2D(const ::coder::array<double, 2U> &in,
                        const ::coder::array<double, 2U> &weights,
                        const ::coder::array<int, 2U> &indices,
                        double out_length, ::coder::array<double, 2U> &out)
{
  double sumVal1;
  int i;
  int i1;
  int k;
  int linearInds;
  int outCInd;
  int pixelIndex;
  int pixelIndex_tmp;
  int ub_loop;
  ub_loop = in.size(0) - 1;
#pragma omp parallel for num_threads(32 > omp_get_max_threads()                \
                                         ? omp_get_max_threads()               \
                                         : 32) private(pixelIndex, linearInds, \
                                                       sumVal1, i, outCInd,    \
                                                       i1, k, pixelIndex_tmp)

  for (int inRInd = 0; inRInd <= ub_loop; inRInd++) {
    i = static_cast<int>(out_length);
    for (outCInd = 0; outCInd < i; outCInd++) {
      sumVal1 = 0.0;
      //  Core - second dimension
      i1 = weights.size(0);
      linearInds = weights.size(0) * outCInd + 1;
      for (k = 0; k < i1; k++) {
        pixelIndex_tmp = (linearInds + k) - 1;
        pixelIndex = (inRInd + (indices[pixelIndex_tmp] - 1) * in.size(0)) + 1;
        sumVal1 += weights[pixelIndex_tmp] * in[pixelIndex - 1];
      }
      out[inRInd + out.size(0) * outCInd] = sumVal1;
    }
  }
}

void c_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    c_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 4.0, weights,
                    indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    c_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 4.0, weights,
                    indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    c_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 4.0, weights,
                    indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    c_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 4.0, weights,
                    indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void d_contributions(int in_length, double out_length, double scale,
                     ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b;
  array<double, 2U> b_y;
  array<double, 2U> c_indices;
  array<double, 2U> f;
  array<double, 2U> xin;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b_indices;
  array<int, 1U> a;
  double d;
  int bcoef;
  int c_k;
  int i;
  int loop_ub_tmp;
  int nx;
  signed char tmp_data[6];
  boolean_T b_bv[6];
  //  Contributions, using pixel indices
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (int k{0}; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  d = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      u[k] = y[k] / scale + d;
    }
  }
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = u[k] - 2.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = u[k] - 2.0;
    }
  }
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  a.set_size(x.size(0));
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  b_indices.set_size(a.size(0), 6);
  if (a.size(0) != 0) {
    nx = (a.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = b_indices.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        b_indices[c_k + b_indices.size(0) * b_k] = a[nx * c_k] + b_k;
      }
    }
  }
  c_indices.set_size(b_indices.size(0), 6);
  loop_ub_tmp = b_indices.size(0) * 6;
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (int k{0}; k < loop_ub_tmp; k++) {
      c_indices[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < loop_ub_tmp; k++) {
      c_indices[k] = b_indices[k];
    }
  }
  bcoef = c_indices.size(0);
  nx = u.size(0);
  if (bcoef <= nx) {
    nx = bcoef;
  }
  if (c_indices.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = c_indices.size(0);
  } else if (u.size(0) == c_indices.size(0)) {
    i = u.size(0);
  } else {
    i = nx;
  }
  xin.set_size(i, 6);
  if (i != 0) {
    nx = (u.size(0) != 1);
    bcoef = (c_indices.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = xin.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        xin[c_k + xin.size(0) * b_k] =
            u[nx * c_k] - c_indices[bcoef * c_k + c_indices.size(0) * b_k];
      }
    }
  }
  c_indices.set_size(xin.size(0), 6);
  nx = xin.size(0) * 6;
  i = (nx < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      c_indices[k] = 3.1415926535897931 * xin[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      c_indices[k] = 3.1415926535897931 * xin[k];
    }
  }
  f.set_size(c_indices.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      f[k] = c_indices[k];
    }
    for (int k{0}; k < nx; k++) {
      f[k] = std::sin(f[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = c_indices[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = std::sin(f[k]);
    }
  }
  c_indices.set_size(c_indices.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      c_indices[k] = c_indices[k] / 2.0;
    }
    for (int k{0}; k < nx; k++) {
      c_indices[k] = std::sin(c_indices[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      c_indices[k] = c_indices[k] / 2.0;
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      c_indices[k] = std::sin(c_indices[k]);
    }
  }
  b.set_size(xin.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b[k] = xin[k] * xin[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b[k] = xin[k] * xin[k];
    }
  }
  b_y.set_size(xin.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b_y[k] = std::abs(xin[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b_y[k] = std::abs(xin[k]);
    }
  }
  f.set_size(f.size(0), 6);
  if (i) {
    for (int k{0}; k < nx; k++) {
      f[k] = (f[k] * c_indices[k] + 2.2204460492503131E-16) /
             (9.869604401089358 * b[k] / 2.0 + 2.2204460492503131E-16) *
             static_cast<double>(b_y[k] < 2.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = (f[k] * c_indices[k] + 2.2204460492503131E-16) /
             (9.869604401089358 * b[k] / 2.0 + 2.2204460492503131E-16) *
             static_cast<double>(b_y[k] < 2.0);
    }
  }
  if (f.size(0) == 0) {
    u.set_size(0);
  } else {
    nx = f.size(0);
    u.set_size(f.size(0));
    if (static_cast<int>(f.size(0) < 3200)) {
      for (int k{0}; k < nx; k++) {
        u[k] = f[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < nx; k++) {
        u[k] = f[k];
      }
    }
    for (int b_k{0}; b_k < 5; b_k++) {
      bcoef = (b_k + 1) * nx;
      for (c_k = 0; c_k < nx; c_k++) {
        u[c_k] = u[c_k] + f[bcoef + c_k];
      }
    }
  }
  c_indices.set_size(f.size(0), 6);
  nx = f.size(0) * f.size(1) - 1;
  for (i = 0; i <= nx; i++) {
    c_indices[i] = f[i];
  }
  bcoef = u.size(0);
  nx = c_indices.size(0);
  if (bcoef <= nx) {
    nx = bcoef;
  }
  if (u.size(0) == 1) {
    i = c_indices.size(0);
  } else if (c_indices.size(0) == 1) {
    i = u.size(0);
  } else if (c_indices.size(0) == u.size(0)) {
    i = c_indices.size(0);
  } else {
    i = nx;
  }
  f.set_size(i, 6);
  if (i != 0) {
    nx = (c_indices.size(0) != 1);
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 6; b_k++) {
      i = f.size(0) - 1;
      for (c_k = 0; c_k <= i; c_k++) {
        f[c_k + f.size(0) * b_k] =
            c_indices[nx * c_k + c_indices.size(0) * b_k] / u[bcoef * c_k];
      }
    }
  }
  //  Create the auxiliary matrix:
  bcoef = in_length << 1;
  aux.set_size(1, bcoef);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (int b_k{2}; b_k <= in_length; b_k++) {
    aux[b_k - 1] = aux[b_k - 2] + 1;
    nx = in_length + b_k;
    aux[nx - 1] = aux[nx - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (int b_k{0}; b_k < loop_ub_tmp; b_k++) {
    b_indices[b_k] =
        aux[static_cast<int>(b_mod(static_cast<double>(b_indices[b_k]) - 1.0,
                                   static_cast<double>(bcoef)))];
  }
  b_any(f, b_bv);
  c_k = 0;
  bcoef = 0;
  for (int b_k{0}; b_k < 6; b_k++) {
    if (b_bv[b_k]) {
      c_k++;
      tmp_data[bcoef] = static_cast<signed char>(b_k);
      bcoef++;
    }
  }
  weights.set_size(c_k, f.size(0));
  nx = f.size(0);
  for (i = 0; i < nx; i++) {
    for (bcoef = 0; bcoef < c_k; bcoef++) {
      weights[bcoef + weights.size(0) * i] = f[i + f.size(0) * tmp_data[bcoef]];
    }
  }
  indices.set_size(c_k, b_indices.size(0));
  nx = b_indices.size(0);
  for (i = 0; i < nx; i++) {
    for (bcoef = 0; bcoef < c_k; bcoef++) {
      indices[bcoef + indices.size(0) * i] =
          b_indices[i + b_indices.size(0) * tmp_data[bcoef]];
    }
  }
}

void d_contributions(int in_length, double out_length, double scale,
                     double kernel_width, ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b_indices;
  array<double, 2U> b_x;
  array<double, 2U> b_y;
  array<double, 2U> c_y;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> c_indices;
  array<int, 2U> r1;
  array<int, 1U> a;
  array<boolean_T, 2U> r;
  double b_kernel_width;
  int P;
  int b_k;
  int bcoef;
  int c_k;
  int i;
  int i1;
  int k;
  int loop_ub_tmp;
  int nx;
  int trueCountPrime;
  unsigned int unnamed_idx_0_tmp;
  unsigned int unnamed_idx_1_tmp;
  int varargin_3;
  //  Contributions, using pixel indices
  if (scale < 1.0) {
    kernel_width = 4.0 / scale;
  }
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  b_kernel_width = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  }
  b_kernel_width = kernel_width / 2.0;
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  }
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  P = static_cast<int>(std::ceil(kernel_width) + 2.0);
  if (P - 1 < 0) {
    P = 0;
  }
  aux.set_size(1, P);
  if (P > 0) {
    aux[0] = 0;
    nx = 0;
    for (b_k = 2; b_k <= P; b_k++) {
      nx++;
      aux[b_k - 1] = nx;
    }
  }
  a.set_size(x.size(0));
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  indices.set_size(a.size(0), aux.size(1));
  if ((a.size(0) != 0) && (aux.size(1) != 0)) {
    P = (aux.size(1) != 1);
    i = aux.size(1) - 1;
    nx = (a.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = P * b_k;
      i1 = indices.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        indices[c_k + indices.size(0) * b_k] = a[nx * c_k] + aux[varargin_3];
      }
    }
  }
  b_indices.set_size(indices.size(0), indices.size(1));
  loop_ub_tmp = indices.size(0) * indices.size(1);
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (k = 0; k < loop_ub_tmp; k++) {
      b_indices[k] = indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub_tmp; k++) {
      b_indices[k] = indices[k];
    }
  }
  P = b_indices.size(0);
  nx = u.size(0);
  if (P <= nx) {
    nx = P;
  }
  if (b_indices.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = b_indices.size(0);
  } else if (u.size(0) == b_indices.size(0)) {
    i = u.size(0);
  } else {
    i = nx;
  }
  b_x.set_size(i, b_indices.size(1));
  if ((i != 0) && (b_indices.size(1) != 0)) {
    P = (b_indices.size(1) != 1);
    i = b_indices.size(1) - 1;
    nx = (u.size(0) != 1);
    bcoef = (b_indices.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = P * b_k;
      i1 = b_x.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        b_x[c_k + b_x.size(0) * b_k] =
            u[nx * c_k] -
            b_indices[bcoef * c_k + b_indices.size(0) * varargin_3];
      }
    }
  }
  if (scale < 1.0) {
    nx = b_x.size(0) * b_x.size(1);
    if (static_cast<int>(nx < 3200)) {
      for (k = 0; k < nx; k++) {
        b_x[k] = scale * b_x[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        b_x[k] = scale * b_x[k];
      }
    }
  }
  b_indices.set_size(b_x.size(0), b_x.size(1));
  nx = b_x.size(0) * b_x.size(1);
  i = (nx < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      b_indices[k] = 3.1415926535897931 * b_x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = 3.1415926535897931 * b_x[k];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
    for (k = 0; k < nx; k++) {
      weights[k] = std::sin(weights[k]);
    }
    for (k = 0; k < nx; k++) {
      b_indices[k] = b_indices[k] / 2.0;
    }
    for (k = 0; k < nx; k++) {
      b_indices[k] = std::sin(b_indices[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = std::sin(weights[k]);
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = b_indices[k] / 2.0;
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = std::sin(b_indices[k]);
    }
  }
  unnamed_idx_0_tmp = static_cast<unsigned int>(b_x.size(0));
  unnamed_idx_1_tmp = static_cast<unsigned int>(b_x.size(1));
  b_y.set_size(b_x.size(0), b_x.size(1));
  if (i) {
    for (k = 0; k < nx; k++) {
      b_y[k] = std::abs(b_x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_y[k] = std::abs(b_x[k]);
    }
  }
  c_y.set_size(static_cast<int>(unnamed_idx_0_tmp),
               static_cast<int>(unnamed_idx_1_tmp));
  P = static_cast<int>(unnamed_idx_0_tmp) * static_cast<int>(unnamed_idx_1_tmp);
  if (static_cast<int>(P < 3200)) {
    for (k = 0; k < P; k++) {
      c_y[k] = b_x[k] * b_x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < P; k++) {
      c_y[k] = b_x[k] * b_x[k];
    }
  }
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] = (weights[k] * b_indices[k] + 2.2204460492503131E-16) /
                   (9.869604401089358 * c_y[k] / 2.0 + 2.2204460492503131E-16) *
                   static_cast<double>(b_y[k] < 2.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = (weights[k] * b_indices[k] + 2.2204460492503131E-16) /
                   (9.869604401089358 * c_y[k] / 2.0 + 2.2204460492503131E-16) *
                   static_cast<double>(b_y[k] < 2.0);
    }
  }
  if (scale < 1.0) {
    if (i) {
      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    }
  }
  sum(weights, u);
  b_indices.set_size(weights.size(0), weights.size(1));
  nx = weights.size(0) * weights.size(1) - 1;
  for (i = 0; i <= nx; i++) {
    b_indices[i] = weights[i];
  }
  bsxfun(b_indices, u, weights);
  //  Create the auxiliary matrix:
  P = in_length << 1;
  aux.set_size(1, P);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (varargin_3 = 2; varargin_3 <= in_length; varargin_3++) {
    aux[varargin_3 - 1] = aux[varargin_3 - 2] + 1;
    nx = in_length + varargin_3;
    aux[nx - 1] = aux[nx - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (varargin_3 = 0; varargin_3 < loop_ub_tmp; varargin_3++) {
    indices[varargin_3] = aux[static_cast<int>(
        b_mod(static_cast<double>(indices[varargin_3]) - 1.0,
              static_cast<double>(P)))];
  }
  any(weights, r);
  nx = r.size(1) - 1;
  P = 0;
  if (static_cast<int>(r.size(1) < 3200)) {
    for (k = 0; k <= nx; k++) {
      if (r[k]) {
        P++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= nx; k++) {
        if (r[k]) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        P += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, P);
  P = 0;
  for (varargin_3 = 0; varargin_3 <= nx; varargin_3++) {
    if (r[varargin_3]) {
      r1[P] = varargin_3;
      P++;
    }
  }
  P = weights.size(0);
  b_indices.set_size(r1.size(1), weights.size(0));
  for (i = 0; i < P; i++) {
    nx = r1.size(1);
    for (i1 = 0; i1 < nx; i1++) {
      b_indices[i1 + b_indices.size(0) * i] =
          weights[i + weights.size(0) * r1[i1]];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  nx = b_indices.size(0) * b_indices.size(1);
  if (static_cast<int>(nx < 3200)) {
    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
  }
  P = indices.size(0);
  c_indices.set_size(r1.size(1), indices.size(0));
  for (i = 0; i < P; i++) {
    nx = r1.size(1);
    for (i1 = 0; i1 < nx; i1++) {
      c_indices[i1 + c_indices.size(0) * i] =
          indices[i + indices.size(0) * r1[i1]];
    }
  }
  indices.set_size(c_indices.size(0), c_indices.size(1));
  nx = c_indices.size(0) * c_indices.size(1);
  if (static_cast<int>(nx < 3200)) {
    for (k = 0; k < nx; k++) {
      indices[k] = c_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      indices[k] = c_indices[k];
    }
  }
}

void d_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights, indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights, indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights, indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights, indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void e_contributions(int in_length, double out_length, double scale,
                     ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b;
  array<double, 2U> b_b;
  array<double, 2U> b_y;
  array<double, 2U> f;
  array<double, 2U> xin;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> b_indices;
  array<int, 1U> left;
  double d;
  int acoef;
  int bcoef;
  int i;
  int loop_ub_tmp;
  int nx;
  int vstride;
  signed char tmp_data[8];
  boolean_T copyCols[8];
  //  Contributions, using pixel indices
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    acoef = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (int k{0}; k <= acoef; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k <= acoef; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  d = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  acoef = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (int k{0}; k < acoef; k++) {
      u[k] = y[k] / scale + d;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < acoef; k++) {
      u[k] = y[k] / scale + d;
    }
  }
  x.set_size(u.size(0));
  acoef = u.size(0);
  if (i) {
    for (int k{0}; k < acoef; k++) {
      x[k] = u[k] - 3.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < acoef; k++) {
      x[k] = u[k] - 3.0;
    }
  }
  nx = x.size(0);
  if (i) {
    for (int k{0}; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  left.set_size(x.size(0));
  acoef = x.size(0);
  if (i) {
    for (int k{0}; k < acoef; k++) {
      left[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < acoef; k++) {
      left[k] = static_cast<int>(x[k]);
    }
  }
  b_indices.set_size(left.size(0), 8);
  if (left.size(0) != 0) {
    acoef = (left.size(0) != 1);
    for (int b_k{0}; b_k < 8; b_k++) {
      i = b_indices.size(0) - 1;
      for (nx = 0; nx <= i; nx++) {
        b_indices[nx + b_indices.size(0) * b_k] = left[acoef * nx] + b_k;
      }
    }
  }
  b.set_size(b_indices.size(0), 8);
  loop_ub_tmp = b_indices.size(0) << 3;
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (int k{0}; k < loop_ub_tmp; k++) {
      b[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < loop_ub_tmp; k++) {
      b[k] = b_indices[k];
    }
  }
  acoef = b.size(0);
  bcoef = u.size(0);
  if (acoef <= bcoef) {
    bcoef = acoef;
  }
  if (b.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = b.size(0);
  } else if (u.size(0) == b.size(0)) {
    i = u.size(0);
  } else {
    i = bcoef;
  }
  xin.set_size(i, 8);
  if (i != 0) {
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 8; b_k++) {
      i = xin.size(0) - 1;
      for (nx = 0; nx <= i; nx++) {
        vstride = bcoef * nx;
        xin[nx + xin.size(0) * b_k] = u[vstride] - b[vstride + b.size(0) * b_k];
      }
    }
  }
  b.set_size(xin.size(0), 8);
  nx = xin.size(0) << 3;
  i = (nx < 3200);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b[k] = 3.1415926535897931 * xin[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b[k] = 3.1415926535897931 * xin[k];
    }
  }
  f.set_size(b.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      f[k] = b[k];
    }
    for (int k{0}; k < nx; k++) {
      f[k] = std::sin(f[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = b[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = std::sin(f[k]);
    }
  }
  b.set_size(b.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b[k] = b[k] / 3.0;
    }
    for (int k{0}; k < nx; k++) {
      b[k] = std::sin(b[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b[k] = b[k] / 3.0;
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b[k] = std::sin(b[k]);
    }
  }
  b_b.set_size(xin.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b_b[k] = xin[k] * xin[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b_b[k] = xin[k] * xin[k];
    }
  }
  b_y.set_size(xin.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b_y[k] = std::abs(xin[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b_y[k] = std::abs(xin[k]);
    }
  }
  f.set_size(f.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      f[k] = (f[k] * b[k] + 2.2204460492503131E-16) /
             (9.869604401089358 * b_b[k] / 3.0 + 2.2204460492503131E-16) *
             static_cast<double>(b_y[k] < 3.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      f[k] = (f[k] * b[k] + 2.2204460492503131E-16) /
             (9.869604401089358 * b_b[k] / 3.0 + 2.2204460492503131E-16) *
             static_cast<double>(b_y[k] < 3.0);
    }
  }
  if (f.size(0) == 0) {
    u.set_size(0);
  } else {
    vstride = f.size(0);
    u.set_size(f.size(0));
    if (static_cast<int>(f.size(0) < 3200)) {
      for (int k{0}; k < vstride; k++) {
        u[k] = f[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int k = 0; k < vstride; k++) {
        u[k] = f[k];
      }
    }
    for (int b_k{0}; b_k < 7; b_k++) {
      acoef = (b_k + 1) * vstride;
      for (bcoef = 0; bcoef < vstride; bcoef++) {
        u[bcoef] = u[bcoef] + f[acoef + bcoef];
      }
    }
  }
  b.set_size(f.size(0), 8);
  if (i) {
    for (int k{0}; k < nx; k++) {
      b[k] = f[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int k = 0; k < nx; k++) {
      b[k] = f[k];
    }
  }
  acoef = u.size(0);
  bcoef = f.size(0);
  if (acoef <= bcoef) {
    bcoef = acoef;
  }
  if (u.size(0) == 1) {
    acoef = f.size(0);
  } else if (f.size(0) == 1) {
    acoef = u.size(0);
  } else if (f.size(0) == u.size(0)) {
    acoef = f.size(0);
  } else {
    acoef = bcoef;
  }
  f.set_size(acoef, 8);
  if (acoef != 0) {
    acoef = (b.size(0) != 1);
    bcoef = (u.size(0) != 1);
    for (int b_k{0}; b_k < 8; b_k++) {
      i = f.size(0) - 1;
      for (nx = 0; nx <= i; nx++) {
        f[nx + f.size(0) * b_k] =
            b[acoef * nx + b.size(0) * b_k] / u[bcoef * nx];
      }
    }
  }
  //  Create the auxiliary matrix:
  acoef = in_length << 1;
  aux.set_size(1, acoef);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (nx = 2; nx <= in_length; nx++) {
    aux[nx - 1] = aux[nx - 2] + 1;
    bcoef = in_length + nx;
    aux[bcoef - 1] = aux[bcoef - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (nx = 0; nx < loop_ub_tmp; nx++) {
    b_indices[nx] = aux[static_cast<int>(b_mod(
        static_cast<double>(b_indices[nx]) - 1.0, static_cast<double>(acoef)))];
  }
  for (i = 0; i < 8; i++) {
    copyCols[i] = false;
  }
  acoef = 0;
  for (nx = 0; nx < 8; nx++) {
    boolean_T exitg1;
    bcoef = acoef + f.size(0);
    vstride = acoef;
    acoef += f.size(0);
    exitg1 = false;
    while ((!exitg1) && (vstride + 1 <= bcoef)) {
      if ((f[vstride] == 0.0) || std::isnan(f[vstride])) {
        vstride++;
      } else {
        copyCols[nx] = true;
        exitg1 = true;
      }
    }
  }
  vstride = 0;
  acoef = 0;
  for (nx = 0; nx < 8; nx++) {
    if (copyCols[nx]) {
      vstride++;
      tmp_data[acoef] = static_cast<signed char>(nx);
      acoef++;
    }
  }
  weights.set_size(vstride, f.size(0));
  acoef = f.size(0);
  for (i = 0; i < acoef; i++) {
    for (bcoef = 0; bcoef < vstride; bcoef++) {
      weights[bcoef + weights.size(0) * i] = f[i + f.size(0) * tmp_data[bcoef]];
    }
  }
  indices.set_size(vstride, b_indices.size(0));
  acoef = b_indices.size(0);
  for (i = 0; i < acoef; i++) {
    for (bcoef = 0; bcoef < vstride; bcoef++) {
      indices[bcoef + indices.size(0) * i] =
          b_indices[i + b_indices.size(0) * tmp_data[bcoef]];
    }
  }
}

void e_contributions(int in_length, double out_length, double scale,
                     double kernel_width, ::coder::array<double, 2U> &weights,
                     ::coder::array<int, 2U> &indices)
{
  array<double, 2U> b_indices;
  array<double, 2U> b_x;
  array<double, 2U> b_y;
  array<double, 2U> c_y;
  array<double, 2U> y;
  array<double, 1U> u;
  array<double, 1U> x;
  array<int, 2U> aux;
  array<int, 2U> c_indices;
  array<int, 2U> r1;
  array<int, 1U> a;
  array<boolean_T, 2U> r;
  double b_kernel_width;
  int P;
  int b_k;
  int bcoef;
  int c_k;
  int i;
  int i1;
  int k;
  int loop_ub_tmp;
  int nx;
  int trueCountPrime;
  unsigned int unnamed_idx_0_tmp;
  unsigned int unnamed_idx_1_tmp;
  int varargin_3;
  //  Contributions, using pixel indices
  if (scale < 1.0) {
    kernel_width = 6.0 / scale;
  }
  if (std::isnan(out_length)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (out_length < 1.0) {
    y.set_size(1, 0);
  } else {
    y.set_size(1, static_cast<int>(out_length - 1.0) + 1);
    nx = static_cast<int>(out_length - 1.0);
    if (static_cast<int>(static_cast<int>(out_length - 1.0) + 1 < 3200)) {
      for (k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k <= nx; k++) {
        y[k] = static_cast<double>(k) + 1.0;
      }
    }
  }
  b_kernel_width = 0.5 * (1.0 - 1.0 / scale);
  u.set_size(y.size(1));
  nx = y.size(1);
  i = (y.size(1) < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      u[k] = y[k] / scale + b_kernel_width;
    }
  }
  b_kernel_width = kernel_width / 2.0;
  x.set_size(u.size(0));
  nx = u.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = u[k] - b_kernel_width;
    }
  }
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::floor(x[k]);
    }
  }
  P = static_cast<int>(std::ceil(kernel_width) + 2.0);
  if (P - 1 < 0) {
    P = 0;
  }
  aux.set_size(1, P);
  if (P > 0) {
    aux[0] = 0;
    nx = 0;
    for (b_k = 2; b_k <= P; b_k++) {
      nx++;
      aux[b_k - 1] = nx;
    }
  }
  a.set_size(x.size(0));
  nx = x.size(0);
  if (i) {
    for (k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      a[k] = static_cast<int>(x[k]);
    }
  }
  indices.set_size(a.size(0), aux.size(1));
  if ((a.size(0) != 0) && (aux.size(1) != 0)) {
    P = (aux.size(1) != 1);
    i = aux.size(1) - 1;
    nx = (a.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = P * b_k;
      i1 = indices.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        indices[c_k + indices.size(0) * b_k] = a[nx * c_k] + aux[varargin_3];
      }
    }
  }
  b_indices.set_size(indices.size(0), indices.size(1));
  loop_ub_tmp = indices.size(0) * indices.size(1);
  if (static_cast<int>(loop_ub_tmp < 3200)) {
    for (k = 0; k < loop_ub_tmp; k++) {
      b_indices[k] = indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub_tmp; k++) {
      b_indices[k] = indices[k];
    }
  }
  P = b_indices.size(0);
  nx = u.size(0);
  if (P <= nx) {
    nx = P;
  }
  if (b_indices.size(0) == 1) {
    i = u.size(0);
  } else if (u.size(0) == 1) {
    i = b_indices.size(0);
  } else if (u.size(0) == b_indices.size(0)) {
    i = u.size(0);
  } else {
    i = nx;
  }
  b_x.set_size(i, b_indices.size(1));
  if ((i != 0) && (b_indices.size(1) != 0)) {
    P = (b_indices.size(1) != 1);
    i = b_indices.size(1) - 1;
    nx = (u.size(0) != 1);
    bcoef = (b_indices.size(0) != 1);
    for (b_k = 0; b_k <= i; b_k++) {
      varargin_3 = P * b_k;
      i1 = b_x.size(0) - 1;
      for (c_k = 0; c_k <= i1; c_k++) {
        b_x[c_k + b_x.size(0) * b_k] =
            u[nx * c_k] -
            b_indices[bcoef * c_k + b_indices.size(0) * varargin_3];
      }
    }
  }
  if (scale < 1.0) {
    nx = b_x.size(0) * b_x.size(1);
    if (static_cast<int>(nx < 3200)) {
      for (k = 0; k < nx; k++) {
        b_x[k] = scale * b_x[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        b_x[k] = scale * b_x[k];
      }
    }
  }
  b_indices.set_size(b_x.size(0), b_x.size(1));
  nx = b_x.size(0) * b_x.size(1);
  i = (nx < 3200);
  if (i) {
    for (k = 0; k < nx; k++) {
      b_indices[k] = 3.1415926535897931 * b_x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = 3.1415926535897931 * b_x[k];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
    for (k = 0; k < nx; k++) {
      weights[k] = std::sin(weights[k]);
    }
    for (k = 0; k < nx; k++) {
      b_indices[k] = b_indices[k] / 3.0;
    }
    for (k = 0; k < nx; k++) {
      b_indices[k] = std::sin(b_indices[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = std::sin(weights[k]);
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = b_indices[k] / 3.0;
    }
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_indices[k] = std::sin(b_indices[k]);
    }
  }
  unnamed_idx_0_tmp = static_cast<unsigned int>(b_x.size(0));
  unnamed_idx_1_tmp = static_cast<unsigned int>(b_x.size(1));
  b_y.set_size(b_x.size(0), b_x.size(1));
  if (i) {
    for (k = 0; k < nx; k++) {
      b_y[k] = std::abs(b_x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      b_y[k] = std::abs(b_x[k]);
    }
  }
  c_y.set_size(static_cast<int>(unnamed_idx_0_tmp),
               static_cast<int>(unnamed_idx_1_tmp));
  P = static_cast<int>(unnamed_idx_0_tmp) * static_cast<int>(unnamed_idx_1_tmp);
  if (static_cast<int>(P < 3200)) {
    for (k = 0; k < P; k++) {
      c_y[k] = b_x[k] * b_x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < P; k++) {
      c_y[k] = b_x[k] * b_x[k];
    }
  }
  if (i) {
    for (k = 0; k < nx; k++) {
      weights[k] = (weights[k] * b_indices[k] + 2.2204460492503131E-16) /
                   (9.869604401089358 * c_y[k] / 3.0 + 2.2204460492503131E-16) *
                   static_cast<double>(b_y[k] < 3.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = (weights[k] * b_indices[k] + 2.2204460492503131E-16) /
                   (9.869604401089358 * c_y[k] / 3.0 + 2.2204460492503131E-16) *
                   static_cast<double>(b_y[k] < 3.0);
    }
  }
  if (scale < 1.0) {
    if (i) {
      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k < nx; k++) {
        weights[k] = scale * weights[k];
      }
    }
  }
  sum(weights, u);
  b_indices.set_size(weights.size(0), weights.size(1));
  nx = weights.size(0) * weights.size(1) - 1;
  for (i = 0; i <= nx; i++) {
    b_indices[i] = weights[i];
  }
  bsxfun(b_indices, u, weights);
  //  Create the auxiliary matrix:
  P = in_length << 1;
  aux.set_size(1, P);
  aux[0] = 1;
  aux[in_length] = in_length;
  for (varargin_3 = 2; varargin_3 <= in_length; varargin_3++) {
    aux[varargin_3 - 1] = aux[varargin_3 - 2] + 1;
    nx = in_length + varargin_3;
    aux[nx - 1] = aux[nx - 2] - 1;
  }
  //  Mirror the out-of-bounds indices using mod:
  for (varargin_3 = 0; varargin_3 < loop_ub_tmp; varargin_3++) {
    indices[varargin_3] = aux[static_cast<int>(
        b_mod(static_cast<double>(indices[varargin_3]) - 1.0,
              static_cast<double>(P)))];
  }
  any(weights, r);
  nx = r.size(1) - 1;
  P = 0;
  if (static_cast<int>(r.size(1) < 3200)) {
    for (k = 0; k <= nx; k++) {
      if (r[k]) {
        P++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= nx; k++) {
        if (r[k]) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        P += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, P);
  P = 0;
  for (varargin_3 = 0; varargin_3 <= nx; varargin_3++) {
    if (r[varargin_3]) {
      r1[P] = varargin_3;
      P++;
    }
  }
  P = weights.size(0);
  b_indices.set_size(r1.size(1), weights.size(0));
  for (i = 0; i < P; i++) {
    nx = r1.size(1);
    for (i1 = 0; i1 < nx; i1++) {
      b_indices[i1 + b_indices.size(0) * i] =
          weights[i + weights.size(0) * r1[i1]];
    }
  }
  weights.set_size(b_indices.size(0), b_indices.size(1));
  nx = b_indices.size(0) * b_indices.size(1);
  if (static_cast<int>(nx < 3200)) {
    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      weights[k] = b_indices[k];
    }
  }
  P = indices.size(0);
  c_indices.set_size(r1.size(1), indices.size(0));
  for (i = 0; i < P; i++) {
    nx = r1.size(1);
    for (i1 = 0; i1 < nx; i1++) {
      c_indices[i1 + c_indices.size(0) * i] =
          indices[i + indices.size(0) * r1[i1]];
    }
  }
  indices.set_size(c_indices.size(0), c_indices.size(1));
  nx = c_indices.size(0) * c_indices.size(1);
  if (static_cast<int>(nx < 3200)) {
    for (k = 0; k < nx; k++) {
      indices[k] = c_indices[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      indices[k] = c_indices[k];
    }
  }
}

void e_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    b_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights,
                    indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    b_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights,
                    indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    b_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights,
                    indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    b_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights,
                    indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void f_imresize(const ::coder::array<double, 2U> &Ain,
                const double varargin_1[2], ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    c_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights,
                    indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    c_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights,
                    indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    c_contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, weights,
                    indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    c_contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, weights,
                    indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void imresize(const ::coder::array<double, 2U> &Ain, const double varargin_1[2],
              ::coder::array<double, 2U> &Bout)
{
  array<double, 2U> out;
  array<double, 2U> weights;
  array<int, 2U> indices;
  double outputSize_idx_0;
  double outputSize_idx_1;
  double scale_idx_0;
  double scale_idx_1;
  if (std::isnan(varargin_1[0])) {
    outputSize_idx_0 =
        std::ceil(varargin_1[1] * static_cast<double>(Ain.size(0)) /
                  static_cast<double>(Ain.size(1)));
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  } else if (std::isnan(varargin_1[1])) {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 =
        std::ceil(varargin_1[0] * static_cast<double>(Ain.size(1)) /
                  static_cast<double>(Ain.size(0)));
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = scale_idx_0;
  } else {
    outputSize_idx_0 = std::ceil(varargin_1[0]);
    outputSize_idx_1 = std::ceil(varargin_1[1]);
    scale_idx_0 = outputSize_idx_0 / static_cast<double>(Ain.size(0));
    scale_idx_1 = outputSize_idx_1 / static_cast<double>(Ain.size(1));
  }
  if (scale_idx_0 <= scale_idx_1) {
    //  Resize first dimension
    contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 1.0, weights,
                  indices);
    out.set_size(weights.size(1), Ain.size(1));
    resizeAlongDim2D(Ain, weights, indices,
                     static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 1.0, weights,
                  indices);
    Bout.set_size(out.size(0), weights.size(1));
    b_resizeAlongDim2D(out, weights, indices,
                       static_cast<double>(weights.size(1)), Bout);
  } else {
    contributions(Ain.size(1), outputSize_idx_1, scale_idx_1, 1.0, weights,
                  indices);
    out.set_size(Ain.size(0), weights.size(1));
    b_resizeAlongDim2D(Ain, weights, indices,
                       static_cast<double>(weights.size(1)), out);
    //  Resize second dimension
    contributions(Ain.size(0), outputSize_idx_0, scale_idx_0, 1.0, weights,
                  indices);
    Bout.set_size(weights.size(1), out.size(1));
    resizeAlongDim2D(out, weights, indices,
                     static_cast<double>(weights.size(1)), Bout);
  }
}

void resizeAlongDim2D(const ::coder::array<double, 2U> &in,
                      const ::coder::array<double, 2U> &weights,
                      const ::coder::array<int, 2U> &indices, double out_length,
                      ::coder::array<double, 2U> &out)
{
  double sumVal1;
  int i;
  int i1;
  int k;
  int linearInds;
  int outRInd;
  int sumVal1_tmp;
  int ub_loop;
  ub_loop = static_cast<int>(static_cast<double>(in.size(0) * in.size(1)) /
                             static_cast<double>(in.size(0))) -
            1;
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads()                                                 \
        ? omp_get_max_threads()                                                \
        : 32) private(linearInds, sumVal1, i, outRInd, i1, k, sumVal1_tmp)

  for (int inCInd = 0; inCInd <= ub_loop; inCInd++) {
    i = static_cast<int>(out_length);
    for (outRInd = 0; outRInd < i; outRInd++) {
      sumVal1 = 0.0;
      i1 = weights.size(0);
      linearInds = weights.size(0) * outRInd + 1;
      //  Core - first dimension
      for (k = 0; k < i1; k++) {
        sumVal1_tmp = (linearInds + k) - 1;
        sumVal1 += weights[sumVal1_tmp] *
                   in[(indices[sumVal1_tmp] + in.size(0) * inCInd) - 1];
      }
      out[outRInd + out.size(0) * inCInd] = sumVal1;
    }
  }
}

} // namespace coder

// End of code generation (imresize.cpp)
