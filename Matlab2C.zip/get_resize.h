//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_resize.h
//
// Code generation for function 'get_resize'
//

#ifndef GET_RESIZE_H
#define GET_RESIZE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void get_resize(const coder::array<double, 2U> &b_I, double W, double H,
                       unsigned long long method, boolean_T Antialiasing,
                       coder::array<double, 2U> &img);

#endif
// End of code generation (get_resize.h)
