//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// isequal.cpp
//
// Code generation for function 'isequal'
//

// Include files
#include "isequal.h"
#include "rt_nonfinite.h"

// Function Definitions
namespace coder {
boolean_T isequal(const double varargin_1_data[], const int varargin_1_size[2],
                  double varargin_2)
{
  boolean_T p;
  p = (varargin_1_size[1] == 1);
  if (p && (varargin_1_size[1] != 0) && (!(varargin_1_data[0] == varargin_2))) {
    p = false;
  }
  return p;
}

} // namespace coder

// End of code generation (isequal.cpp)
