//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// qrsolve.cpp
//
// Code generation for function 'qrsolve'
//

// Include files
#include "qrsolve.h"
#include "rt_nonfinite.h"
#include "xgeqp3.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>
#include <cstring>

// Function Definitions
namespace coder {
namespace internal {
int qrsolve(const ::coder::array<double, 2U> &A,
            const ::coder::array<double, 1U> &B, double Y_data[], int &rankA)
{
  array<double, 2U> b_A;
  array<double, 1U> b_B;
  double tau_data[5];
  double tol;
  int jpvt_data[5];
  int jpvt_size[2];
  int Y_size;
  int assumedRank;
  int maxmn;
  int minmn;
  int u1;
  b_A.set_size(A.size(0), A.size(1));
  minmn = A.size(0) * A.size(1);
  if (static_cast<int>(minmn < 3200)) {
    for (int i{0}; i < minmn; i++) {
      b_A[i] = A[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < minmn; i++) {
      b_A[i] = A[i];
    }
  }
  lapack::xgeqp3(b_A, tau_data, jpvt_data, jpvt_size);
  rankA = 0;
  if (b_A.size(0) < b_A.size(1)) {
    minmn = b_A.size(0);
    maxmn = b_A.size(1);
  } else {
    minmn = b_A.size(1);
    maxmn = b_A.size(0);
  }
  if (minmn > 0) {
    tol = std::fmin(1.4901161193847656E-8,
                    2.2204460492503131E-15 * static_cast<double>(maxmn)) *
          std::abs(b_A[0]);
    while ((rankA < minmn) &&
           (!(std::abs(b_A[rankA + b_A.size(0) * rankA]) <= tol))) {
      rankA++;
    }
  }
  assumedRank = 0;
  minmn = b_A.size(0);
  u1 = b_A.size(1);
  if (minmn <= u1) {
    u1 = minmn;
  }
  if (u1 > 0) {
    for (minmn = 0; minmn < u1; minmn++) {
      if (b_A[minmn + b_A.size(0) * minmn] != 0.0) {
        assumedRank++;
      }
    }
  }
  b_B.set_size(B.size(0));
  minmn = B.size(0);
  if (static_cast<int>(B.size(0) < 3200)) {
    for (int i{0}; i < minmn; i++) {
      b_B[i] = B[i];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < minmn; i++) {
      b_B[i] = B[i];
    }
  }
  Y_size = b_A.size(1);
  minmn = b_A.size(1);
  if (minmn - 1 >= 0) {
    std::memset(&Y_data[0], 0,
                static_cast<unsigned int>(minmn) * sizeof(double));
  }
  minmn = b_A.size(0);
  for (int j{0}; j < u1; j++) {
    if (tau_data[j] != 0.0) {
      tol = b_B[j];
      maxmn = j + 2;
      for (int b_i{maxmn}; b_i <= minmn; b_i++) {
        tol += b_A[(b_i + b_A.size(0) * j) - 1] * b_B[b_i - 1];
      }
      tol *= tau_data[j];
      if (tol != 0.0) {
        b_B[j] = b_B[j] - tol;
        for (int b_i{maxmn}; b_i <= minmn; b_i++) {
          b_B[b_i - 1] = b_B[b_i - 1] - b_A[(b_i + b_A.size(0) * j) - 1] * tol;
        }
      }
    }
  }
  for (int b_i{0}; b_i < assumedRank; b_i++) {
    Y_data[jpvt_data[b_i] - 1] = b_B[b_i];
  }
  for (int j{assumedRank}; j >= 1; j--) {
    maxmn = jpvt_data[j - 1];
    Y_data[maxmn - 1] /= b_A[(j + b_A.size(0) * (j - 1)) - 1];
    for (int b_i{0}; b_i <= j - 2; b_i++) {
      minmn = jpvt_data[b_i];
      Y_data[minmn - 1] -= Y_data[maxmn - 1] * b_A[b_i + b_A.size(0) * (j - 1)];
    }
  }
  return Y_size;
}

} // namespace internal
} // namespace coder

// End of code generation (qrsolve.cpp)
