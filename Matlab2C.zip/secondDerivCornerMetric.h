//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// secondDerivCornerMetric.h
//
// Code generation for function 'secondDerivCornerMetric'
//

#ifndef SECONDDERIVCORNERMETRIC_H
#define SECONDDERIVCORNERMETRIC_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
void b_secondDerivCornerMetric(
    const ::coder::array<float, 2U> &b_I, boolean_T highDistortion,
    ::coder::array<float, 2U> &cxy, ::coder::array<float, 2U> &c45,
    ::coder::array<float, 2U> &Ix, ::coder::array<float, 2U> &Iy,
    ::coder::array<float, 2U> &Ixy, ::coder::array<float, 2U> &I_45_45);

void secondDerivCornerMetric(const ::coder::array<float, 2U> &b_I, double sigma,
                             boolean_T highDistortion,
                             ::coder::array<float, 2U> &cxy,
                             ::coder::array<float, 2U> &c45,
                             ::coder::array<float, 2U> &Ix,
                             ::coder::array<float, 2U> &Iy,
                             ::coder::array<float, 2U> &Ixy,
                             ::coder::array<float, 2U> &I_45_45);

} // namespace checkerboard
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder

#endif
// End of code generation (secondDerivCornerMetric.h)
