//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// secondDerivCornerMetric.cpp
//
// Code generation for function 'secondDerivCornerMetric'
//

// Include files
#include "secondDerivCornerMetric.h"
#include "bsxfun.h"
#include "colon.h"
#include "combineVectorElements.h"
#include "fspecial.h"
#include "get_chessborad_pixel_data.h"
#include "imdilate.h"
#include "imerode.h"
#include "imfilter.h"
#include "minOrMax.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "libmwimfilter.h"
#include "libmwippfilter.h"
#include "omp.h"
#include <cmath>
#include <cstring>

// Type Definitions
struct cell_wrap_11 {
  double f1[25];
};

// Function Declarations
static void b_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2,
                               const coder::array<float, 2U> &in3);

static void b_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2);

static void binary_expand_op(coder::array<float, 2U> &in1, double in2,
                             double in3, const coder::array<float, 2U> &in4,
                             const coder::array<float, 2U> &in5);

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 3U> &in2,
                             const coder::array<float, 2U> &in3);

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 3U> &in2);

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 2U> &in2,
                             const coder::array<float, 2U> &in3);

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 2U> &in2);

static void c_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2);

namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
static void getDerivFilters(cell_wrap_11 filters[12]);

}
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder
static void d_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2,
                               const coder::array<float, 2U> &in3);

// Function Definitions
static void b_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2,
                               const coder::array<float, 2U> &in3)
{
  coder::array<float, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in3.size(0) == 1) {
    if (in2.size(0) == 1) {
      loop_ub = in1.size(0);
    } else {
      loop_ub = in2.size(0);
    }
  } else {
    loop_ub = in3.size(0);
  }
  if (in3.size(1) == 1) {
    if (in2.size(1) == 1) {
      b_loop_ub = in1.size(1);
    } else {
      b_loop_ub = in2.size(1);
    }
  } else {
    b_loop_ub = in3.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  stride_2_0 = (in3.size(0) != 1);
  stride_2_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          (in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] +
           in2[i1 * stride_1_0 + in2.size(0) * aux_1_1]) +
          in3[i1 * stride_2_0 + in3.size(0) * aux_2_1];
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

static void b_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2)
{
  coder::array<float, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] +
          in2[i1 * stride_1_0 + in2.size(0) * aux_1_1] * -0.707106769F;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

static void binary_expand_op(coder::array<float, 2U> &in1, double in2,
                             double in3, const coder::array<float, 2U> &in4,
                             const coder::array<float, 2U> &in5)
{
  coder::array<float, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in5.size(0) == 1) {
    i = in4.size(0);
  } else {
    i = in5.size(0);
  }
  if (i == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = i;
  }
  if (in5.size(1) == 1) {
    i = in4.size(1);
  } else {
    i = in5.size(1);
  }
  if (i == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = i;
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in4.size(0) != 1);
  stride_1_1 = (in4.size(1) != 1);
  stride_2_0 = (in5.size(0) != 1);
  stride_2_1 = (in5.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in2[i1 + b_in2.size(0) * i] =
          static_cast<float>(in2) *
              in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] -
          static_cast<float>(in3) *
              (in4[i1 * stride_1_0 + in4.size(0) * aux_1_1] +
               in5[i1 * stride_2_0 + in5.size(0) * aux_2_1]);
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 3U> &in2,
                             const coder::array<float, 2U> &in3)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      int i2;
      i2 = i1 * stride_0_0;
      in1[i1 + in1.size(0) * i] =
          (in2[i2 + in2.size(0) * aux_0_1] +
           in2[(i2 + in2.size(0) * aux_0_1) + in2.size(0) * in2.size(1)]) -
          in3[i1 * stride_1_0 + in3.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 3U> &in2)
{
  coder::array<float, 2U> b_in2;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in1.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  if (in1.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in1.size(1);
  }
  b_in2.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in1.size(0) != 1);
  stride_1_1 = (in1.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      int in2_tmp;
      in2_tmp = i1 * stride_0_0;
      b_in2[i1 + b_in2.size(0) * i] =
          (in2[(in2_tmp + in2.size(0) * aux_0_1) +
               in2.size(0) * in2.size(1) * 2] +
           in2[(in2_tmp + in2.size(0) * aux_0_1) +
               in2.size(0) * in2.size(1) * 3]) -
          in1[i1 * stride_1_0 + in1.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in2.size(0), b_in2.size(1));
  loop_ub = b_in2.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in2.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in2[i1 + b_in2.size(0) * i];
    }
  }
}

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 2U> &in2,
                             const coder::array<float, 2U> &in3)
{
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in3.size(0) == 1) {
    loop_ub = in2.size(0);
  } else {
    loop_ub = in3.size(0);
  }
  in1.set_size(loop_ub, in1.size(1));
  if (in3.size(1) == 1) {
    b_loop_ub = in2.size(1);
  } else {
    b_loop_ub = in3.size(1);
  }
  in1.set_size(in1.size(0), b_loop_ub);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3.size(0) != 1);
  stride_1_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] =
          in2[i1 * stride_0_0 + in2.size(0) * aux_0_1] +
          in3[i1 * stride_1_0 + in3.size(0) * aux_1_1] * 0.707106769F;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
}

static void binary_expand_op(coder::array<float, 2U> &in1,
                             const coder::array<float, 2U> &in2)
{
  coder::array<float, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] * 0.707106769F +
          in2[i1 * stride_1_0 + in2.size(0) * aux_1_1] * -0.707106769F;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

static void c_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2)
{
  coder::array<float, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  if (in2.size(1) == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = in2.size(1);
  }
  b_in1.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  for (int i{0}; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] * 0.3F +
          in2[i1 * stride_1_0 + in2.size(0) * aux_1_1] * 0.3F;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (int i{0}; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
static void getDerivFilters(cell_wrap_11 filters[12])
{
  static const double idTheta[25]{225.0, 206.565051177078,
                                  180.0, 153.43494882292202,
                                  135.0, 243.43494882292202,
                                  225.0, 180.0,
                                  135.0, 116.56505117707798,
                                  270.0, 270.0,
                                  0.0,   90.0,
                                  90.0,  296.565051177078,
                                  315.0, 0.0,
                                  45.0,  63.434948822922024,
                                  315.0, 333.434948822922,
                                  0.0,   26.565051177077976,
                                  45.0};
  static const short angRange[6]{0, 270, 45, 315, 0, 315};
  static const signed char iv[3]{90, 90, 45};
  std::memset(&filters[0].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[3].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[6].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[9].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[1].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[4].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[7].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[10].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[2].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[5].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[8].f1[0], 0, 25U * sizeof(double));
  std::memset(&filters[11].f1[0], 0, 25U * sizeof(double));
  for (int rangeIdx{0}; rangeIdx < 3; rangeIdx++) {
    double d;
    double rangeComp;
    double thetaCand_idx_2;
    int i;
    int thetaCand_idx_0;
    short b_i;
    short range_idx_0;
    rangeComp = (180.0 - static_cast<double>(iv[rangeIdx])) / 2.0;
    i = rangeIdx << 1;
    b_i = angRange[i];
    range_idx_0 = b_i;
    thetaCand_idx_0 = b_i;
    b_i = angRange[i + 1];
    thetaCand_idx_2 = static_cast<double>(range_idx_0) + 2.0 * rangeComp;
    rangeComp = static_cast<double>(b_i) + -2.0 * rangeComp;
    for (i = 0; i < 25; i++) {
      d = idTheta[i];
      if ((thetaCand_idx_0 > d) || (b_i < d)) {
        filters[rangeIdx].f1[i] = 1.0;
      }
      if ((thetaCand_idx_2 < d) && (rangeComp > d)) {
        filters[rangeIdx].f1[i] = -1.0;
      }
      if ((rangeComp < d) && (b_i > d)) {
        filters[rangeIdx + 3].f1[i] = 1.0;
      }
    }
    filters[rangeIdx].f1[12] = 0.0;
    for (i = 0; i < 25; i++) {
      d = idTheta[i];
      if ((thetaCand_idx_0 < d) && (thetaCand_idx_2 > d)) {
        filters[rangeIdx + 3].f1[i] = -1.0;
      }
      filters[rangeIdx + 6].f1[i] = -filters[rangeIdx].f1[i];
    }
    filters[rangeIdx + 3].f1[12] = 0.0;
    for (i = 0; i < 25; i++) {
      filters[rangeIdx + 9].f1[i] = -filters[rangeIdx + 3].f1[i];
    }
  }
}

} // namespace checkerboard
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder
static void d_binary_expand_op(coder::array<float, 2U> &in1,
                               const coder::array<float, 2U> &in2,
                               const coder::array<float, 2U> &in3)
{
  coder::array<float, 2U> r;
  int aux_0_1;
  int aux_1_1;
  int aux_2_1;
  int b_loop_ub;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  int stride_2_0;
  int stride_2_1;
  if (in3.size(0) == 1) {
    i = in2.size(0);
  } else {
    i = in3.size(0);
  }
  if (i == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = i;
  }
  if (in3.size(1) == 1) {
    i = in2.size(1);
  } else {
    i = in3.size(1);
  }
  if (i == 1) {
    b_loop_ub = in1.size(1);
  } else {
    b_loop_ub = i;
  }
  r.set_size(loop_ub, b_loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  stride_2_0 = (in3.size(0) != 1);
  stride_2_1 = (in3.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  aux_2_1 = 0;
  for (i = 0; i < b_loop_ub; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      r[i1 + r.size(0) * i] =
          16.0F * in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] -
          6.0F * (in2[i1 * stride_1_0 + in2.size(0) * aux_1_1] +
                  in3[i1 * stride_2_0 + in3.size(0) * aux_2_1]);
    }
    aux_2_1 += stride_2_1;
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(r.size(0), r.size(1));
  loop_ub = r.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = r.size(0);
    for (int i1{0}; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = r[i1 + r.size(0) * i];
    }
  }
}

namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
void b_secondDerivCornerMetric(
    const ::coder::array<float, 2U> &b_I, boolean_T highDistortion,
    ::coder::array<float, 2U> &cxy, ::coder::array<float, 2U> &c45,
    ::coder::array<float, 2U> &Ix, ::coder::array<float, 2U> &Iy,
    ::coder::array<float, 2U> &Ixy, ::coder::array<float, 2U> &I_45_45)
{
  array<float, 3U> IfilterDdot;
  array<float, 3U> IfilterDot;
  array<float, 3U> b_IfilterDdot;
  array<float, 3U> x;
  array<float, 2U> Ig;
  array<float, 2U> b_checkerEdge;
  array<float, 2U> c_checkerEdge;
  array<float, 2U> checkerEdgeComp;
  array<float, 2U> checkerboardPeaks;
  int b_loop_ub_tmp;
  int i;
  int i1;
  int loop_ub;
  int loop_ub_tmp;
  int nx;
  unsigned int unnamed_idx_0_tmp;
  unsigned int unnamed_idx_1_tmp;
  Ig.set_size(b_I.size(0), b_I.size(1));
  loop_ub = b_I.size(0) * b_I.size(1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (int checkerEdge{0}; checkerEdge < loop_ub; checkerEdge++) {
      Ig[checkerEdge] = b_I[checkerEdge];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < loop_ub; checkerEdge++) {
      Ig[checkerEdge] = b_I[checkerEdge];
    }
  }
  d_imfilter(Ig);
  Iy.set_size(Ig.size(0), Ig.size(1));
  loop_ub_tmp = Ig.size(0) * Ig.size(1);
  i = (loop_ub_tmp < 3200);
  if (i) {
    for (int checkerEdge{0}; checkerEdge < loop_ub_tmp; checkerEdge++) {
      Iy[checkerEdge] = Ig[checkerEdge];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < loop_ub_tmp; checkerEdge++) {
      Iy[checkerEdge] = Ig[checkerEdge];
    }
  }
  imfilter(Iy);
  Ix.set_size(Ig.size(0), Ig.size(1));
  if (i) {
    for (int checkerEdge{0}; checkerEdge < loop_ub_tmp; checkerEdge++) {
      Ix[checkerEdge] = Ig[checkerEdge];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < loop_ub_tmp; checkerEdge++) {
      Ix[checkerEdge] = Ig[checkerEdge];
    }
  }
  b_imfilter(Ix);
  Ixy.set_size(Ix.size(0), Ix.size(1));
  nx = Ix.size(0) * Ix.size(1);
  i = (nx < 3200);
  if (i) {
    for (int checkerEdge{0}; checkerEdge < nx; checkerEdge++) {
      Ixy[checkerEdge] = Ix[checkerEdge];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < nx; checkerEdge++) {
      Ixy[checkerEdge] = Ix[checkerEdge];
    }
  }
  imfilter(Ixy);
  unnamed_idx_0_tmp = static_cast<unsigned int>(b_I.size(0));
  unnamed_idx_1_tmp = static_cast<unsigned int>(b_I.size(1));
  c45.set_size(b_I.size(0), b_I.size(1));
  b_loop_ub_tmp = b_I.size(0) * b_I.size(1);
  i1 = (b_loop_ub_tmp < 3200);
  if (i1) {
    for (int checkerEdge{0}; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
      c45[checkerEdge] = 0.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
      c45[checkerEdge] = 0.0F;
    }
  }
  I_45_45.set_size(static_cast<int>(unnamed_idx_0_tmp),
                   static_cast<int>(unnamed_idx_1_tmp));
  if (i1) {
    for (int checkerEdge{0}; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
      I_45_45[checkerEdge] = 0.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int checkerEdge = 0; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
      I_45_45[checkerEdge] = 0.0F;
    }
  }
  if (!highDistortion) {
    int b_nx;
    int i2;
    Ig.set_size(Ix.size(0), Ix.size(1));
    if (i) {
      for (int checkerEdge{0}; checkerEdge < nx; checkerEdge++) {
        Ig[checkerEdge] = Ix[checkerEdge] * 0.707106769F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < nx; checkerEdge++) {
        Ig[checkerEdge] = Ix[checkerEdge] * 0.707106769F;
      }
    }
    if ((Ig.size(0) == Iy.size(0)) && (Ig.size(1) == Iy.size(1))) {
      checkerEdgeComp.set_size(Ig.size(0), Ig.size(1));
      if (i) {
        for (int checkerEdge{0}; checkerEdge < nx; checkerEdge++) {
          checkerEdgeComp[checkerEdge] =
              Ig[checkerEdge] + Iy[checkerEdge] * 0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (int checkerEdge = 0; checkerEdge < nx; checkerEdge++) {
          checkerEdgeComp[checkerEdge] =
              Ig[checkerEdge] + Iy[checkerEdge] * 0.707106769F;
        }
      }
    } else {
      binary_expand_op(checkerEdgeComp, Ig, Iy);
    }
    if ((Ig.size(0) == Iy.size(0)) && (Ig.size(1) == Iy.size(1))) {
      loop_ub = Ig.size(0) * Ig.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (int checkerEdge{0}; checkerEdge < loop_ub; checkerEdge++) {
          Ig[checkerEdge] = Ig[checkerEdge] + Iy[checkerEdge] * -0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (int checkerEdge = 0; checkerEdge < loop_ub; checkerEdge++) {
          Ig[checkerEdge] = Ig[checkerEdge] + Iy[checkerEdge] * -0.707106769F;
        }
      }
    } else {
      b_binary_expand_op(Ig, Iy);
    }
    I_45_45.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
    b_nx = checkerEdgeComp.size(0) * checkerEdgeComp.size(1);
    i1 = (b_nx < 3200);
    if (i1) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        I_45_45[checkerEdge] = checkerEdgeComp[checkerEdge];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        I_45_45[checkerEdge] = checkerEdgeComp[checkerEdge];
      }
    }
    b_imfilter(I_45_45);
    b_checkerEdge.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
    if (i1) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = checkerEdgeComp[checkerEdge];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = checkerEdgeComp[checkerEdge];
      }
    }
    imfilter(b_checkerEdge);
    if ((I_45_45.size(0) == b_checkerEdge.size(0)) &&
        (I_45_45.size(1) == b_checkerEdge.size(1))) {
      loop_ub = I_45_45.size(0) * I_45_45.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (int checkerEdge{0}; checkerEdge < loop_ub; checkerEdge++) {
          I_45_45[checkerEdge] = I_45_45[checkerEdge] * 0.707106769F +
                                 b_checkerEdge[checkerEdge] * -0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (int checkerEdge = 0; checkerEdge < loop_ub; checkerEdge++) {
          I_45_45[checkerEdge] = I_45_45[checkerEdge] * 0.707106769F +
                                 b_checkerEdge[checkerEdge] * -0.707106769F;
        }
      }
    } else {
      binary_expand_op(I_45_45, b_checkerEdge);
    }
    b_checkerEdge.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
    if (i1) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = std::abs(checkerEdgeComp[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = std::abs(checkerEdgeComp[checkerEdge]);
      }
    }
    b_nx = Ig.size(0) * Ig.size(1);
    checkerEdgeComp.set_size(Ig.size(0), Ig.size(1));
    if (static_cast<int>(b_nx < 3200)) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        checkerEdgeComp[checkerEdge] = std::abs(Ig[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        checkerEdgeComp[checkerEdge] = std::abs(Ig[checkerEdge]);
      }
    }
    b_nx = Ixy.size(0) * Ixy.size(1);
    cxy.set_size(Ixy.size(0), Ixy.size(1));
    if (static_cast<int>(b_nx < 3200)) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        cxy[checkerEdge] = std::abs(Ixy[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        cxy[checkerEdge] = std::abs(Ixy[checkerEdge]);
      }
    }
    if (b_checkerEdge.size(0) == 1) {
      i1 = checkerEdgeComp.size(0);
    } else {
      i1 = b_checkerEdge.size(0);
    }
    if (b_checkerEdge.size(1) == 1) {
      i2 = checkerEdgeComp.size(1);
    } else {
      i2 = b_checkerEdge.size(1);
    }
    if ((b_checkerEdge.size(0) == checkerEdgeComp.size(0)) &&
        (b_checkerEdge.size(1) == checkerEdgeComp.size(1)) &&
        (cxy.size(0) == i1) && (cxy.size(1) == i2)) {
      loop_ub = cxy.size(0) * cxy.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (int checkerEdge{0}; checkerEdge < loop_ub; checkerEdge++) {
          cxy[checkerEdge] =
              16.0F * cxy[checkerEdge] - 6.0F * (b_checkerEdge[checkerEdge] +
                                                 checkerEdgeComp[checkerEdge]);
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (int checkerEdge = 0; checkerEdge < loop_ub; checkerEdge++) {
          cxy[checkerEdge] =
              16.0F * cxy[checkerEdge] - 6.0F * (b_checkerEdge[checkerEdge] +
                                                 checkerEdgeComp[checkerEdge]);
        }
      }
    } else {
      d_binary_expand_op(cxy, b_checkerEdge, checkerEdgeComp);
    }
    b_loop_ub_tmp = cxy.size(0) * cxy.size(1);
    loop_ub = b_loop_ub_tmp - 1;
    if (static_cast<int>(b_loop_ub_tmp < 3200)) {
      for (int checkerEdge{0}; checkerEdge <= loop_ub; checkerEdge++) {
        if (cxy[checkerEdge] < 0.0F) {
          cxy[checkerEdge] = 0.0F;
        }
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge <= loop_ub; checkerEdge++) {
        if (cxy[checkerEdge] < 0.0F) {
          cxy[checkerEdge] = 0.0F;
        }
      }
    }
    b_checkerEdge.set_size(Ix.size(0), Ix.size(1));
    if (i) {
      for (int checkerEdge{0}; checkerEdge < nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = std::abs(Ix[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < nx; checkerEdge++) {
        b_checkerEdge[checkerEdge] = std::abs(Ix[checkerEdge]);
      }
    }
    b_nx = Iy.size(0) * Iy.size(1);
    checkerEdgeComp.set_size(Iy.size(0), Iy.size(1));
    if (static_cast<int>(b_nx < 3200)) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        checkerEdgeComp[checkerEdge] = std::abs(Iy[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        checkerEdgeComp[checkerEdge] = std::abs(Iy[checkerEdge]);
      }
    }
    b_nx = I_45_45.size(0) * I_45_45.size(1);
    c45.set_size(I_45_45.size(0), I_45_45.size(1));
    if (static_cast<int>(b_nx < 3200)) {
      for (int checkerEdge{0}; checkerEdge < b_nx; checkerEdge++) {
        c45[checkerEdge] = std::abs(I_45_45[checkerEdge]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_nx; checkerEdge++) {
        c45[checkerEdge] = std::abs(I_45_45[checkerEdge]);
      }
    }
    if (b_checkerEdge.size(0) == 1) {
      i = checkerEdgeComp.size(0);
    } else {
      i = b_checkerEdge.size(0);
    }
    if (b_checkerEdge.size(1) == 1) {
      i1 = checkerEdgeComp.size(1);
    } else {
      i1 = b_checkerEdge.size(1);
    }
    if ((b_checkerEdge.size(0) == checkerEdgeComp.size(0)) &&
        (b_checkerEdge.size(1) == checkerEdgeComp.size(1)) &&
        (c45.size(0) == i) && (c45.size(1) == i1)) {
      loop_ub = c45.size(0) * c45.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (int checkerEdge{0}; checkerEdge < loop_ub; checkerEdge++) {
          c45[checkerEdge] =
              16.0F * c45[checkerEdge] - 6.0F * (b_checkerEdge[checkerEdge] +
                                                 checkerEdgeComp[checkerEdge]);
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (int checkerEdge = 0; checkerEdge < loop_ub; checkerEdge++) {
          c45[checkerEdge] =
              16.0F * c45[checkerEdge] - 6.0F * (b_checkerEdge[checkerEdge] +
                                                 checkerEdgeComp[checkerEdge]);
        }
      }
    } else {
      d_binary_expand_op(c45, b_checkerEdge, checkerEdgeComp);
    }
    b_loop_ub_tmp = c45.size(0) * c45.size(1);
    loop_ub = b_loop_ub_tmp - 1;
    if (static_cast<int>(b_loop_ub_tmp < 3200)) {
      for (int checkerEdge{0}; checkerEdge <= loop_ub; checkerEdge++) {
        if (c45[checkerEdge] < 0.0F) {
          c45[checkerEdge] = 0.0F;
        }
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge <= loop_ub; checkerEdge++) {
        if (c45[checkerEdge] < 0.0F) {
          c45[checkerEdge] = 0.0F;
        }
      }
    }
  } else {
    cell_wrap_11 derivFilters[12];
    int b_nx;
    getDerivFilters(derivFilters);
    checkerboardPeaks.set_size(static_cast<int>(unnamed_idx_0_tmp),
                               static_cast<int>(unnamed_idx_1_tmp));
    if (i1) {
      for (int checkerEdge{0}; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        checkerboardPeaks[checkerEdge] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        checkerboardPeaks[checkerEdge] = 0.0F;
      }
    }
    IfilterDot.set_size(Ig.size(0), Ig.size(1), 4);
    b_loop_ub_tmp = loop_ub_tmp << 2;
    i = (b_loop_ub_tmp < 3200);
    if (i) {
      for (int checkerEdge{0}; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        IfilterDot[checkerEdge] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        IfilterDot[checkerEdge] = 0.0F;
      }
    }
    IfilterDdot.set_size(Ig.size(0), Ig.size(1), 4);
    if (i) {
      for (int checkerEdge{0}; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        IfilterDdot[checkerEdge] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int checkerEdge = 0; checkerEdge < b_loop_ub_tmp; checkerEdge++) {
        IfilterDdot[checkerEdge] = 0.0F;
      }
    }
    b_nx = Iy.size(0) * Iy.size(1);
    for (int filtIdx{0}; filtIdx < 3; filtIdx++) {
      float varargin_1;
      b_checkerEdge.set_size(Ig.size(0), Ig.size(1));
      for (i = 0; i < loop_ub_tmp; i++) {
        b_checkerEdge[i] = Ig[i];
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDot[i1 + IfilterDot.size(0) * i] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      b_checkerEdge.set_size(Ig.size(0), Ig.size(1));
      for (i = 0; i < loop_ub_tmp; i++) {
        b_checkerEdge[i] = Ig[i];
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 3].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDot[(i1 + IfilterDot.size(0) * i) +
                     IfilterDot.size(0) * IfilterDot.size(1)] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      b_checkerEdge.set_size(Ig.size(0), Ig.size(1));
      for (i = 0; i < loop_ub_tmp; i++) {
        b_checkerEdge[i] = Ig[i];
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 6].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDot[(i1 + IfilterDot.size(0) * i) +
                     IfilterDot.size(0) * IfilterDot.size(1) * 2] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      b_checkerEdge.set_size(Ig.size(0), Ig.size(1));
      for (i = 0; i < loop_ub_tmp; i++) {
        b_checkerEdge[i] = Ig[i];
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 9].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDot[(i1 + IfilterDot.size(0) * i) +
                     IfilterDot.size(0) * IfilterDot.size(1) * 3] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      loop_ub = IfilterDot.size(1);
      b_checkerEdge.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = IfilterDot.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          b_checkerEdge[i1 + b_checkerEdge.size(0) * i] =
              IfilterDot[i1 + IfilterDot.size(0) * i];
        }
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDdot[i1 + IfilterDdot.size(0) * i] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      loop_ub = IfilterDot.size(1);
      b_checkerEdge.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = IfilterDot.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          b_checkerEdge[i1 + b_checkerEdge.size(0) * i] =
              IfilterDot[(i1 + IfilterDot.size(0) * i) +
                         IfilterDot.size(0) * IfilterDot.size(1)];
        }
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 3].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1)] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      loop_ub = IfilterDot.size(1);
      b_checkerEdge.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = IfilterDot.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          b_checkerEdge[i1 + b_checkerEdge.size(0) * i] =
              IfilterDot[i1 + IfilterDot.size(0) * i];
        }
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 6].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1) * 2] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      loop_ub = IfilterDot.size(1);
      b_checkerEdge.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = IfilterDot.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          b_checkerEdge[i1 + b_checkerEdge.size(0) * i] =
              IfilterDot[(i1 + IfilterDot.size(0) * i) +
                         IfilterDot.size(0) * IfilterDot.size(1)];
        }
      }
      imfilter(b_checkerEdge, derivFilters[filtIdx + 9].f1);
      loop_ub = b_checkerEdge.size(1);
      for (i = 0; i < loop_ub; i++) {
        b_loop_ub_tmp = b_checkerEdge.size(0);
        for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
          IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1) * 3] =
              b_checkerEdge[i1 + b_checkerEdge.size(0) * i];
        }
      }
      checkerEdgeComp.set_size(Ix.size(0), Ix.size(1));
      for (b_loop_ub_tmp = 0; b_loop_ub_tmp < nx; b_loop_ub_tmp++) {
        checkerEdgeComp[b_loop_ub_tmp] = std::abs(Ix[b_loop_ub_tmp]);
      }
      b_checkerEdge.set_size(Iy.size(0), Iy.size(1));
      for (b_loop_ub_tmp = 0; b_loop_ub_tmp < b_nx; b_loop_ub_tmp++) {
        b_checkerEdge[b_loop_ub_tmp] = std::abs(Iy[b_loop_ub_tmp]);
      }
      if ((checkerEdgeComp.size(0) == b_checkerEdge.size(0)) &&
          (checkerEdgeComp.size(1) == b_checkerEdge.size(1))) {
        loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1);
        for (i = 0; i < loop_ub; i++) {
          checkerEdgeComp[i] =
              checkerEdgeComp[i] * 0.3F + b_checkerEdge[i] * 0.3F;
        }
      } else {
        c_binary_expand_op(checkerEdgeComp, b_checkerEdge);
      }
      loop_ub = IfilterDdot.size(1);
      if ((IfilterDdot.size(0) == checkerEdgeComp.size(0)) &&
          (IfilterDdot.size(1) == checkerEdgeComp.size(1))) {
        b_checkerEdge.set_size(IfilterDdot.size(0), IfilterDdot.size(1));
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub_tmp = IfilterDdot.size(0);
          for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
            b_checkerEdge[i1 + b_checkerEdge.size(0) * i] =
                (IfilterDdot[i1 + IfilterDdot.size(0) * i] +
                 IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1)]) -
                checkerEdgeComp[i1 + checkerEdgeComp.size(0) * i];
          }
        }
      } else {
        binary_expand_op(b_checkerEdge, IfilterDdot, checkerEdgeComp);
      }
      loop_ub = IfilterDdot.size(1);
      if ((IfilterDdot.size(0) == checkerEdgeComp.size(0)) &&
          (IfilterDdot.size(1) == checkerEdgeComp.size(1))) {
        checkerEdgeComp.set_size(IfilterDdot.size(0), IfilterDdot.size(1));
        for (i = 0; i < loop_ub; i++) {
          b_loop_ub_tmp = IfilterDdot.size(0);
          for (i1 = 0; i1 < b_loop_ub_tmp; i1++) {
            checkerEdgeComp[i1 + checkerEdgeComp.size(0) * i] =
                (IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1) * 2] +
                 IfilterDdot[(i1 + IfilterDdot.size(0) * i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1) * 3]) -
                checkerEdgeComp[i1 + checkerEdgeComp.size(0) * i];
          }
        }
      } else {
        binary_expand_op(checkerEdgeComp, IfilterDdot);
      }
      loop_ub = b_checkerEdge.size(0) * b_checkerEdge.size(1) - 1;
      for (b_loop_ub_tmp = 0; b_loop_ub_tmp <= loop_ub; b_loop_ub_tmp++) {
        if (b_checkerEdge[b_loop_ub_tmp] < 0.0F) {
          b_checkerEdge[b_loop_ub_tmp] = 0.0F;
        }
      }
      loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1) - 1;
      for (b_loop_ub_tmp = 0; b_loop_ub_tmp <= loop_ub; b_loop_ub_tmp++) {
        if (checkerEdgeComp[b_loop_ub_tmp] < 0.0F) {
          checkerEdgeComp[b_loop_ub_tmp] = 0.0F;
        }
      }
      c_checkerEdge.set_size(b_checkerEdge.size(0), b_checkerEdge.size(1));
      loop_ub = b_checkerEdge.size(0) * b_checkerEdge.size(1) - 1;
      for (i = 0; i <= loop_ub; i++) {
        c_checkerEdge[i] = b_checkerEdge[i];
      }
      imdilate(c_checkerEdge, b_checkerEdge);
      c_checkerEdge.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
      loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1) - 1;
      for (i = 0; i <= loop_ub; i++) {
        c_checkerEdge[i] = checkerEdgeComp[i];
      }
      imdilate(c_checkerEdge, checkerEdgeComp);
      loop_ub = IfilterDdot.size(1);
      b_IfilterDdot.set_size(IfilterDdot.size(0), IfilterDdot.size(1), 2);
      for (i = 0; i < 2; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_loop_ub_tmp = IfilterDdot.size(0);
          for (int i2{0}; i2 < b_loop_ub_tmp; i2++) {
            b_IfilterDdot[(i2 + b_IfilterDdot.size(0) * i1) +
                          b_IfilterDdot.size(0) * b_IfilterDdot.size(1) * i] =
                IfilterDdot[(i2 + IfilterDdot.size(0) * i1) +
                            IfilterDdot.size(0) * IfilterDdot.size(1) * i];
          }
        }
      }
      bsxfun(b_IfilterDdot, b_checkerEdge, x);
      b_loop_ub_tmp = x.size(0) * x.size(1);
      loop_ub = b_loop_ub_tmp << 1;
      x.set_size(x.size(0), x.size(1), 2);
      for (i = 0; i < loop_ub; i++) {
        varargin_1 = x[i];
        x[i] = std::fmax(varargin_1, 0.0F);
      }
      if ((x.size(0) == 0) || (x.size(1) == 0)) {
        b_checkerEdge.set_size(x.size(0), x.size(1));
        loop_ub = x.size(0) * x.size(1);
        for (i = 0; i < loop_ub; i++) {
          b_checkerEdge[i] = 0.0F;
        }
      } else {
        b_checkerEdge.set_size(x.size(0), x.size(1));
        for (loop_ub = 0; loop_ub < b_loop_ub_tmp; loop_ub++) {
          b_checkerEdge[loop_ub] = x[loop_ub];
        }
        for (loop_ub = 0; loop_ub < b_loop_ub_tmp; loop_ub++) {
          b_checkerEdge[loop_ub] =
              b_checkerEdge[loop_ub] + x[b_loop_ub_tmp + loop_ub];
        }
      }
      loop_ub = IfilterDdot.size(1);
      b_IfilterDdot.set_size(IfilterDdot.size(0), IfilterDdot.size(1), 2);
      for (i = 0; i < 2; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_loop_ub_tmp = IfilterDdot.size(0);
          for (int i2{0}; i2 < b_loop_ub_tmp; i2++) {
            b_IfilterDdot[(i2 + b_IfilterDdot.size(0) * i1) +
                          b_IfilterDdot.size(0) * b_IfilterDdot.size(1) * i] =
                IfilterDdot[(i2 + IfilterDdot.size(0) * i1) +
                            IfilterDdot.size(0) * IfilterDdot.size(1) *
                                (i + 2)];
          }
        }
      }
      bsxfun(b_IfilterDdot, checkerEdgeComp, x);
      b_loop_ub_tmp = x.size(0) * x.size(1);
      loop_ub = b_loop_ub_tmp << 1;
      x.set_size(x.size(0), x.size(1), 2);
      for (i = 0; i < loop_ub; i++) {
        varargin_1 = x[i];
        x[i] = std::fmax(varargin_1, 0.0F);
      }
      if ((x.size(0) == 0) || (x.size(1) == 0)) {
        checkerEdgeComp.set_size(x.size(0), x.size(1));
        loop_ub = x.size(0) * x.size(1);
        for (i = 0; i < loop_ub; i++) {
          checkerEdgeComp[i] = 0.0F;
        }
      } else {
        checkerEdgeComp.set_size(x.size(0), x.size(1));
        for (loop_ub = 0; loop_ub < b_loop_ub_tmp; loop_ub++) {
          checkerEdgeComp[loop_ub] = x[loop_ub];
        }
        for (loop_ub = 0; loop_ub < b_loop_ub_tmp; loop_ub++) {
          checkerEdgeComp[loop_ub] =
              checkerEdgeComp[loop_ub] + x[b_loop_ub_tmp + loop_ub];
        }
      }
      if (checkerboardPeaks.size(0) == 1) {
        i = b_checkerEdge.size(0);
      } else {
        i = checkerboardPeaks.size(0);
      }
      if (checkerboardPeaks.size(1) == 1) {
        i1 = b_checkerEdge.size(1);
      } else {
        i1 = checkerboardPeaks.size(1);
      }
      if ((checkerboardPeaks.size(0) == b_checkerEdge.size(0)) &&
          (checkerboardPeaks.size(1) == b_checkerEdge.size(1)) &&
          (i == checkerEdgeComp.size(0)) && (i1 == checkerEdgeComp.size(1))) {
        loop_ub = checkerboardPeaks.size(0) * checkerboardPeaks.size(1);
        for (i = 0; i < loop_ub; i++) {
          checkerboardPeaks[i] =
              (checkerboardPeaks[i] + b_checkerEdge[i]) + checkerEdgeComp[i];
        }
      } else {
        b_binary_expand_op(checkerboardPeaks, b_checkerEdge, checkerEdgeComp);
      }
    }
    imerode(checkerboardPeaks, cxy);
  }
}

void secondDerivCornerMetric(const ::coder::array<float, 2U> &b_I, double sigma,
                             boolean_T highDistortion,
                             ::coder::array<float, 2U> &cxy,
                             ::coder::array<float, 2U> &c45,
                             ::coder::array<float, 2U> &Ix,
                             ::coder::array<float, 2U> &Iy,
                             ::coder::array<float, 2U> &Ixy,
                             ::coder::array<float, 2U> &I_45_45)
{
  array<double, 2U> b_y;
  array<double, 2U> y;
  array<double, 1U> b_G_data;
  array<double, 1U> c_G_data;
  array<float, 3U> IfilterDdot;
  array<float, 3U> IfilterDot;
  array<float, 3U> b_IfilterDdot;
  array<float, 3U> x;
  array<float, 2U> I_45;
  array<float, 2U> Ig;
  array<float, 2U> a;
  array<float, 2U> checkerEdgeComp;
  array<float, 2U> checkerboardPeaks;
  array<float, 2U> r;
  cell_wrap_11 derivFilters[12];
  double G_data[225];
  double nonzero_h_data[225];
  double y_data[225];
  double connDimsT[2];
  double outSizeT[2];
  double padSizeT[2];
  double siz[2];
  double a_tmp;
  double sumh;
  float varargin_1;
  int G_size[2];
  int y_size[2];
  int b_i;
  int b_nx;
  int b_outSizeT_tmp;
  int conn_size_idx_0;
  int end;
  int end_tmp_tmp;
  int i;
  int j;
  int loop_ub;
  int nx;
  int ny;
  int outSizeT_tmp;
  int trueCount;
  int trueCountPrime;
  boolean_T conn_data[225];
  boolean_T tooBig;
  sumh = ((std::round(sigma * 7.0) + 1.0) - 1.0) / 2.0;
  siz[0] = sumh;
  tooBig = std::isnan(-sumh);
  if (tooBig || std::isnan(sumh)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (sumh < -sumh) {
    y.set_size(1, 0);
  } else if ((std::isinf(-sumh) || std::isinf(sumh)) && (-sumh == sumh)) {
    y.set_size(1, 1);
    y[0] = rtNaN;
  } else if (std::floor(-sumh) == -sumh) {
    a_tmp = -sumh;
    loop_ub = static_cast<int>(sumh - (-sumh));
    y.set_size(1, loop_ub + 1);
    if (static_cast<int>(loop_ub + 1 < 3200)) {
      for (j = 0; j <= loop_ub; j++) {
        y[j] = -sumh + static_cast<double>(j);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j <= loop_ub; j++) {
        y[j] = a_tmp + static_cast<double>(j);
      }
    }
  } else {
    eml_float_colon(-sumh, sumh, y);
  }
  if (tooBig || std::isnan(siz[0])) {
    b_y.set_size(1, 1);
    b_y[0] = rtNaN;
  } else if (siz[0] < -siz[0]) {
    b_y.set_size(1, 0);
  } else if ((std::isinf(-siz[0]) || std::isinf(siz[0])) &&
             (-siz[0] == siz[0])) {
    b_y.set_size(1, 1);
    b_y[0] = rtNaN;
  } else if (std::floor(-siz[0]) == -siz[0]) {
    a_tmp = -siz[0];
    loop_ub = static_cast<int>(siz[0] - (-siz[0]));
    b_y.set_size(1, loop_ub + 1);
    if (static_cast<int>(loop_ub + 1 < 3200)) {
      for (j = 0; j <= loop_ub; j++) {
        b_y[j] = a_tmp + static_cast<double>(j);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j <= loop_ub; j++) {
        b_y[j] = a_tmp + static_cast<double>(j);
      }
    }
  } else {
    eml_float_colon(-siz[0], siz[0], b_y);
  }
  nx = y.size(1);
  ny = b_y.size(1);
  G_size[0] = b_y.size(1);
  G_size[1] = y.size(1);
  y_size[0] = b_y.size(1);
  y_size[1] = y.size(1);
  loop_ub = y.size(1) * b_y.size(1);
  if (static_cast<int>(loop_ub < 3200)) {
    for (j = 0; j < nx; j++) {
      for (i = 0; i < ny; i++) {
        G_data[i + G_size[0] * j] = y[j];
        y_data[i + y_size[0] * j] = b_y[i];
      }
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(i)

    for (j = 0; j < nx; j++) {
      for (i = 0; i < ny; i++) {
        G_data[i + G_size[0] * j] = y[j];
        y_data[i + y_size[0] * j] = b_y[i];
      }
    }
  }
  if ((G_size[0] == y_size[0]) && (G_size[1] == y_size[1])) {
    a_tmp = 2.0 * sigma * sigma;
    for (b_i = 0; b_i < loop_ub; b_i++) {
      sumh = y_data[b_i];
      G_data[b_i] = -(G_data[b_i] * G_data[b_i] + sumh * sumh) / a_tmp;
    }
  } else {
    binary_expand_op(G_data, G_size, y_data, y_size, sigma);
  }
  loop_ub = G_size[0] * G_size[1];
  for (ny = 0; ny < loop_ub; ny++) {
    G_data[ny] = std::exp(G_data[ny]);
  }
  b_G_data.set(&G_data[0], loop_ub);
  sumh = ::coder::internal::maximum(b_G_data);
  end_tmp_tmp = loop_ub - 1;
  for (b_i = 0; b_i <= end_tmp_tmp; b_i++) {
    if (G_data[b_i] < 2.2204460492503131E-16 * sumh) {
      G_data[b_i] = 0.0;
    }
  }
  c_G_data.set(&G_data[0], loop_ub);
  sumh = combineVectorElements(c_G_data);
  if (sumh != 0.0) {
    for (b_i = 0; b_i < loop_ub; b_i++) {
      G_data[b_i] /= sumh;
    }
  }
  outSizeT_tmp = b_I.size(0);
  outSizeT[0] = b_I.size(0);
  siz[0] = static_cast<double>(G_size[0]) -
           std::floor((static_cast<double>(G_size[0]) + 1.0) / 2.0);
  b_outSizeT_tmp = b_I.size(1);
  outSizeT[1] = b_I.size(1);
  siz[1] = static_cast<double>(G_size[1]) -
           std::floor((static_cast<double>(G_size[1]) + 1.0) / 2.0);
  if ((b_I.size(0) == 0) || (b_I.size(1) == 0)) {
    Ig.set_size(b_I.size(0), b_I.size(1));
    loop_ub = b_I.size(0) * b_I.size(1);
    if (static_cast<int>(loop_ub < 3200)) {
      for (j = 0; j < loop_ub; j++) {
        Ig[j] = b_I[j];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < loop_ub; j++) {
        Ig[j] = b_I[j];
      }
    }
  } else if ((G_size[0] == 0) || (G_size[1] == 0)) {
    Ig.set_size(b_I.size(0), b_I.size(1));
    loop_ub = b_I.size(0) * b_I.size(1);
    if (static_cast<int>(loop_ub < 3200)) {
      for (j = 0; j < loop_ub; j++) {
        Ig[j] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < loop_ub; j++) {
        Ig[j] = 0.0F;
      }
    }
  } else {
    padImage(b_I, siz, a);
    conn_size_idx_0 = G_size[0];
    nx = G_size[1];
    for (b_i = 0; b_i < loop_ub; b_i++) {
      conn_data[b_i] = (G_data[b_i] != 0.0);
    }
    if ((G_size[0] == 1) || (G_size[1] == 1)) {
      end = loop_ub - 1;
      trueCount = 0;
      if (static_cast<int>(loop_ub < 3200)) {
        for (i = 0; i <= end_tmp_tmp; i++) {
          if (conn_data[i]) {
            trueCount++;
          }
        }
      } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
        {
          trueCountPrime = 0;
#pragma omp for nowait
          for (i = 0; i <= end; i++) {
            if (conn_data[i]) {
              trueCountPrime++;
            }
          }
          omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
          {

            trueCount = trueCountPrime;
          }
          omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
        }
      }
      ny = 0;
      for (b_i = 0; b_i <= end; b_i++) {
        if (conn_data[b_i]) {
          nonzero_h_data[ny] = G_data[b_i];
          ny++;
        }
      }
    } else {
      trueCount = 0;
      for (b_i = 0; b_i <= end_tmp_tmp; b_i++) {
        if (conn_data[b_i]) {
          trueCount++;
        }
      }
      ny = 0;
      for (b_i = 0; b_i <= end_tmp_tmp; b_i++) {
        if (conn_data[b_i]) {
          nonzero_h_data[ny] = G_data[b_i];
          ny++;
        }
      }
    }
    tooBig = true;
    b_i = static_cast<int>(outSizeT[0]);
    if ((b_i <= 65500) || (!(outSizeT[1] > 65500.0))) {
      tooBig = false;
    }
    if ((static_cast<double>(trueCount) / static_cast<double>(loop_ub) >
         0.05) &&
        (!tooBig)) {
      tooBig = true;
    } else {
      tooBig = false;
    }
    Ig.set_size(b_i, static_cast<int>(outSizeT[1]));
    if (tooBig) {
      padSizeT[0] = a.size(0);
      siz[0] = G_size[0];
      padSizeT[1] = a.size(1);
      siz[1] = G_size[1];
      ippfilter_real32(&a[0], &Ig[0], &outSizeT[0], 2.0, &padSizeT[0],
                       &G_data[0], &siz[0], true);
    } else {
      padSizeT[0] = a.size(0);
      connDimsT[0] = conn_size_idx_0;
      padSizeT[1] = a.size(1);
      connDimsT[1] = nx;
      imfilter_real32(&a[0], &Ig[0], 2.0, &outSizeT[0], 2.0, &padSizeT[0],
                      &nonzero_h_data[0], static_cast<double>(trueCount),
                      &conn_data[0], 2.0, &connDimsT[0], &siz[0], 2.0, true,
                      true);
    }
  }
  Iy.set_size(Ig.size(0), Ig.size(1));
  conn_size_idx_0 = Ig.size(0) * Ig.size(1);
  b_i = (conn_size_idx_0 < 3200);
  if (b_i) {
    for (j = 0; j < conn_size_idx_0; j++) {
      Iy[j] = Ig[j];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (j = 0; j < conn_size_idx_0; j++) {
      Iy[j] = Ig[j];
    }
  }
  imfilter(Iy);
  Ix.set_size(Ig.size(0), Ig.size(1));
  if (b_i) {
    for (j = 0; j < conn_size_idx_0; j++) {
      Ix[j] = Ig[j];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (j = 0; j < conn_size_idx_0; j++) {
      Ix[j] = Ig[j];
    }
  }
  b_imfilter(Ix);
  Ixy.set_size(Ix.size(0), Ix.size(1));
  b_nx = Ix.size(0) * Ix.size(1);
  b_i = (b_nx < 3200);
  if (b_i) {
    for (j = 0; j < b_nx; j++) {
      Ixy[j] = Ix[j];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (j = 0; j < b_nx; j++) {
      Ixy[j] = Ix[j];
    }
  }
  imfilter(Ixy);
  c45.set_size(outSizeT_tmp, b_outSizeT_tmp);
  ny = outSizeT_tmp * b_outSizeT_tmp;
  trueCount = (ny < 3200);
  if (trueCount) {
    for (j = 0; j < ny; j++) {
      c45[j] = 0.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (j = 0; j < ny; j++) {
      c45[j] = 0.0F;
    }
  }
  I_45_45.set_size(outSizeT_tmp, b_outSizeT_tmp);
  if (trueCount) {
    for (j = 0; j < ny; j++) {
      I_45_45[j] = 0.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (j = 0; j < ny; j++) {
      I_45_45[j] = 0.0F;
    }
  }
  if (!highDistortion) {
    checkerEdgeComp.set_size(Ix.size(0), Ix.size(1));
    if (b_i) {
      for (j = 0; j < b_nx; j++) {
        checkerEdgeComp[j] = Ix[j] * 0.707106769F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < b_nx; j++) {
        checkerEdgeComp[j] = Ix[j] * 0.707106769F;
      }
    }
    if ((checkerEdgeComp.size(0) == Iy.size(0)) &&
        (checkerEdgeComp.size(1) == Iy.size(1))) {
      I_45.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
      if (b_i) {
        for (j = 0; j < b_nx; j++) {
          I_45[j] = checkerEdgeComp[j] + Iy[j] * 0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (j = 0; j < b_nx; j++) {
          I_45[j] = checkerEdgeComp[j] + Iy[j] * 0.707106769F;
        }
      }
    } else {
      binary_expand_op(I_45, checkerEdgeComp, Iy);
    }
    if ((checkerEdgeComp.size(0) == Iy.size(0)) &&
        (checkerEdgeComp.size(1) == Iy.size(1))) {
      loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (j = 0; j < loop_ub; j++) {
          checkerEdgeComp[j] = checkerEdgeComp[j] + Iy[j] * -0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (j = 0; j < loop_ub; j++) {
          checkerEdgeComp[j] = checkerEdgeComp[j] + Iy[j] * -0.707106769F;
        }
      }
    } else {
      b_binary_expand_op(checkerEdgeComp, Iy);
    }
    I_45_45.set_size(I_45.size(0), I_45.size(1));
    nx = I_45.size(0) * I_45.size(1);
    trueCount = (nx < 3200);
    if (trueCount) {
      for (j = 0; j < nx; j++) {
        I_45_45[j] = I_45[j];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        I_45_45[j] = I_45[j];
      }
    }
    b_imfilter(I_45_45);
    a.set_size(I_45.size(0), I_45.size(1));
    if (trueCount) {
      for (j = 0; j < nx; j++) {
        a[j] = I_45[j];
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        a[j] = I_45[j];
      }
    }
    imfilter(a);
    if ((I_45_45.size(0) == a.size(0)) && (I_45_45.size(1) == a.size(1))) {
      loop_ub = I_45_45.size(0) * I_45_45.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (j = 0; j < loop_ub; j++) {
          I_45_45[j] = I_45_45[j] * 0.707106769F + a[j] * -0.707106769F;
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (j = 0; j < loop_ub; j++) {
          I_45_45[j] = I_45_45[j] * 0.707106769F + a[j] * -0.707106769F;
        }
      }
    } else {
      binary_expand_op(I_45_45, a);
    }
    r.set_size(I_45.size(0), I_45.size(1));
    if (trueCount) {
      for (j = 0; j < nx; j++) {
        r[j] = std::abs(I_45[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        r[j] = std::abs(I_45[j]);
      }
    }
    nx = checkerEdgeComp.size(0) * checkerEdgeComp.size(1);
    a.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
    if (static_cast<int>(nx < 3200)) {
      for (j = 0; j < nx; j++) {
        a[j] = std::abs(checkerEdgeComp[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        a[j] = std::abs(checkerEdgeComp[j]);
      }
    }
    sumh = sigma * sigma;
    nx = Ixy.size(0) * Ixy.size(1);
    cxy.set_size(Ixy.size(0), Ixy.size(1));
    if (static_cast<int>(nx < 3200)) {
      for (j = 0; j < nx; j++) {
        cxy[j] = std::abs(Ixy[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        cxy[j] = std::abs(Ixy[j]);
      }
    }
    a_tmp = 1.5 * sigma;
    if (r.size(0) == 1) {
      end = a.size(0);
    } else {
      end = r.size(0);
    }
    if (r.size(1) == 1) {
      loop_ub = a.size(1);
    } else {
      loop_ub = r.size(1);
    }
    if ((r.size(0) == a.size(0)) && (r.size(1) == a.size(1)) &&
        (cxy.size(0) == end) && (cxy.size(1) == loop_ub)) {
      loop_ub = cxy.size(0) * cxy.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (j = 0; j < loop_ub; j++) {
          cxy[j] = static_cast<float>(sumh) * cxy[j] -
                   static_cast<float>(a_tmp) * (r[j] + a[j]);
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (j = 0; j < loop_ub; j++) {
          cxy[j] = static_cast<float>(sumh) * cxy[j] -
                   static_cast<float>(a_tmp) * (r[j] + a[j]);
        }
      }
    } else {
      binary_expand_op(cxy, sumh, a_tmp, r, a);
    }
    ny = cxy.size(0) * cxy.size(1);
    end = ny - 1;
    if (static_cast<int>(ny < 3200)) {
      for (i = 0; i <= end; i++) {
        if (cxy[i] < 0.0F) {
          cxy[i] = 0.0F;
        }
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(j)

      for (i = 0; i <= end; i++) {
        if (cxy[i] < 0.0F) {
          cxy[i] = 0.0F;
        }
      }
    }
    r.set_size(Ix.size(0), Ix.size(1));
    if (b_i) {
      for (j = 0; j < b_nx; j++) {
        r[j] = std::abs(Ix[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < b_nx; j++) {
        r[j] = std::abs(Ix[j]);
      }
    }
    nx = Iy.size(0) * Iy.size(1);
    a.set_size(Iy.size(0), Iy.size(1));
    if (static_cast<int>(nx < 3200)) {
      for (j = 0; j < nx; j++) {
        a[j] = std::abs(Iy[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        a[j] = std::abs(Iy[j]);
      }
    }
    nx = I_45_45.size(0) * I_45_45.size(1);
    c45.set_size(I_45_45.size(0), I_45_45.size(1));
    if (static_cast<int>(nx < 3200)) {
      for (j = 0; j < nx; j++) {
        c45[j] = std::abs(I_45_45[j]);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < nx; j++) {
        c45[j] = std::abs(I_45_45[j]);
      }
    }
    if (r.size(0) == 1) {
      end = a.size(0);
    } else {
      end = r.size(0);
    }
    if (r.size(1) == 1) {
      loop_ub = a.size(1);
    } else {
      loop_ub = r.size(1);
    }
    if ((r.size(0) == a.size(0)) && (r.size(1) == a.size(1)) &&
        (c45.size(0) == end) && (c45.size(1) == loop_ub)) {
      loop_ub = c45.size(0) * c45.size(1);
      if (static_cast<int>(loop_ub < 3200)) {
        for (j = 0; j < loop_ub; j++) {
          c45[j] = static_cast<float>(sumh) * c45[j] -
                   static_cast<float>(a_tmp) * (r[j] + a[j]);
        }
      } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

        for (j = 0; j < loop_ub; j++) {
          c45[j] = static_cast<float>(sumh) * c45[j] -
                   static_cast<float>(a_tmp) * (r[j] + a[j]);
        }
      }
    } else {
      binary_expand_op(c45, sumh, a_tmp, r, a);
    }
    ny = c45.size(0) * c45.size(1);
    end = ny - 1;
    if (static_cast<int>(ny < 3200)) {
      for (i = 0; i <= end; i++) {
        if (c45[i] < 0.0F) {
          c45[i] = 0.0F;
        }
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(j)

      for (i = 0; i <= end; i++) {
        if (c45[i] < 0.0F) {
          c45[i] = 0.0F;
        }
      }
    }
  } else {
    getDerivFilters(derivFilters);
    checkerboardPeaks.set_size(outSizeT_tmp, b_outSizeT_tmp);
    if (trueCount) {
      for (j = 0; j < ny; j++) {
        checkerboardPeaks[j] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < ny; j++) {
        checkerboardPeaks[j] = 0.0F;
      }
    }
    IfilterDot.set_size(Ig.size(0), Ig.size(1), 4);
    ny = conn_size_idx_0 << 2;
    b_i = (ny < 3200);
    if (b_i) {
      for (j = 0; j < ny; j++) {
        IfilterDot[j] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < ny; j++) {
        IfilterDot[j] = 0.0F;
      }
    }
    IfilterDdot.set_size(Ig.size(0), Ig.size(1), 4);
    if (b_i) {
      for (j = 0; j < ny; j++) {
        IfilterDdot[j] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (j = 0; j < ny; j++) {
        IfilterDdot[j] = 0.0F;
      }
    }
    nx = Iy.size(0) * Iy.size(1);
    for (outSizeT_tmp = 0; outSizeT_tmp < 3; outSizeT_tmp++) {
      r.set_size(Ig.size(0), Ig.size(1));
      for (b_i = 0; b_i < conn_size_idx_0; b_i++) {
        r[b_i] = Ig[b_i];
      }
      imfilter(r, derivFilters[outSizeT_tmp].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDot[trueCount + IfilterDot.size(0) * b_i] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      r.set_size(Ig.size(0), Ig.size(1));
      for (b_i = 0; b_i < conn_size_idx_0; b_i++) {
        r[b_i] = Ig[b_i];
      }
      imfilter(r, derivFilters[outSizeT_tmp + 3].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDot[(trueCount + IfilterDot.size(0) * b_i) +
                     IfilterDot.size(0) * IfilterDot.size(1)] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      r.set_size(Ig.size(0), Ig.size(1));
      for (b_i = 0; b_i < conn_size_idx_0; b_i++) {
        r[b_i] = Ig[b_i];
      }
      imfilter(r, derivFilters[outSizeT_tmp + 6].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDot[(trueCount + IfilterDot.size(0) * b_i) +
                     IfilterDot.size(0) * IfilterDot.size(1) * 2] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      r.set_size(Ig.size(0), Ig.size(1));
      for (b_i = 0; b_i < conn_size_idx_0; b_i++) {
        r[b_i] = Ig[b_i];
      }
      imfilter(r, derivFilters[outSizeT_tmp + 9].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDot[(trueCount + IfilterDot.size(0) * b_i) +
                     IfilterDot.size(0) * IfilterDot.size(1) * 3] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      loop_ub = IfilterDot.size(1);
      r.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = IfilterDot.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          r[trueCount + r.size(0) * b_i] =
              IfilterDot[trueCount + IfilterDot.size(0) * b_i];
        }
      }
      imfilter(r, derivFilters[outSizeT_tmp].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDdot[trueCount + IfilterDdot.size(0) * b_i] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      loop_ub = IfilterDot.size(1);
      r.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = IfilterDot.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          r[trueCount + r.size(0) * b_i] =
              IfilterDot[(trueCount + IfilterDot.size(0) * b_i) +
                         IfilterDot.size(0) * IfilterDot.size(1)];
        }
      }
      imfilter(r, derivFilters[outSizeT_tmp + 3].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1)] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      loop_ub = IfilterDot.size(1);
      r.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = IfilterDot.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          r[trueCount + r.size(0) * b_i] =
              IfilterDot[trueCount + IfilterDot.size(0) * b_i];
        }
      }
      imfilter(r, derivFilters[outSizeT_tmp + 6].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1) * 2] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      loop_ub = IfilterDot.size(1);
      r.set_size(IfilterDot.size(0), IfilterDot.size(1));
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = IfilterDot.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          r[trueCount + r.size(0) * b_i] =
              IfilterDot[(trueCount + IfilterDot.size(0) * b_i) +
                         IfilterDot.size(0) * IfilterDot.size(1)];
        }
      }
      imfilter(r, derivFilters[outSizeT_tmp + 9].f1);
      loop_ub = r.size(1);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        ny = r.size(0);
        for (trueCount = 0; trueCount < ny; trueCount++) {
          IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                      IfilterDdot.size(0) * IfilterDdot.size(1) * 3] =
              r[trueCount + r.size(0) * b_i];
        }
      }
      checkerEdgeComp.set_size(Ix.size(0), Ix.size(1));
      for (ny = 0; ny < b_nx; ny++) {
        checkerEdgeComp[ny] = std::abs(Ix[ny]);
      }
      I_45.set_size(Iy.size(0), Iy.size(1));
      for (ny = 0; ny < nx; ny++) {
        I_45[ny] = std::abs(Iy[ny]);
      }
      if ((checkerEdgeComp.size(0) == I_45.size(0)) &&
          (checkerEdgeComp.size(1) == I_45.size(1))) {
        loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1);
        for (b_i = 0; b_i < loop_ub; b_i++) {
          checkerEdgeComp[b_i] = checkerEdgeComp[b_i] * 0.3F + I_45[b_i] * 0.3F;
        }
      } else {
        c_binary_expand_op(checkerEdgeComp, I_45);
      }
      loop_ub = IfilterDdot.size(1);
      if ((IfilterDdot.size(0) == checkerEdgeComp.size(0)) &&
          (IfilterDdot.size(1) == checkerEdgeComp.size(1))) {
        a.set_size(IfilterDdot.size(0), IfilterDdot.size(1));
        for (b_i = 0; b_i < loop_ub; b_i++) {
          ny = IfilterDdot.size(0);
          for (trueCount = 0; trueCount < ny; trueCount++) {
            a[trueCount + a.size(0) * b_i] =
                (IfilterDdot[trueCount + IfilterDdot.size(0) * b_i] +
                 IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1)]) -
                checkerEdgeComp[trueCount + checkerEdgeComp.size(0) * b_i];
          }
        }
      } else {
        binary_expand_op(a, IfilterDdot, checkerEdgeComp);
      }
      loop_ub = IfilterDdot.size(1);
      if ((IfilterDdot.size(0) == checkerEdgeComp.size(0)) &&
          (IfilterDdot.size(1) == checkerEdgeComp.size(1))) {
        checkerEdgeComp.set_size(IfilterDdot.size(0), IfilterDdot.size(1));
        for (b_i = 0; b_i < loop_ub; b_i++) {
          ny = IfilterDdot.size(0);
          for (trueCount = 0; trueCount < ny; trueCount++) {
            checkerEdgeComp[trueCount + checkerEdgeComp.size(0) * b_i] =
                (IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1) * 2] +
                 IfilterDdot[(trueCount + IfilterDdot.size(0) * b_i) +
                             IfilterDdot.size(0) * IfilterDdot.size(1) * 3]) -
                checkerEdgeComp[trueCount + checkerEdgeComp.size(0) * b_i];
          }
        }
      } else {
        binary_expand_op(checkerEdgeComp, IfilterDdot);
      }
      end = a.size(0) * a.size(1) - 1;
      for (b_i = 0; b_i <= end; b_i++) {
        if (a[b_i] < 0.0F) {
          a[b_i] = 0.0F;
        }
      }
      end = checkerEdgeComp.size(0) * checkerEdgeComp.size(1) - 1;
      for (b_i = 0; b_i <= end; b_i++) {
        if (checkerEdgeComp[b_i] < 0.0F) {
          checkerEdgeComp[b_i] = 0.0F;
        }
      }
      I_45.set_size(a.size(0), a.size(1));
      loop_ub = a.size(0) * a.size(1) - 1;
      for (b_i = 0; b_i <= loop_ub; b_i++) {
        I_45[b_i] = a[b_i];
      }
      imdilate(I_45, a);
      I_45.set_size(checkerEdgeComp.size(0), checkerEdgeComp.size(1));
      loop_ub = checkerEdgeComp.size(0) * checkerEdgeComp.size(1) - 1;
      for (b_i = 0; b_i <= loop_ub; b_i++) {
        I_45[b_i] = checkerEdgeComp[b_i];
      }
      imdilate(I_45, checkerEdgeComp);
      loop_ub = IfilterDdot.size(1);
      b_IfilterDdot.set_size(IfilterDdot.size(0), IfilterDdot.size(1), 2);
      for (b_i = 0; b_i < 2; b_i++) {
        for (trueCount = 0; trueCount < loop_ub; trueCount++) {
          ny = IfilterDdot.size(0);
          for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
            b_IfilterDdot[(end_tmp_tmp + b_IfilterDdot.size(0) * trueCount) +
                          b_IfilterDdot.size(0) * b_IfilterDdot.size(1) * b_i] =
                IfilterDdot[(end_tmp_tmp + IfilterDdot.size(0) * trueCount) +
                            IfilterDdot.size(0) * IfilterDdot.size(1) * b_i];
          }
        }
      }
      bsxfun(b_IfilterDdot, a, x);
      ny = x.size(0) * x.size(1);
      loop_ub = ny << 1;
      x.set_size(x.size(0), x.size(1), 2);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        varargin_1 = x[b_i];
        x[b_i] = std::fmax(varargin_1, 0.0F);
      }
      if ((x.size(0) == 0) || (x.size(1) == 0)) {
        I_45.set_size(x.size(0), x.size(1));
        loop_ub = x.size(0) * x.size(1);
        for (b_i = 0; b_i < loop_ub; b_i++) {
          I_45[b_i] = 0.0F;
        }
      } else {
        I_45.set_size(x.size(0), x.size(1));
        for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
          I_45[end_tmp_tmp] = x[end_tmp_tmp];
        }
        for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
          I_45[end_tmp_tmp] = I_45[end_tmp_tmp] + x[ny + end_tmp_tmp];
        }
      }
      loop_ub = IfilterDdot.size(1);
      b_IfilterDdot.set_size(IfilterDdot.size(0), IfilterDdot.size(1), 2);
      for (b_i = 0; b_i < 2; b_i++) {
        for (trueCount = 0; trueCount < loop_ub; trueCount++) {
          ny = IfilterDdot.size(0);
          for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
            b_IfilterDdot[(end_tmp_tmp + b_IfilterDdot.size(0) * trueCount) +
                          b_IfilterDdot.size(0) * b_IfilterDdot.size(1) * b_i] =
                IfilterDdot[(end_tmp_tmp + IfilterDdot.size(0) * trueCount) +
                            IfilterDdot.size(0) * IfilterDdot.size(1) *
                                (b_i + 2)];
          }
        }
      }
      bsxfun(b_IfilterDdot, checkerEdgeComp, x);
      ny = x.size(0) * x.size(1);
      loop_ub = ny << 1;
      x.set_size(x.size(0), x.size(1), 2);
      for (b_i = 0; b_i < loop_ub; b_i++) {
        varargin_1 = x[b_i];
        x[b_i] = std::fmax(varargin_1, 0.0F);
      }
      if ((x.size(0) == 0) || (x.size(1) == 0)) {
        a.set_size(x.size(0), x.size(1));
        loop_ub = x.size(0) * x.size(1);
        for (b_i = 0; b_i < loop_ub; b_i++) {
          a[b_i] = 0.0F;
        }
      } else {
        a.set_size(x.size(0), x.size(1));
        for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
          a[end_tmp_tmp] = x[end_tmp_tmp];
        }
        for (end_tmp_tmp = 0; end_tmp_tmp < ny; end_tmp_tmp++) {
          a[end_tmp_tmp] = a[end_tmp_tmp] + x[ny + end_tmp_tmp];
        }
      }
      if (checkerboardPeaks.size(0) == 1) {
        end = I_45.size(0);
      } else {
        end = checkerboardPeaks.size(0);
      }
      if (checkerboardPeaks.size(1) == 1) {
        loop_ub = I_45.size(1);
      } else {
        loop_ub = checkerboardPeaks.size(1);
      }
      if ((checkerboardPeaks.size(0) == I_45.size(0)) &&
          (checkerboardPeaks.size(1) == I_45.size(1)) && (end == a.size(0)) &&
          (loop_ub == a.size(1))) {
        loop_ub = checkerboardPeaks.size(0) * checkerboardPeaks.size(1);
        for (b_i = 0; b_i < loop_ub; b_i++) {
          checkerboardPeaks[b_i] =
              (checkerboardPeaks[b_i] + I_45[b_i]) + a[b_i];
        }
      } else {
        b_binary_expand_op(checkerboardPeaks, I_45, a);
      }
    }
    imerode(checkerboardPeaks, cxy);
  }
}

} // namespace checkerboard
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder

// End of code generation (secondDerivCornerMetric.cpp)
