//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// imedge_2d.h
//
// Code generation for function 'imedge_2d'
//

#ifndef IMEDGE_2D_H
#define IMEDGE_2D_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void imedge_2d(const coder::array<unsigned char, 2U> &b_I,
                      unsigned long long method,
                      coder::array<boolean_T, 2U> &bwimage);

#endif
// End of code generation (imedge_2d.h)
