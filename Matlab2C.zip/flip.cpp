//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// flip.cpp
//
// Code generation for function 'flip'
//

// Include files
#include "flip.h"
#include "get_chessborad_pixel_data.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"

// Function Definitions
namespace coder {
void flip(::coder::array<double, 2U> &x, double dim)
{
  double tmp;
  int b_i;
  int i;
  int i1;
  int i2;
  int j;
  int k;
  int lowerDim;
  int nd2;
  int npages;
  int npagesPrime;
  int pagelen;
  int tmp_tmp;
  int vstride;
  if ((x.size(0) != 0) && (x.size(1) != 0)) {
    i = x.size(static_cast<int>(dim) - 1);
    if (i > 1) {
      vstride = 1;
      i1 = static_cast<unsigned char>(static_cast<int>(dim) - 1);
      for (k = 0; k < i1; k++) {
        vstride *= x.size(0);
      }
      pagelen = vstride * i;
      npages = 1;
      lowerDim = static_cast<int>(dim) + 1;
      if (static_cast<int>(2 - static_cast<int>(dim) < 3200)) {
        for (k = lowerDim; k < 3; k++) {
          npages *= x.size(1);
        }
      } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(npagesPrime)
        {
          npagesPrime = 1;
#pragma omp for nowait
          for (k = lowerDim; k < 3; k++) {
            npagesPrime *= x.size(1);
          }
          omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
          {

            npages *= npagesPrime;
          }
          omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
        }
      }
      nd2 = i >> 1;
      i1 = npages - 1;
      for (j = 0; j <= i1; j++) {
        lowerDim = vstride - 1;
        for (b_i = 0; b_i <= lowerDim; b_i++) {
          npages = j * pagelen + b_i;
          for (k = 0; k < nd2; k++) {
            tmp_tmp = npages + k * vstride;
            tmp = x[tmp_tmp];
            i2 = npages + ((i - k) - 1) * vstride;
            x[tmp_tmp] = x[i2];
            x[i2] = tmp;
          }
        }
      }
    }
  }
}

} // namespace coder

// End of code generation (flip.cpp)
