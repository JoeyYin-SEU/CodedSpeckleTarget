//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sum.cpp
//
// Code generation for function 'sum'
//

// Include files
#include "sum.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"

// Function Definitions
namespace coder {
void sum(const ::coder::array<double, 2U> &x, ::coder::array<double, 1U> &y)
{
  array<double, 1U> bsum;
  if ((x.size(0) == 0) || (x.size(1) == 0)) {
    int firstBlockLength;
    y.set_size(x.size(0));
    firstBlockLength = x.size(0);
    if (static_cast<int>(x.size(0) < 3200)) {
      for (int xj{0}; xj < firstBlockLength; xj++) {
        y[xj] = 0.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int xj = 0; xj < firstBlockLength; xj++) {
        y[xj] = 0.0;
      }
    }
  } else {
    int bvstride;
    int firstBlockLength;
    int lastBlockLength;
    int nblocks;
    int vstride;
    int xoffset;
    vstride = x.size(0) - 1;
    bvstride = x.size(0) << 10;
    y.set_size(x.size(0));
    bsum.set_size(x.size(0));
    if (x.size(1) <= 1024) {
      firstBlockLength = x.size(1);
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = static_cast<int>(static_cast<unsigned int>(x.size(1)) >> 10);
      lastBlockLength = x.size(1) - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    if (static_cast<int>(x.size(0) < 3200)) {
      for (int xj{0}; xj <= vstride; xj++) {
        y[xj] = x[xj];
        bsum[xj] = 0.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int xj = 0; xj <= vstride; xj++) {
        y[xj] = x[xj];
        bsum[xj] = 0.0;
      }
    }
    for (int k{2}; k <= firstBlockLength; k++) {
      xoffset = (k - 1) * (vstride + 1);
      for (int b_xj{0}; b_xj <= vstride; b_xj++) {
        y[b_xj] = y[b_xj] + x[xoffset + b_xj];
      }
    }
    for (int ib{2}; ib <= nblocks; ib++) {
      int hi;
      firstBlockLength = (ib - 1) * bvstride;
      for (int b_xj{0}; b_xj <= vstride; b_xj++) {
        bsum[b_xj] = x[firstBlockLength + b_xj];
      }
      if (ib == nblocks) {
        hi = lastBlockLength;
      } else {
        hi = 1024;
      }
      for (int k{2}; k <= hi; k++) {
        xoffset = firstBlockLength + (k - 1) * (vstride + 1);
        for (int b_xj{0}; b_xj <= vstride; b_xj++) {
          bsum[b_xj] = bsum[b_xj] + x[xoffset + b_xj];
        }
      }
      for (int b_xj{0}; b_xj <= vstride; b_xj++) {
        y[b_xj] = y[b_xj] + bsum[b_xj];
      }
    }
  }
}

double sum(const ::coder::array<float, 1U> &x)
{
  double y;
  if (x.size(0) == 0) {
    y = 0.0;
  } else {
    int firstBlockLength;
    int lastBlockLength;
    int nblocks;
    if (x.size(0) <= 1024) {
      firstBlockLength = x.size(0);
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = static_cast<int>(static_cast<unsigned int>(x.size(0)) >> 10);
      lastBlockLength = x.size(0) - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    y = x[0];
    for (int k{2}; k <= firstBlockLength; k++) {
      y += x[k - 1];
    }
    for (int ib{2}; ib <= nblocks; ib++) {
      double bsum;
      int hi;
      firstBlockLength = (ib - 1) << 10;
      bsum = x[firstBlockLength];
      if (ib == nblocks) {
        hi = lastBlockLength;
      } else {
        hi = 1024;
      }
      for (int k{2}; k <= hi; k++) {
        bsum += x[(firstBlockLength + k) - 1];
      }
      y += bsum;
    }
  }
  return y;
}

} // namespace coder

// End of code generation (sum.cpp)
