//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// imdilate.h
//
// Code generation for function 'imdilate'
//

#ifndef IMDILATE_H
#define IMDILATE_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void imdilate(const ::coder::array<float, 2U> &A, ::coder::array<float, 2U> &B);

}

#endif
// End of code generation (imdilate.h)
