//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// div.cpp
//
// Code generation for function 'div'
//

// Include files
#include "div.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"

// Function Definitions
void binary_expand_op(coder::array<float, 1U> &in1,
                      const coder::array<float, 1U> &in2, float in3)
{
  coder::array<float, 1U> b_in1;
  int i;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  if (in2.size(0) == 1) {
    loop_ub = in1.size(0);
  } else {
    loop_ub = in2.size(0);
  }
  b_in1.set_size(loop_ub);
  stride_0_0 = (in1.size(0) != 1);
  stride_1_0 = (in2.size(0) != 1);
  i = (loop_ub < 3200);
  if (i) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      b_in1[i1] = in1[i1 * stride_0_0] / (in2[i1 * stride_1_0] * in3);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      b_in1[i1] = in1[i1 * stride_0_0] / (in2[i1 * stride_1_0] * in3);
    }
  }
  in1.set_size(b_in1.size(0));
  loop_ub = b_in1.size(0);
  if (i) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1] = b_in1[i1];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i1 = 0; i1 < loop_ub; i1++) {
      in1[i1] = b_in1[i1];
    }
  }
}

// End of code generation (div.cpp)
