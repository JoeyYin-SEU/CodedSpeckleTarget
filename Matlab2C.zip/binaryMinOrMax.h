//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// binaryMinOrMax.h
//
// Code generation for function 'binaryMinOrMax'
//

#ifndef BINARYMINORMAX_H
#define BINARYMINORMAX_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
float binary_expand_op(float in1, const coder::array<double, 1U> &in2,
                       const coder::array<double, 1U> &in3);

#endif
// End of code generation (binaryMinOrMax.h)
