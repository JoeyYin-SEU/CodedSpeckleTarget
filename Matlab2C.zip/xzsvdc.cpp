//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xzsvdc.cpp
//
// Code generation for function 'xzsvdc'
//

// Include files
#include "xzsvdc.h"
#include "rt_nonfinite.h"
#include "xaxpy.h"
#include "xnrm2.h"
#include "xrotg.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>
#include <cstring>

// Function Definitions
namespace coder {
namespace internal {
namespace reflapack {
double xzsvdc(const ::coder::array<double, 2U> &A, double S_data[],
              ::coder::array<double, 2U> &V, int &S_size)
{
  array<double, 1U> e;
  double s_data[2];
  double U;
  double f;
  double nrm;
  double sqds;
  int p;
  int qp1jj;
  p = A.size(1);
  if (A.size(1) >= 2) {
    qp1jj = 2;
  } else {
    qp1jj = A.size(1);
  }
  S_size = (A.size(1) >= 1);
  if (static_cast<int>(qp1jj < 3200)) {
    if (qp1jj - 1 >= 0) {
      std::memset(&s_data[0], 0,
                  static_cast<unsigned int>(qp1jj) * sizeof(double));
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < qp1jj; i++) {
      s_data[i] = 0.0;
    }
  }
  e.set_size(A.size(1));
  qp1jj = A.size(1);
  if (static_cast<int>(A.size(1) < 3200)) {
    for (int i{0}; i < qp1jj; i++) {
      e[i] = 0.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < qp1jj; i++) {
      e[i] = 0.0;
    }
  }
  V.set_size(A.size(1), A.size(1));
  qp1jj = A.size(1) * A.size(1);
  if (static_cast<int>(qp1jj < 3200)) {
    for (int i{0}; i < qp1jj; i++) {
      V[i] = 0.0;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (int i = 0; i < qp1jj; i++) {
      V[i] = 0.0;
    }
  }
  if (A.size(1) == 0) {
    U = 1.0;
  } else {
    double rt;
    double snorm;
    int ii;
    int iter;
    int m;
    int mm;
    int nrt;
    int q;
    if (A.size(1) >= 2) {
      nrt = A.size(1) - 2;
    } else {
      nrt = 0;
    }
    if (nrt > 1) {
      nrt = 1;
    }
    for (q = 0; q < nrt; q++) {
      for (iter = 2; iter <= p; iter++) {
        e[iter - 1] = A[iter - 1];
      }
      if (nrt >= 1) {
        nrm = blas::xnrm2(p - 1, e, 2);
        if (nrm == 0.0) {
          e[0] = 0.0;
        } else {
          if (e[1] < 0.0) {
            e[0] = -nrm;
          } else {
            e[0] = nrm;
          }
          nrm = e[0];
          if (std::abs(e[0]) >= 1.0020841800044864E-292) {
            nrm = 1.0 / e[0];
            for (int k{2}; k <= p; k++) {
              e[k - 1] = nrm * e[k - 1];
            }
          } else {
            for (int k{2}; k <= p; k++) {
              e[k - 1] = e[k - 1] / nrm;
            }
          }
          e[1] = e[1] + 1.0;
          e[0] = -e[0];
        }
        for (ii = 2; ii <= p; ii++) {
          V[ii - 1] = e[ii - 1];
        }
      }
    }
    m = A.size(1);
    if (m > 2) {
      m = 2;
    }
    s_data[0] = A[0];
    if (m > 1) {
      s_data[1] = 0.0;
    }
    if (nrt + 1 < m) {
      e[0] = A[1];
    }
    e[m - 1] = 0.0;
    U = 1.0;
    for (q = p; q >= 1; q--) {
      if ((q <= nrt) && (e[0] != 0.0)) {
        for (iter = 2; iter <= p; iter++) {
          qp1jj = p * (iter - 1);
          nrm = 0.0;
          if (p - 1 >= 1) {
            for (int k{0}; k <= p - 2; k++) {
              nrm += V[k + 1] * V[(qp1jj + k) + 1];
            }
          }
          nrm = -(nrm / V[1]);
          blas::xaxpy(p - 1, nrm, V, qp1jj + 2);
        }
      }
      for (ii = 0; ii < p; ii++) {
        V[ii + V.size(0) * (q - 1)] = 0.0;
      }
      V[(q + V.size(0) * (q - 1)) - 1] = 1.0;
    }
    for (q = 0; q < m; q++) {
      nrm = s_data[q];
      if (nrm != 0.0) {
        rt = std::abs(nrm);
        nrm /= rt;
        s_data[q] = rt;
        if (q + 1 < m) {
          e[0] = e[0] / nrm;
        }
        if (q + 1 <= 1) {
          U *= nrm;
        }
      }
      if ((q + 1 < m) && (e[0] != 0.0)) {
        rt = std::abs(e[0]);
        nrm = rt / e[0];
        e[0] = rt;
        s_data[1] *= nrm;
        qp1jj = p + 1;
        nrt = p + p;
        for (int k{qp1jj}; k <= nrt; k++) {
          V[k - 1] = nrm * V[k - 1];
        }
      }
    }
    mm = m;
    iter = 0;
    snorm = 0.0;
    for (ii = 0; ii < m; ii++) {
      snorm =
          std::fmax(snorm, std::fmax(std::abs(s_data[ii]), std::abs(e[ii])));
    }
    while ((m > 0) && (iter < 75)) {
      boolean_T exitg1;
      q = m - 1;
      ii = m - 1;
      exitg1 = false;
      while (!(exitg1 || (ii == 0))) {
        nrm = std::abs(e[0]);
        if ((nrm <= 2.2204460492503131E-16 *
                        (std::abs(s_data[0]) + std::abs(s_data[1]))) ||
            (nrm <= 1.0020841800044864E-292) ||
            ((iter > 20) && (nrm <= 2.2204460492503131E-16 * snorm))) {
          e[0] = 0.0;
          exitg1 = true;
        } else {
          ii = 0;
        }
      }
      if (ii == m - 1) {
        qp1jj = 4;
      } else {
        nrt = m;
        qp1jj = m;
        exitg1 = false;
        while ((!exitg1) && (qp1jj >= ii)) {
          nrt = qp1jj;
          if (qp1jj == ii) {
            exitg1 = true;
          } else {
            nrm = 0.0;
            if (qp1jj < m) {
              nrm = std::abs(e[0]);
            }
            if (qp1jj > ii + 1) {
              nrm += std::abs(e[0]);
            }
            rt = std::abs(s_data[qp1jj - 1]);
            if ((rt <= 2.2204460492503131E-16 * nrm) ||
                (rt <= 1.0020841800044864E-292)) {
              s_data[qp1jj - 1] = 0.0;
              exitg1 = true;
            } else {
              qp1jj--;
            }
          }
        }
        if (nrt == ii) {
          qp1jj = 3;
        } else if (nrt == m) {
          qp1jj = 1;
        } else {
          qp1jj = 2;
          ii = nrt;
        }
      }
      switch (qp1jj) {
      case 1: {
        f = e[0];
        e[0] = 0.0;
        for (int k{q}; k >= ii + 1; k--) {
          double c;
          c = blas::xrotg(s_data[0], f, nrm);
          if (p >= 1) {
            qp1jj = p * (m - 1);
            for (int b_k{0}; b_k < p; b_k++) {
              double b;
              nrt = qp1jj + b_k;
              b = V[nrt];
              rt = c * V[b_k] + nrm * b;
              V[nrt] = c * b - nrm * V[b_k];
              V[b_k] = rt;
            }
          }
        }
      } break;
      case 2: {
        f = e[ii - 1];
        e[ii - 1] = 0.0;
        for (int k{ii + 1}; k <= m; k++) {
          double sm;
          sm = blas::xrotg(s_data[k - 1], f, sqds);
          nrm = e[k - 1];
          f = -sqds * nrm;
          e[k - 1] = nrm * sm;
          U = sm * U + sqds * U;
        }
      } break;
      case 3: {
        double b;
        double c;
        double scale;
        double sm;
        nrm = s_data[m - 1];
        scale = std::fmax(
            std::fmax(std::fmax(std::fmax(std::abs(nrm), std::abs(s_data[0])),
                                std::abs(e[0])),
                      std::abs(s_data[ii])),
            std::abs(e[ii]));
        sm = nrm / scale;
        nrm = s_data[0] / scale;
        rt = e[0] / scale;
        sqds = s_data[ii] / scale;
        b = ((nrm + sm) * (nrm - sm) + rt * rt) / 2.0;
        c = sm * rt;
        c *= c;
        if ((b != 0.0) || (c != 0.0)) {
          nrm = std::sqrt(b * b + c);
          if (b < 0.0) {
            nrm = -nrm;
          }
          nrm = c / (b + nrm);
        } else {
          nrm = 0.0;
        }
        f = (sqds + sm) * (sqds - sm) + nrm;
        nrm = sqds * (e[ii] / scale);
        for (int k{ii + 1}; k < 2; k++) {
          sm = blas::xrotg(f, nrm, sqds);
          f = sm * s_data[0] + sqds * e[0];
          e[0] = sm * e[0] - sqds * s_data[0];
          nrm = sqds * s_data[1];
          s_data[1] *= sm;
          if (p >= 1) {
            for (int b_k{0}; b_k < p; b_k++) {
              nrt = p + b_k;
              b = V[nrt];
              rt = sm * V[b_k] + sqds * b;
              V[nrt] = sm * b - sqds * V[b_k];
              V[b_k] = rt;
            }
          }
          s_data[0] = f;
          sm = blas::xrotg(s_data[0], nrm, sqds);
          f = sm * e[0] + sqds * s_data[1];
          s_data[1] = -sqds * e[0] + sm * s_data[1];
          nrm = sqds * e[1];
          e[1] = e[1] * sm;
        }
        e[0] = f;
        iter++;
      } break;
      default:
        if (s_data[ii] < 0.0) {
          s_data[ii] = -s_data[ii];
          qp1jj = p * ii;
          nrt = qp1jj + p;
          for (int k{qp1jj + 1}; k <= nrt; k++) {
            V[k - 1] = -V[k - 1];
          }
        }
        while ((ii + 1 < mm) && (s_data[0] < s_data[1])) {
          rt = s_data[0];
          s_data[0] = s_data[1];
          s_data[1] = rt;
          if (p > 1) {
            for (int k{0}; k < p; k++) {
              rt = V[k];
              nrt = p + k;
              V[k] = V[nrt];
              V[nrt] = rt;
            }
          }
          ii = 1;
        }
        iter = 0;
        m--;
        break;
      }
    }
  }
  if (S_size - 1 >= 0) {
    S_data[0] = s_data[0];
  }
  return U;
}

} // namespace reflapack
} // namespace internal
} // namespace coder

// End of code generation (xzsvdc.cpp)
