//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_fx_fy.h
//
// Code generation for function 'get_fx_fy'
//

#ifndef GET_FX_FY_H
#define GET_FX_FY_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void get_fx_fy(const coder::array<unsigned char, 2U> &b_I, double sigma,
                      coder::array<float, 2U> &dx, coder::array<float, 2U> &dy);

#endif
// End of code generation (get_fx_fy.h)
