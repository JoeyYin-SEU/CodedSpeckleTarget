//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// bsxfun.cpp
//
// Code generation for function 'bsxfun'
//

// Include files
#include "bsxfun.h"
#include "rt_nonfinite.h"
#include "coder_array.h"

// Function Definitions
namespace coder {
void bsxfun(const ::coder::array<float, 3U> &a,
            const ::coder::array<float, 2U> &b, ::coder::array<float, 3U> &c)
{
  int acoef;
  int i;
  int u0;
  u0 = b.size(0);
  acoef = a.size(0);
  if (u0 <= acoef) {
    acoef = u0;
  }
  if (b.size(0) == 1) {
    i = a.size(0);
  } else if (a.size(0) == 1) {
    i = b.size(0);
  } else if (a.size(0) == b.size(0)) {
    i = a.size(0);
  } else {
    i = acoef;
  }
  u0 = b.size(1);
  acoef = a.size(1);
  if (u0 <= acoef) {
    acoef = u0;
  }
  if (b.size(1) == 1) {
    u0 = a.size(1);
  } else if (a.size(1) == 1) {
    u0 = b.size(1);
  } else if (a.size(1) == b.size(1)) {
    u0 = a.size(1);
  } else {
    u0 = acoef;
  }
  c.set_size(i, u0, 2);
  if ((i != 0) && (u0 != 0)) {
    int b_acoef;
    int b_bcoef;
    int bcoef;
    acoef = (a.size(1) != 1);
    bcoef = (b.size(1) != 1);
    b_acoef = (a.size(0) != 1);
    b_bcoef = (b.size(0) != 1);
    for (int k{0}; k < 2; k++) {
      i = c.size(1) - 1;
      for (int b_k{0}; b_k <= i; b_k++) {
        int varargin_3;
        int varargin_5;
        varargin_3 = acoef * b_k;
        varargin_5 = bcoef * b_k;
        u0 = c.size(0) - 1;
        for (int c_k{0}; c_k <= u0; c_k++) {
          c[(c_k + c.size(0) * b_k) + c.size(0) * c.size(1) * k] =
              a[(b_acoef * c_k + a.size(0) * varargin_3) +
                a.size(0) * a.size(1) * k] -
              b[b_bcoef * c_k + b.size(0) * varargin_5];
        }
      }
    }
  }
}

void bsxfun(const ::coder::array<float, 2U> &a,
            const ::coder::array<double, 2U> &b, ::coder::array<float, 2U> &c)
{
  int acoef;
  int u0;
  u0 = b.size(1);
  acoef = a.size(1);
  if (u0 <= acoef) {
    acoef = u0;
  }
  if (b.size(1) == 1) {
    u0 = a.size(1);
  } else if (a.size(1) == 1) {
    u0 = b.size(1);
  } else if (a.size(1) == b.size(1)) {
    u0 = a.size(1);
  } else {
    u0 = acoef;
  }
  c.set_size(a.size(0), u0);
  if ((a.size(0) != 0) && (u0 != 0)) {
    int b_acoef;
    int bcoef;
    b_acoef = (a.size(1) != 1);
    bcoef = (b.size(1) != 1);
    u0--;
    acoef = (a.size(0) != 1);
    for (int k{0}; k <= u0; k++) {
      int i;
      int varargin_2;
      int varargin_3;
      varargin_2 = b_acoef * k;
      varargin_3 = bcoef * k;
      i = c.size(0) - 1;
      for (int b_k{0}; b_k <= i; b_k++) {
        c[b_k + c.size(0) * k] = a[acoef * b_k + a.size(0) * varargin_2] -
                                 static_cast<float>(b[varargin_3]);
      }
    }
  }
}

void bsxfun(const ::coder::array<double, 1U> &a,
            const ::coder::array<double, 2U> &b, ::coder::array<double, 2U> &c)
{
  int bcoef;
  int u0;
  u0 = b.size(0);
  bcoef = a.size(0);
  if (u0 <= bcoef) {
    bcoef = u0;
  }
  if (b.size(0) == 1) {
    u0 = a.size(0);
  } else if (a.size(0) == 1) {
    u0 = b.size(0);
  } else if (a.size(0) == b.size(0)) {
    u0 = a.size(0);
  } else {
    u0 = bcoef;
  }
  c.set_size(u0, b.size(1));
  if ((u0 != 0) && (b.size(1) != 0)) {
    int acoef;
    int b_bcoef;
    bcoef = (b.size(1) != 1);
    u0 = b.size(1) - 1;
    acoef = (a.size(0) != 1);
    b_bcoef = (b.size(0) != 1);
    for (int k{0}; k <= u0; k++) {
      int i;
      int varargin_3;
      varargin_3 = bcoef * k;
      i = c.size(0) - 1;
      for (int b_k{0}; b_k <= i; b_k++) {
        c[b_k + c.size(0) * k] =
            a[acoef * b_k] - b[b_bcoef * b_k + b.size(0) * varargin_3];
      }
    }
  }
}

void bsxfun(const ::coder::array<double, 2U> &a,
            const ::coder::array<double, 1U> &b, ::coder::array<double, 2U> &c)
{
  int acoef;
  int u0;
  u0 = b.size(0);
  acoef = a.size(0);
  if (u0 <= acoef) {
    acoef = u0;
  }
  if (b.size(0) == 1) {
    u0 = a.size(0);
  } else if (a.size(0) == 1) {
    u0 = b.size(0);
  } else if (a.size(0) == b.size(0)) {
    u0 = a.size(0);
  } else {
    u0 = acoef;
  }
  c.set_size(u0, a.size(1));
  if ((u0 != 0) && (a.size(1) != 0)) {
    int b_acoef;
    int bcoef;
    acoef = (a.size(1) != 1);
    u0 = a.size(1) - 1;
    b_acoef = (a.size(0) != 1);
    bcoef = (b.size(0) != 1);
    for (int k{0}; k <= u0; k++) {
      int i;
      int varargin_2;
      varargin_2 = acoef * k;
      i = c.size(0) - 1;
      for (int b_k{0}; b_k <= i; b_k++) {
        c[b_k + c.size(0) * k] =
            a[b_acoef * b_k + a.size(0) * varargin_2] / b[bcoef * b_k];
      }
    }
  }
}

} // namespace coder

// End of code generation (bsxfun.cpp)
