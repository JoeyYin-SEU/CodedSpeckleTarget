//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_fx_fy.cpp
//
// Code generation for function 'get_fx_fy'
//

// Include files
#include "get_fx_fy.h"
#include "combineVectorElements.h"
#include "get_chessborad_pixel_data.h"
#include "get_chessborad_pixel_initialize.h"
#include "imfilter.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "omp.h"
#include <cmath>

// Function Definitions
void get_fx_fy(const coder::array<unsigned char, 2U> &b_I, double sigma,
               coder::array<float, 2U> &dx, coder::array<float, 2U> &dy)
{
  coder::array<double, 2U> b_derivGaussKernel;
  coder::array<double, 2U> derivGaussKernel;
  coder::array<double, 2U> x;
  coder::array<double, 1U> c_derivGaussKernel;
  coder::array<int, 2U> r;
  coder::array<int, 2U> r1;
  coder::array<boolean_T, 2U> negVals;
  double a;
  double d;
  double filterExtent;
  double varargin_1;
  int b_loop_ub_tmp;
  int b_trueCountPrime;
  int end_tmp;
  int i;
  int i1;
  int i2;
  int k;
  int loop_ub;
  int loop_ub_tmp;
  int nx;
  int trueCountPrime;
  if (!isInitialized_get_chessborad_pixel) {
    get_chessborad_pixel_initialize();
  }
  dy.set_size(b_I.size(0), b_I.size(1));
  loop_ub_tmp = b_I.size(0) * b_I.size(1);
  i = (loop_ub_tmp < 3200);
  if (i) {
    for (k = 0; k < loop_ub_tmp; k++) {
      dy[k] = static_cast<float>(b_I[k]) / 255.0F;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub_tmp; k++) {
      dy[k] = static_cast<float>(b_I[k]) / 255.0F;
    }
  }
  //  Create an even-length 1-D separable Derivative of Gaussian filter
  //  Determine filter length
  filterExtent = std::ceil(4.0 * sigma);
  if (std::isnan(-filterExtent) || std::isnan(filterExtent)) {
    x.set_size(1, 1);
    x[0] = rtNaN;
  } else if (filterExtent < -filterExtent) {
    x.set_size(x.size(0), 0);
  } else if ((std::isinf(-filterExtent) || std::isinf(filterExtent)) &&
             (-filterExtent == filterExtent)) {
    x.set_size(1, 1);
    x[0] = rtNaN;
  } else {
    d = -filterExtent;
    loop_ub = static_cast<int>(filterExtent - (-filterExtent));
    x.set_size(1, loop_ub + 1);
    if (static_cast<int>(loop_ub + 1 < 3200)) {
      for (k = 0; k <= loop_ub; k++) {
        x[k] = -filterExtent + static_cast<double>(k);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 0; k <= loop_ub; k++) {
        x[k] = d + static_cast<double>(k);
      }
    }
  }
  //  Create 1-D Gaussian Kernel
  a = 1.0 / (2.5066282746310002 * sigma);
  x.set_size(1, x.size(1));
  d = 2.0 * (sigma * sigma);
  b_loop_ub_tmp = x.size(1) - 1;
  loop_ub = x.size(1) - 1;
  i1 = (x.size(1) < 3200);
  if (i1) {
    for (k = 0; k <= b_loop_ub_tmp; k++) {
      filterExtent = x[k];
      x[k] = -(filterExtent * filterExtent) / d;
    }
  } else {
#pragma omp parallel for num_threads(32 > omp_get_max_threads()                \
                                         ? omp_get_max_threads()               \
                                         : 32) private(varargin_1)

    for (k = 0; k <= loop_ub; k++) {
      varargin_1 = x[k];
      x[k] = -(varargin_1 * varargin_1) / d;
    }
  }
  nx = x.size(1);
  if (i1) {
    for (k = 0; k < nx; k++) {
      x[k] = std::exp(x[k]);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      x[k] = std::exp(x[k]);
    }
  }
  x.set_size(1, x.size(1));
  if (i1) {
    for (k = 0; k <= b_loop_ub_tmp; k++) {
      x[k] = a * x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k <= b_loop_ub_tmp; k++) {
      x[k] = a * x[k];
    }
  }
  //  Normalize to ensure kernel sums to one
  filterExtent = coder::combineVectorElements(x);
  x.set_size(1, x.size(1));
  if (i1) {
    for (k = 0; k <= b_loop_ub_tmp; k++) {
      x[k] = x[k] / filterExtent;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k <= b_loop_ub_tmp; k++) {
      x[k] = x[k] / filterExtent;
    }
  }
  //  Create 1-D Derivative of Gaussian Kernel
  if (x.size(1) == 1) {
    derivGaussKernel.set_size(1, 1);
    derivGaussKernel[0] = 0.0;
  } else if (x.size(1) < 2) {
    derivGaussKernel.set_size(
        1, static_cast<int>(static_cast<signed char>(x.size(1))));
    loop_ub = static_cast<signed char>(x.size(1));
    for (i2 = 0; i2 < loop_ub; i2++) {
      derivGaussKernel[0] = 0.0;
    }
  } else {
    derivGaussKernel.set_size(1, x.size(1));
    derivGaussKernel[0] = x[1] - x[0];
    if (static_cast<int>(x.size(1) - 2 < 3200)) {
      for (k = 2; k <= b_loop_ub_tmp; k++) {
        derivGaussKernel[k - 1] = (x[k] - x[k - 2]) / 2.0;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (k = 2; k <= b_loop_ub_tmp; k++) {
        derivGaussKernel[k - 1] = (x[k] - x[k - 2]) / 2.0;
      }
    }
    derivGaussKernel[x.size(1) - 1] = x[x.size(1) - 1] - x[x.size(1) - 2];
  }
  //  Normalize to ensure kernel sums to zero
  negVals.set_size(1, derivGaussKernel.size(1));
  loop_ub = derivGaussKernel.size(1);
  i2 = (derivGaussKernel.size(1) < 3200);
  if (i2) {
    for (k = 0; k < loop_ub; k++) {
      negVals[k] = (derivGaussKernel[k] < 0.0);
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub; k++) {
      negVals[k] = (derivGaussKernel[k] < 0.0);
    }
  }
  end_tmp = derivGaussKernel.size(1) - 1;
  b_loop_ub_tmp = derivGaussKernel.size(1) - 1;
  nx = 0;
  if (i2) {
    for (k = 0; k <= end_tmp; k++) {
      if (derivGaussKernel[k] > 0.0) {
        nx++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(trueCountPrime)
    {
      trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= b_loop_ub_tmp; k++) {
        if (derivGaussKernel[k] > 0.0) {
          trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        nx += trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r.set_size(1, nx);
  nx = 0;
  for (loop_ub = 0; loop_ub <= b_loop_ub_tmp; loop_ub++) {
    if (derivGaussKernel[loop_ub] > 0.0) {
      r[nx] = loop_ub;
      nx++;
    }
  }
  b_derivGaussKernel.set_size(1, r.size(1));
  loop_ub = r.size(1);
  b_loop_ub_tmp = (r.size(1) < 3200);
  if (b_loop_ub_tmp) {
    for (k = 0; k < loop_ub; k++) {
      b_derivGaussKernel[k] = derivGaussKernel[r[k]];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub; k++) {
      b_derivGaussKernel[k] = derivGaussKernel[r[k]];
    }
  }
  filterExtent = coder::combineVectorElements(b_derivGaussKernel);
  loop_ub = r.size(1);
  c_derivGaussKernel.set_size(r.size(1));
  nx = r.size(1);
  if (b_loop_ub_tmp) {
    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[r[k]] / filterExtent;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[r[k]] / filterExtent;
    }
  }
  loop_ub = c_derivGaussKernel.size(0);
  for (b_loop_ub_tmp = 0; b_loop_ub_tmp < loop_ub; b_loop_ub_tmp++) {
    derivGaussKernel[r[b_loop_ub_tmp]] = c_derivGaussKernel[b_loop_ub_tmp];
  }
  nx = 0;
  if (i2) {
    for (k = 0; k <= end_tmp; k++) {
      if (negVals[k]) {
        nx++;
      }
    }
  } else {
#pragma omp parallel num_threads(32 > omp_get_max_threads()                    \
                                     ? omp_get_max_threads()                   \
                                     : 32) private(b_trueCountPrime)
    {
      b_trueCountPrime = 0;
#pragma omp for nowait
      for (k = 0; k <= end_tmp; k++) {
        if (negVals[k]) {
          b_trueCountPrime++;
        }
      }
      omp_set_nest_lock(&get_chessborad_pixel_nestLockGlobal);
      {

        nx += b_trueCountPrime;
      }
      omp_unset_nest_lock(&get_chessborad_pixel_nestLockGlobal);
    }
  }
  r1.set_size(1, nx);
  nx = 0;
  for (loop_ub = 0; loop_ub <= end_tmp; loop_ub++) {
    if (negVals[loop_ub]) {
      r1[nx] = loop_ub;
      nx++;
    }
  }
  b_derivGaussKernel.set_size(1, r1.size(1));
  loop_ub = r1.size(1);
  b_loop_ub_tmp = (r1.size(1) < 3200);
  if (b_loop_ub_tmp) {
    for (k = 0; k < loop_ub; k++) {
      b_derivGaussKernel[k] = derivGaussKernel[r1[k]];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub; k++) {
      b_derivGaussKernel[k] = derivGaussKernel[r1[k]];
    }
  }
  filterExtent = std::abs(coder::combineVectorElements(b_derivGaussKernel));
  loop_ub = r1.size(1);
  c_derivGaussKernel.set_size(r1.size(1));
  nx = r1.size(1);
  if (b_loop_ub_tmp) {
    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[r1[k]] / filterExtent;
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < nx; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[r1[k]] / filterExtent;
    }
  }
  loop_ub = c_derivGaussKernel.size(0);
  for (b_loop_ub_tmp = 0; b_loop_ub_tmp < loop_ub; b_loop_ub_tmp++) {
    derivGaussKernel[r1[b_loop_ub_tmp]] = c_derivGaussKernel[b_loop_ub_tmp];
  }
  //  Compute smoothed numerical gradient of image I along x (horizontal)
  //  direction. GX corresponds to dG/dx, where G is the Gaussian Smoothed
  //  version of image I.
  dx.set_size(dy.size(0), dy.size(1));
  if (i) {
    for (k = 0; k < loop_ub_tmp; k++) {
      dx[k] = dy[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub_tmp; k++) {
      dx[k] = dy[k];
    }
  }
  c_derivGaussKernel.set_size(x.size(1));
  loop_ub = x.size(1);
  if (i1) {
    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = x[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = x[k];
    }
  }
  coder::imfilter(dx, c_derivGaussKernel);
  coder::imfilter(dx, derivGaussKernel);
  //  Compute smoothed numerical gradient of image I along y (vertical)
  //  direction. GY corresponds to dG/dy, where G is the Gaussian Smoothed
  //  version of image I.
  coder::imfilter(dy, x);
  c_derivGaussKernel.set_size(derivGaussKernel.size(1));
  loop_ub = derivGaussKernel.size(1);
  if (i2) {
    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[k];
    }
  } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

    for (k = 0; k < loop_ub; k++) {
      c_derivGaussKernel[k] = derivGaussKernel[k];
    }
  }
  coder::imfilter(dy, c_derivGaussKernel);
}

// End of code generation (get_fx_fy.cpp)
