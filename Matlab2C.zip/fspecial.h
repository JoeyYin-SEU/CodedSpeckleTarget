//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// fspecial.h
//
// Code generation for function 'fspecial'
//

#ifndef FSPECIAL_H
#define FSPECIAL_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void binary_expand_op(double in1_data[], int in1_size[2],
                      const double in2_data[], const int in2_size[2],
                      double in3);

#endif
// End of code generation (fspecial.h)
