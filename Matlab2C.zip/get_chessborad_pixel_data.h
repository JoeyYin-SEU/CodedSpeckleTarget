//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel_data.h
//
// Code generation for function 'get_chessborad_pixel_data'
//

#ifndef GET_CHESSBORAD_PIXEL_DATA_H
#define GET_CHESSBORAD_PIXEL_DATA_H

// Include files
#include "rtwtypes.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern boolean_T halideInit_not_empty;
extern omp_nest_lock_t get_chessborad_pixel_nestLockGlobal;
extern const boolean_T bv[9];
extern boolean_T isInitialized_get_chessborad_pixel;

#endif
// End of code generation (get_chessborad_pixel_data.h)
