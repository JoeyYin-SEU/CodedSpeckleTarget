//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// xgeqp3.cpp
//
// Code generation for function 'xgeqp3'
//

// Include files
#include "xgeqp3.h"
#include "get_chessborad_pixel_rtwutil.h"
#include "rt_nonfinite.h"
#include "xnrm2.h"
#include "coder_array.h"
#include <cmath>
#include <cstring>

// Function Definitions
namespace coder {
namespace internal {
namespace lapack {
int xgeqp3(::coder::array<double, 2U> &A, double tau_data[], int jpvt_data[],
           int jpvt_size[2])
{
  array<double, 2U> x;
  double work_data[5];
  int itemp;
  int m;
  int n;
  int tau_size;
  m = A.size(0);
  n = A.size(1);
  itemp = A.size(0);
  tau_size = A.size(1);
  if (itemp <= tau_size) {
    tau_size = itemp;
  }
  if (tau_size - 1 >= 0) {
    std::memset(&tau_data[0], 0,
                static_cast<unsigned int>(tau_size) * sizeof(double));
  }
  if ((A.size(0) == 0) || (tau_size < 1)) {
    int lastv;
    jpvt_size[0] = 1;
    jpvt_size[1] = A.size(1);
    lastv = A.size(1);
    for (int ix{0}; ix < lastv; ix++) {
      jpvt_data[ix] = ix + 1;
    }
  } else {
    double vn1_data[5];
    double vn2_data[5];
    double absxk;
    int jA;
    int lastv;
    int ma;
    jpvt_size[0] = 1;
    jpvt_size[1] = A.size(1);
    lastv = A.size(1);
    ma = A.size(0);
    for (jA = 0; jA < lastv; jA++) {
      jpvt_data[jA] = jA + 1;
      work_data[jA] = 0.0;
      absxk = blas::xnrm2(m, A, jA * ma + 1);
      vn1_data[jA] = absxk;
      vn2_data[jA] = absxk;
    }
    for (int i{0}; i < tau_size; i++) {
      double s;
      double smax;
      double t;
      int b_i;
      int i1;
      int ii;
      int ii_tmp;
      int ip1;
      int ix;
      int mmi;
      int nmi;
      int pvt;
      ip1 = i + 2;
      ii_tmp = i * ma;
      ii = ii_tmp + i;
      nmi = n - i;
      mmi = (m - i) - 1;
      if (nmi < 1) {
        itemp = -1;
      } else {
        itemp = 0;
        if (nmi > 1) {
          smax = std::abs(vn1_data[i]);
          for (jA = 2; jA <= nmi; jA++) {
            s = std::abs(vn1_data[(i + jA) - 1]);
            if (s > smax) {
              itemp = jA - 1;
              smax = s;
            }
          }
        }
      }
      pvt = i + itemp;
      if (pvt != i) {
        ix = pvt * ma;
        x.set_size(A.size(0), A.size(1));
        lastv = A.size(0) * A.size(1);
        for (b_i = 0; b_i < lastv; b_i++) {
          x[b_i] = A[b_i];
        }
        for (jA = 0; jA < m; jA++) {
          itemp = ix + jA;
          smax = x[itemp];
          b_i = ii_tmp + jA;
          x[itemp] = x[b_i];
          x[b_i] = smax;
        }
        A.set_size(x.size(0), x.size(1));
        lastv = x.size(1);
        for (b_i = 0; b_i < lastv; b_i++) {
          itemp = x.size(0);
          for (i1 = 0; i1 < itemp; i1++) {
            A[i1 + A.size(0) * b_i] = x[i1 + x.size(0) * b_i];
          }
        }
        itemp = jpvt_data[pvt];
        jpvt_data[pvt] = jpvt_data[i];
        jpvt_data[i] = itemp;
        vn1_data[pvt] = vn1_data[i];
        vn2_data[pvt] = vn2_data[i];
      }
      if (i + 1 < m) {
        t = A[ii];
        pvt = ii + 2;
        tau_data[i] = 0.0;
        if (mmi + 1 > 0) {
          smax = blas::xnrm2(mmi, A, ii + 2);
          if (smax != 0.0) {
            s = rt_hypotd_snf(A[ii], smax);
            if (A[ii] >= 0.0) {
              s = -s;
            }
            if (std::abs(s) < 1.0020841800044864E-292) {
              ix = 0;
              b_i = ii + mmi;
              do {
                ix++;
                x.set_size(A.size(0), A.size(1));
                lastv = A.size(0) * A.size(1);
                for (i1 = 0; i1 < lastv; i1++) {
                  x[i1] = A[i1];
                }
                for (jA = pvt; jA <= b_i + 1; jA++) {
                  x[jA - 1] = 9.9792015476736E+291 * x[jA - 1];
                }
                A.set_size(x.size(0), x.size(1));
                lastv = x.size(1);
                for (i1 = 0; i1 < lastv; i1++) {
                  itemp = x.size(0);
                  for (ii_tmp = 0; ii_tmp < itemp; ii_tmp++) {
                    A[ii_tmp + A.size(0) * i1] = x[ii_tmp + x.size(0) * i1];
                  }
                }
                s *= 9.9792015476736E+291;
                t *= 9.9792015476736E+291;
              } while ((std::abs(s) < 1.0020841800044864E-292) && (ix < 20));
              s = rt_hypotd_snf(t, blas::xnrm2(mmi, x, ii + 2));
              if (t >= 0.0) {
                s = -s;
              }
              tau_data[i] = (s - t) / s;
              smax = 1.0 / (t - s);
              for (jA = pvt; jA <= b_i + 1; jA++) {
                x[jA - 1] = smax * x[jA - 1];
              }
              A.set_size(x.size(0), x.size(1));
              lastv = x.size(1);
              for (b_i = 0; b_i < lastv; b_i++) {
                itemp = x.size(0);
                for (i1 = 0; i1 < itemp; i1++) {
                  A[i1 + A.size(0) * b_i] = x[i1 + x.size(0) * b_i];
                }
              }
              for (jA = 0; jA < ix; jA++) {
                s *= 1.0020841800044864E-292;
              }
              t = s;
            } else {
              tau_data[i] = (s - A[ii]) / s;
              smax = 1.0 / (A[ii] - s);
              x.set_size(A.size(0), A.size(1));
              lastv = A.size(0) * A.size(1);
              for (b_i = 0; b_i < lastv; b_i++) {
                x[b_i] = A[b_i];
              }
              b_i = ii + mmi;
              for (jA = pvt; jA <= b_i + 1; jA++) {
                x[jA - 1] = smax * x[jA - 1];
              }
              A.set_size(x.size(0), x.size(1));
              lastv = x.size(1);
              for (b_i = 0; b_i < lastv; b_i++) {
                itemp = x.size(0);
                for (i1 = 0; i1 < itemp; i1++) {
                  A[i1 + A.size(0) * b_i] = x[i1 + x.size(0) * b_i];
                }
              }
              t = s;
            }
          }
        }
        A[ii] = t;
      } else {
        tau_data[i] = 0.0;
      }
      if (i + 1 < n) {
        t = A[ii];
        A[ii] = 1.0;
        jA = (ii + ma) + 1;
        if (tau_data[i] != 0.0) {
          boolean_T exitg2;
          lastv = mmi;
          itemp = ii + mmi;
          while ((lastv + 1 > 0) && (A[itemp] == 0.0)) {
            lastv--;
            itemp--;
          }
          pvt = nmi - 2;
          exitg2 = false;
          while ((!exitg2) && (pvt + 1 > 0)) {
            int exitg1;
            itemp = jA + pvt * ma;
            ii_tmp = itemp;
            do {
              exitg1 = 0;
              if (ii_tmp <= itemp + lastv) {
                if (A[ii_tmp - 1] != 0.0) {
                  exitg1 = 1;
                } else {
                  ii_tmp++;
                }
              } else {
                pvt--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);
            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        } else {
          lastv = -1;
          pvt = -1;
        }
        if (lastv + 1 > 0) {
          if (pvt + 1 != 0) {
            if (pvt >= 0) {
              std::memset(&work_data[0], 0,
                          static_cast<unsigned int>(pvt + 1) * sizeof(double));
            }
            itemp = 0;
            b_i = jA + ma * pvt;
            for (ix = jA; ma < 0 ? ix >= b_i : ix <= b_i; ix += ma) {
              smax = 0.0;
              i1 = ix + lastv;
              for (ii_tmp = ix; ii_tmp <= i1; ii_tmp++) {
                smax += A[ii_tmp - 1] * A[(ii + ii_tmp) - ix];
              }
              work_data[itemp] += smax;
              itemp++;
            }
          }
          if (!(-tau_data[i] == 0.0)) {
            for (ix = 0; ix <= pvt; ix++) {
              absxk = work_data[ix];
              if (absxk != 0.0) {
                smax = absxk * -tau_data[i];
                b_i = lastv + jA;
                for (itemp = jA; itemp <= b_i; itemp++) {
                  A[itemp - 1] = A[itemp - 1] + A[(ii + itemp) - jA] * smax;
                }
              }
              jA += ma;
            }
          }
        }
        A[ii] = t;
      }
      for (ix = ip1; ix <= n; ix++) {
        itemp = (i + (ix - 1) * ma) + 1;
        absxk = vn1_data[ix - 1];
        if (absxk != 0.0) {
          smax = std::abs(A[itemp - 1]) / absxk;
          smax = 1.0 - smax * smax;
          if (smax < 0.0) {
            smax = 0.0;
          }
          s = absxk / vn2_data[ix - 1];
          s = smax * (s * s);
          if (s <= 1.4901161193847656E-8) {
            if (i + 1 < m) {
              pvt = itemp + 1;
              smax = 0.0;
              if (mmi >= 1) {
                if (mmi == 1) {
                  smax = std::abs(A[itemp]);
                } else {
                  s = 3.3121686421112381E-170;
                  itemp += mmi;
                  for (jA = pvt; jA <= itemp; jA++) {
                    absxk = std::abs(A[jA - 1]);
                    if (absxk > s) {
                      t = s / absxk;
                      smax = smax * t * t + 1.0;
                      s = absxk;
                    } else {
                      t = absxk / s;
                      smax += t * t;
                    }
                  }
                  smax = s * std::sqrt(smax);
                }
              }
              vn1_data[ix - 1] = smax;
              vn2_data[ix - 1] = smax;
            } else {
              vn1_data[ix - 1] = 0.0;
              vn2_data[ix - 1] = 0.0;
            }
          } else {
            vn1_data[ix - 1] = absxk * std::sqrt(smax);
          }
        }
      }
    }
  }
  return tau_size;
}

} // namespace lapack
} // namespace internal
} // namespace coder

// End of code generation (xgeqp3.cpp)
