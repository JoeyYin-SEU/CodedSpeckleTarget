//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// get_chessborad_pixel_terminate.cpp
//
// Code generation for function 'get_chessborad_pixel_terminate'
//

// Include files
#include "get_chessborad_pixel_terminate.h"
#include "get_chessborad_pixel_data.h"
#include "halideEvalImpl.h"
#include "rt_nonfinite.h"
#include "omp.h"

// Function Declarations
static void customAtExit();

// Function Definitions
static void customAtExit()
{
  coder::internal::halide::halideCleanup();
}

void get_chessborad_pixel_terminate()
{
  customAtExit();
  omp_destroy_nest_lock(&get_chessborad_pixel_nestLockGlobal);
  isInitialized_get_chessborad_pixel = false;
}

// End of code generation (get_chessborad_pixel_terminate.cpp)
