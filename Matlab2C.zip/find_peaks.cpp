//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// find_peaks.cpp
//
// Code generation for function 'find_peaks'
//

// Include files
#include "find_peaks.h"
#include "algbwmorph.h"
#include "get_chessborad_pixel_rtwutil.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "libmwimregionalmax.h"
#include "omp.h"
#include <cmath>

// Function Definitions
namespace coder {
namespace vision {
namespace internal {
namespace calibration {
namespace checkerboard {
void find_peaks(const ::coder::array<float, 2U> &metric, double quality,
                ::coder::array<float, 2U> &loc)
{
  array<int, 1U> ii;
  array<int, 1U> vk;
  array<boolean_T, 2U> bw;
  array<boolean_T, 2U> last_aout;
  float maxMetric;
  int i;
  int idx;
  int last_tmp;
  int nx;
  boolean_T exitg1;
  last_tmp = metric.size(0) * metric.size(1);
  if (last_tmp <= 2) {
    if (last_tmp == 1) {
      maxMetric = metric[0];
    } else {
      maxMetric = metric[last_tmp - 1];
      if ((!(metric[0] < maxMetric)) &&
          ((!std::isnan(metric[0])) || std::isnan(maxMetric))) {
        maxMetric = metric[0];
      }
    }
  } else {
    if (!std::isnan(metric[0])) {
      idx = 1;
    } else {
      idx = 0;
      nx = 2;
      exitg1 = false;
      while ((!exitg1) && (nx <= last_tmp)) {
        if (!std::isnan(metric[nx - 1])) {
          idx = nx;
          exitg1 = true;
        } else {
          nx++;
        }
      }
    }
    if (idx == 0) {
      maxMetric = metric[0];
    } else {
      maxMetric = metric[idx - 1];
      idx++;
      for (nx = idx; nx <= last_tmp; nx++) {
        float f;
        f = metric[nx - 1];
        if (maxMetric < f) {
          maxMetric = f;
        }
      }
    }
  }
  if (maxMetric <= 4.94065645841247E-324) {
    loc.set_size(0, 2);
  } else {
    double connSizeT[2];
    double imSizeT[2];
    int imSizeT_tmp;
    boolean_T conn[9];
    bw.set_size(metric.size(0), metric.size(1));
    imSizeT_tmp = metric.size(0);
    imSizeT[0] = metric.size(0);
    imSizeT[1] = metric.size(1);
    for (idx = 0; idx < 9; idx++) {
      conn[idx] = true;
    }
    connSizeT[0] = 3.0;
    connSizeT[1] = 3.0;
    imregionalmax_real32(&metric[0], &bw[0], 2.0, &imSizeT[0], &conn[0], 2.0,
                         &connSizeT[0]);
    nx = last_tmp - 1;
    if (static_cast<int>(last_tmp < 3200)) {
      for (i = 0; i <= nx; i++) {
        if (metric[i] < static_cast<float>(quality) * maxMetric) {
          bw[i] = false;
        }
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (i = 0; i <= nx; i++) {
        if (metric[i] < static_cast<float>(quality) * maxMetric) {
          bw[i] = false;
        }
      }
    }
    if ((bw.size(0) != 0) && (bw.size(1) != 0)) {
      boolean_T p;
      do {
        last_aout.set_size(bw.size(0), bw.size(1));
        last_tmp = bw.size(0) * bw.size(1);
        for (idx = 0; idx < last_tmp; idx++) {
          last_aout[idx] = bw[idx];
        }
        images::internal::bwmorphApplyOnce(bw);
        p = false;
        if ((last_aout.size(0) == bw.size(0)) &&
            (last_aout.size(1) == bw.size(1))) {
          p = true;
        }
        if (p && ((last_aout.size(0) != 0) && (last_aout.size(1) != 0)) &&
            ((bw.size(0) != 0) && (bw.size(1) != 0))) {
          nx = 0;
          exitg1 = false;
          while ((!exitg1) && (nx <= bw.size(0) * bw.size(1) - 1)) {
            if (last_aout[nx] != bw[nx]) {
              p = false;
              exitg1 = true;
            } else {
              nx++;
            }
          }
        }
      } while (!p);
      //  the output is not changing anymore
    }
    last_tmp = bw.size(1);
    idx = (bw.size(1) < 3200);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        bw[bw.size(0) * b_i] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        bw[bw.size(0) * b_i] = false;
      }
    }
    nx = bw.size(0);
    last_tmp = bw.size(1);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        bw[(nx + bw.size(0) * b_i) - 1] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        bw[(nx + bw.size(0) * b_i) - 1] = false;
      }
    }
    last_tmp = bw.size(0);
    idx = (bw.size(0) < 3200);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        bw[b_i] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        bw[b_i] = false;
      }
    }
    nx = bw.size(1);
    last_tmp = bw.size(0);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        bw[b_i + bw.size(0) * (nx - 1)] = false;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        bw[b_i + bw.size(0) * (nx - 1)] = false;
      }
    }
    nx = bw.size(0) * bw.size(1);
    idx = 0;
    ii.set_size(nx);
    last_tmp = 0;
    exitg1 = false;
    while ((!exitg1) && (last_tmp <= nx - 1)) {
      if (bw[last_tmp]) {
        idx++;
        ii[idx - 1] = last_tmp + 1;
        if (idx >= nx) {
          exitg1 = true;
        } else {
          last_tmp++;
        }
      } else {
        last_tmp++;
      }
    }
    if (nx == 1) {
      if (idx == 0) {
        ii.set_size(0);
      }
    } else {
      if (idx < 1) {
        idx = 0;
      }
      ii.set_size(idx);
    }
    loc.set_size(ii.size(0), 2);
    last_tmp = ii.size(0) << 1;
    if (static_cast<int>(last_tmp < 3200)) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        loc[b_i] = 0.0F;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        loc[b_i] = 0.0F;
      }
    }
    connSizeT[0] = imSizeT_tmp;
    last_tmp = ii.size(0);
    idx = (ii.size(0) < 3200);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        ii[b_i] = ii[b_i] - 1;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        ii[b_i] = ii[b_i] - 1;
      }
    }
    nx = static_cast<int>(connSizeT[0]);
    vk.set_size(ii.size(0));
    last_tmp = ii.size(0);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        i = div_s32(ii[b_i], nx);
        vk[b_i] = i;
        ii[b_i] = ii[b_i] - i * nx;
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32) private(i)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        i = div_s32(ii[b_i], nx);
        vk[b_i] = i;
        i = ii[b_i] - i * nx;
        ii[b_i] = i;
      }
    }
    last_tmp = ii.size(0);
    if (idx) {
      for (int b_i{0}; b_i < last_tmp; b_i++) {
        loc[b_i + loc.size(0)] = static_cast<float>(ii[b_i] + 1);
        loc[b_i] = static_cast<float>(vk[b_i] + 1);
      }
    } else {
#pragma omp parallel for num_threads(                                          \
    32 > omp_get_max_threads() ? omp_get_max_threads() : 32)

      for (int b_i = 0; b_i < last_tmp; b_i++) {
        loc[b_i + loc.size(0)] = static_cast<float>(ii[b_i] + 1);
        loc[b_i] = static_cast<float>(vk[b_i] + 1);
      }
    }
  }
}

} // namespace checkerboard
} // namespace calibration
} // namespace internal
} // namespace vision
} // namespace coder

// End of code generation (find_peaks.cpp)
